# FIELD TEST — TMC 0.2.1-graph-editor-v05-buildfix-v01

## 1. Smoke / восстановление

После обновления открыть приложение. Старый SQLite store должен восстановиться.

```text
storage verify
runtime reset
runtime init demo
runtime validate
```

Ожидание: `STORAGE VALID`, затем валидный demo graph с 6 nodes / 8 edges.

## 2. Кнопка СБРОС

На вкладке `ГРАФ` нажать `СБРОС`.

Ожидание:

- runtime становится `не инициализирован`;
- telemetry истории `↶.../6 ↷...` не обнуляется;
- SQLite остаётся VALID.

## 3. История 6 ходов

Сделать не менее 7 изменений layout (перемещения Node) либо mix из add/move/edge/AUTO. Затем:

```text
graph history
```

Ожидание: `limit=6`, `undo` не больше 6.

Нажать `ОТМЕНИТЬ` два раза и `ПОВТОРИТЬ` один раз. Положение/topology должны последовательно возвращаться назад/вперёд.

## 4. История переживает runtime reset

До reset сделать хотя бы одно изменение графа:

```text
graph history
runtime reset
graph history
```

Число `undo` после reset не должно исчезнуть.

Не нажимая INIT, нажать `ОТМЕНИТЬ`.

Ожидание: GraphState восстанавливается из истории, runtime снова получает активную graph projection; ответ содержит `restored_after_reset=true`.

После этого `ПОВТОРИТЬ` должен вернуть состояние, которое было непосредственно перед reset.

## 5. Визуальный трубопровод

На demo graph проверить:

- соединения идут горизонтально/вертикально;
- углы визуально скруглены;
- нет диагональных Bezier/spline-проводов;
- трубы не проходят через прямоугольники Node;
- подписи Edge не лежат поверх Node или других подписей;
- feedback Revision → Checks вынесен в свободный routing corridor.

Попробовать в EDIT перетащить Node поверх другого Node. Ожидание: позиция откатывается и появляется сообщение `Позиция отменена`.

## 6. Runtime regression

```text
runtime reset
runtime init demo
runtime validate
runtime emit claim <v05 test>
runtime run
runtime ledger
storage verify
```

Базовый demo без дополнительных nodes/edges должен снова завершиться `Committed` с расходом 17/30 и валидным SQLite chain.
