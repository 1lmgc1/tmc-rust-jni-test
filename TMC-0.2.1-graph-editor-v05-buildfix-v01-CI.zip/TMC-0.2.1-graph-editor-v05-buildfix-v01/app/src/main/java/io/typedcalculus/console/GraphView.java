package io.typedcalculus.console;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * TMC graph viewer/editor projection.
 * Rust owns GraphState. Java draws/edit-intents only.
 *
 * v05 routing policy:
 * - orthogonal pipeline segments;
 * - orthogonal centerlines with true circular rounded elbows; no Bezier/spline routing;
 * - node rectangles are obstacles;
 * - already routed edges are avoided when another free lane exists;
 * - edge labels use reserved route segments and opaque label backing.
 */
public final class GraphView extends View {
    public interface Listener {
        void onNodeMoved(String nodeId, float xDp, float yDp);
        void onConnect(String fromNode, String fromPort, String toNode, String toPort);
        void onNodeSelected(String nodeId, String label, String type);
        void onEditorMessage(String message);
    }

    private static final class PortData {
        String id;
        String name;
        String direction;
        String eventType;
        String cardinality;
        float cx;
        float cy;
    }

    private static final class NodeData {
        String id;
        String label;
        String type;
        int cost;
        int priority;
        int queued;
        int running;
        int suspended;
        int completed;
        String latestKind;
        RectF rect = new RectF();
        int depth;
        boolean hasStoredPosition;
        float storedX;
        float storedY;
        final List<PortData> ports = new ArrayList<>();
    }

    private static final class EdgeData {
        String id;
        String from;
        String fromPort;
        String to;
        String toPort;
        String eventType;
    }

    private static final class PortHit {
        NodeData node;
        PortData port;
    }

    private static final class RouteData {
        EdgeData edge;
        final List<PointF> points = new ArrayList<>();
        RectF labelRect;
        float labelX;
        float labelY;
    }

    private final Paint edgePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint edgeTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint edgeLabelBgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint nodePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint nodeStrokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint titlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint metaPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint badgePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint badgeTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint emptyPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint portPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint portStrokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint portTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint selectionPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private final List<NodeData> nodes = new ArrayList<>();
    private final List<EdgeData> edges = new ArrayList<>();
    private final Map<String, NodeData> nodeById = new HashMap<>();

    private boolean active;
    private String graphId = "";
    private int graphRevision;
    private String stop = "<none>";
    private int iteration;
    private int totalBudget;
    private int spent;
    private int remaining;
    private int historyUndo;
    private int historyRedo;
    private int historyLimit = 6;

    private float scale = 1f;
    private float translateX = 0f;
    private float translateY = 0f;
    private float lastX;
    private float lastY;
    private float downX;
    private float downY;
    private boolean panning;
    private boolean moved;
    private boolean initialFitDone;
    private final ScaleGestureDetector scaleDetector;

    private float contentWidth;
    private float contentHeight;
    private boolean editMode;
    private NodeData draggedNode;
    private RectF dragStartRect;
    private PortHit downPort;
    private PortHit selectedOutput;
    private String selectedNodeId;
    private Listener listener;

    public GraphView(Context context) { this(context, null); }

    public GraphView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setBackgroundColor(Color.rgb(27, 29, 31));

        edgePaint.setColor(Color.rgb(118, 130, 141));
        edgePaint.setStyle(Paint.Style.STROKE);
        edgePaint.setStrokeWidth(dp(1.7f));
        edgePaint.setStrokeCap(Paint.Cap.ROUND);
        edgePaint.setStrokeJoin(Paint.Join.ROUND);

        edgeTextPaint.setColor(Color.rgb(205, 212, 219));
        edgeTextPaint.setTextSize(dp(8.5f));
        edgeTextPaint.setTextAlign(Paint.Align.CENTER);

        edgeLabelBgPaint.setColor(Color.rgb(27, 29, 31));
        edgeLabelBgPaint.setStyle(Paint.Style.FILL);

        nodePaint.setColor(Color.rgb(48, 52, 57));
        nodePaint.setStyle(Paint.Style.FILL);

        nodeStrokePaint.setColor(Color.rgb(104, 116, 128));
        nodeStrokePaint.setStyle(Paint.Style.STROKE);
        nodeStrokePaint.setStrokeWidth(dp(1.3f));

        titlePaint.setColor(Color.WHITE);
        titlePaint.setTextSize(dp(12.5f));
        titlePaint.setFakeBoldText(true);

        metaPaint.setColor(Color.rgb(192, 199, 206));
        metaPaint.setTextSize(dp(8.8f));

        badgePaint.setStyle(Paint.Style.FILL);
        badgeTextPaint.setColor(Color.WHITE);
        badgeTextPaint.setTextSize(dp(8.5f));
        badgeTextPaint.setTextAlign(Paint.Align.CENTER);
        badgeTextPaint.setFakeBoldText(true);

        emptyPaint.setColor(Color.rgb(180, 186, 192));
        emptyPaint.setTextSize(dp(15));
        emptyPaint.setTextAlign(Paint.Align.CENTER);

        portPaint.setStyle(Paint.Style.FILL);
        portPaint.setColor(Color.rgb(94, 105, 116));
        portStrokePaint.setStyle(Paint.Style.STROKE);
        portStrokePaint.setStrokeWidth(dp(1.2f));
        portStrokePaint.setColor(Color.rgb(195, 205, 214));
        portTextPaint.setColor(Color.rgb(185, 193, 201));
        portTextPaint.setTextSize(dp(7.5f));

        selectionPaint.setStyle(Paint.Style.STROKE);
        selectionPaint.setStrokeWidth(dp(2.2f));
        selectionPaint.setColor(Color.rgb(245, 196, 66));

        scaleDetector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector detector) {
                float old = scale;
                scale = clamp(scale * detector.getScaleFactor(), 0.34f, 2.8f);
                float fx = detector.getFocusX();
                float fy = detector.getFocusY();
                if (old != 0f) {
                    float ratio = scale / old;
                    translateX = fx - (fx - translateX) * ratio;
                    translateY = fy - (fy - translateY) * ratio;
                }
                invalidate();
                return true;
            }
        });
    }

    public void setListener(Listener listener) { this.listener = listener; }

    public void setEditMode(boolean enabled) {
        editMode = enabled;
        if (!enabled) selectedOutput = null;
        invalidate();
    }

    public boolean isEditMode() { return editMode; }
    public String getSelectedNodeId() { return selectedNodeId; }

    public void clearSelection() {
        selectedNodeId = null;
        selectedOutput = null;
        invalidate();
    }

    public void setSnapshot(String json) {
        String oldSelected = selectedNodeId;
        boolean preserveView = active && initialFitDone;
        nodes.clear();
        edges.clear();
        nodeById.clear();
        active = false;
        selectedOutput = null;
        initialFitDone = preserveView;
        try {
            JSONObject root = new JSONObject(json == null ? "{}" : json);
            JSONObject history = root.optJSONObject("history");
            if (history != null) {
                historyLimit = history.optInt("limit", 6);
                historyUndo = history.optInt("undo", 0);
                historyRedo = history.optInt("redo", 0);
            }
            active = root.optBoolean("active", false);
            if (!active) {
                selectedNodeId = null;
                selectedOutput = null;
                invalidate();
                return;
            }
            JSONObject graph = root.getJSONObject("graph");
            graphId = graph.optString("id", "graph");
            graphRevision = graph.optInt("revision", 0);
            JSONArray nodeArray = graph.optJSONArray("nodes");
            if (nodeArray != null) {
                for (int i = 0; i < nodeArray.length(); i++) {
                    JSONObject j = nodeArray.getJSONObject(i);
                    NodeData n = new NodeData();
                    n.id = j.optString("id");
                    n.label = j.optString("label", n.id);
                    n.type = j.optString("type", "Node");
                    n.cost = j.optInt("estimated_cost", 0);
                    n.priority = j.optInt("priority", 0);
                    n.queued = j.optInt("queued", 0);
                    n.running = j.optInt("running", 0);
                    n.suspended = j.optInt("suspended", 0);
                    n.completed = j.optInt("completed", 0);
                    n.latestKind = j.optString("latest_event_kind", "");
                    if (!j.isNull("x") && !j.isNull("y")) {
                        n.hasStoredPosition = true;
                        n.storedX = (float) j.optDouble("x", 0.0);
                        n.storedY = (float) j.optDouble("y", 0.0);
                    }
                    JSONArray ports = j.optJSONArray("ports");
                    if (ports != null) {
                        for (int k = 0; k < ports.length(); k++) {
                            JSONObject pj = ports.getJSONObject(k);
                            PortData p = new PortData();
                            p.id = pj.optString("id");
                            p.name = pj.optString("name", p.id);
                            p.direction = pj.optString("direction", "Input");
                            p.eventType = pj.optString("event_type", "");
                            p.cardinality = pj.optString("cardinality", "One");
                            n.ports.add(p);
                        }
                    }
                    nodes.add(n);
                    nodeById.put(n.id, n);
                }
            }
            JSONArray edgeArray = graph.optJSONArray("edges");
            if (edgeArray != null) {
                for (int i = 0; i < edgeArray.length(); i++) {
                    JSONObject j = edgeArray.getJSONObject(i);
                    EdgeData e = new EdgeData();
                    e.id = j.optString("id");
                    e.from = j.optString("from_node");
                    e.fromPort = j.optString("from_port");
                    e.to = j.optString("to_node");
                    e.toPort = j.optString("to_port");
                    e.eventType = j.optString("event_type", "");
                    edges.add(e);
                }
            }
            JSONObject runtime = root.optJSONObject("runtime");
            if (runtime != null) {
                iteration = runtime.optInt("iteration", 0);
                stop = runtime.isNull("stop") ? "<none>" : runtime.optString("stop", "<none>");
            }
            JSONObject resource = root.optJSONObject("resource");
            if (resource != null) {
                totalBudget = resource.optInt("total", 0);
                spent = resource.optInt("spent", 0);
                remaining = resource.optInt("remaining", 0);
            }
            computeLayout();
            if (oldSelected != null && nodeById.containsKey(oldSelected)) selectedNodeId = oldSelected;
            else selectedNodeId = null;
        } catch (Throwable ignored) {
            active = false;
            selectedNodeId = null;
            selectedOutput = null;
        }
        invalidate();
    }

    private void computeLayout() {
        if (nodes.isEmpty()) return;
        Map<String, Integer> indegree = new HashMap<>();
        Map<String, List<String>> outgoing = new HashMap<>();
        for (NodeData n : nodes) {
            indegree.put(n.id, 0);
            outgoing.put(n.id, new ArrayList<String>());
            n.depth = -1;
        }
        for (EdgeData e : edges) {
            if (indegree.containsKey(e.to)) indegree.put(e.to, indegree.get(e.to) + 1);
            List<String> out = outgoing.get(e.from);
            if (out != null) out.add(e.to);
        }

        ArrayDeque<String> queue = new ArrayDeque<>();
        for (NodeData n : nodes) {
            if (indegree.get(n.id) == 0) {
                n.depth = 0;
                queue.add(n.id);
            }
        }
        if (queue.isEmpty()) {
            nodes.get(0).depth = 0;
            queue.add(nodes.get(0).id);
        }
        Set<String> visited = new HashSet<>();
        while (!queue.isEmpty()) {
            String id = queue.removeFirst();
            if (!visited.add(id)) continue;
            NodeData current = nodeById.get(id);
            List<String> out = outgoing.get(id);
            if (current == null || out == null) continue;
            for (String to : out) {
                NodeData child = nodeById.get(to);
                if (child == null) continue;
                if (child.depth < 0) child.depth = current.depth + 1;
                else child.depth = Math.min(child.depth, current.depth + 1);
                if (!visited.contains(to)) queue.addLast(to);
            }
        }
        int maxDepth = 0;
        for (NodeData n : nodes) {
            if (n.depth < 0) n.depth = maxDepth + 1;
            maxDepth = Math.max(maxDepth, n.depth);
        }

        Map<Integer, List<NodeData>> levels = new HashMap<>();
        for (NodeData n : nodes) {
            List<NodeData> list = levels.get(n.depth);
            if (list == null) {
                list = new ArrayList<>();
                levels.put(n.depth, list);
            }
            list.add(n);
        }

        float nodeW = dp(184);
        int maxPorts = 1;
        for (NodeData n : nodes) {
            int ins = 0, outs = 0;
            for (PortData p : n.ports) {
                if ("Output".equals(p.direction)) outs++; else ins++;
            }
            maxPorts = Math.max(maxPorts, Math.max(ins, outs));
        }
        float nodeH = Math.max(dp(118), dp(82 + maxPorts * 20));
        float hGap = dp(92);
        float vGap = dp(112);
        int maxPerLevel = 1;
        for (List<NodeData> list : levels.values()) maxPerLevel = Math.max(maxPerLevel, list.size());
        contentWidth = Math.max(dp(440), maxPerLevel * nodeW + (maxPerLevel - 1) * hGap + dp(110));
        contentHeight = Math.max(dp(560), (maxDepth + 1) * nodeH + maxDepth * vGap + dp(120));

        for (int d = 0; d <= maxDepth; d++) {
            List<NodeData> list = levels.get(d);
            if (list == null) continue;
            float rowW = list.size() * nodeW + (list.size() - 1) * hGap;
            float startX = (contentWidth - rowW) / 2f;
            float baseY = dp(36) + d * (nodeH + vGap);
            for (int i = 0; i < list.size(); i++) {
                NodeData n = list.get(i);
                float x = startX + i * (nodeW + hGap);
                float y = baseY;
                if (n.hasStoredPosition) {
                    x = dp(n.storedX);
                    y = dp(n.storedY);
                }
                n.rect.set(x, y, x + nodeW, y + nodeH);
            }
        }
        resolveStoredOverlaps();
        recomputeContentBounds();
        layoutPorts();
    }

    private void resolveStoredOverlaps() {
        // Old/manual layouts may contain overlaps. Move only later nodes, preserving the first node.
        final float margin = dp(16);
        for (int i = 0; i < nodes.size(); i++) {
            NodeData n = nodes.get(i);
            int guard = 0;
            while (guard++ < 24) {
                NodeData hit = null;
                RectF nr = expanded(n.rect, margin);
                for (int j = 0; j < i; j++) {
                    if (RectF.intersects(nr, expanded(nodes.get(j).rect, margin))) {
                        hit = nodes.get(j);
                        break;
                    }
                }
                if (hit == null) break;
                float dy = hit.rect.bottom + margin - n.rect.top;
                n.rect.offset(0, Math.max(dp(28), dy));
            }
        }
    }

    private void recomputeContentBounds() {
        float maxR = dp(440);
        float maxB = dp(560);
        for (NodeData n : nodes) {
            maxR = Math.max(maxR, n.rect.right + dp(70));
            maxB = Math.max(maxB, n.rect.bottom + dp(80));
        }
        // Reserve a clean external routing corridor for feedback/cross-level edges.
        contentWidth = maxR + dp(210);
        contentHeight = maxB;
    }

    private void layoutPorts() {
        for (NodeData n : nodes) {
            List<PortData> ins = new ArrayList<>();
            List<PortData> outs = new ArrayList<>();
            for (PortData p : n.ports) {
                if ("Output".equals(p.direction)) outs.add(p); else ins.add(p);
            }
            layoutPortSide(n, ins, false);
            layoutPortSide(n, outs, true);
        }
    }

    private void layoutPortSide(NodeData n, List<PortData> ports, boolean output) {
        if (ports.isEmpty()) return;
        float top = n.rect.top + dp(67);
        float bottom = n.rect.bottom - dp(15);
        float step = ports.size() == 1 ? 0f : (bottom - top) / (ports.size() - 1f);
        for (int i = 0; i < ports.size(); i++) {
            PortData p = ports.get(i);
            p.cx = output ? n.rect.right : n.rect.left;
            p.cy = ports.size() == 1 ? (top + bottom) / 2f : top + i * step;
        }
    }

    @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        fitToScreen();
    }

    public void fitToScreen() {
        if (getWidth() <= 0 || contentWidth <= 0) return;
        float sx = (getWidth() - dp(16)) / contentWidth;
        float sy = (getHeight() - dp(16)) / Math.max(contentHeight, dp(1));
        scale = clamp(Math.min(sx, sy), 0.38f, 1.05f);
        translateX = (getWidth() - contentWidth * scale) / 2f;
        translateY = dp(8);
        initialFitDone = true;
        invalidate();
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (!active || nodes.isEmpty()) {
            canvas.drawText("Runtime не инициализирован — INIT или ОТМЕНИТЬ после INIT", getWidth() / 2f, getHeight() / 2f, emptyPaint);
            return;
        }
        if (!initialFitDone) fitToScreen();

        canvas.save();
        canvas.translate(translateX, translateY);
        canvas.scale(scale, scale);
        drawEdges(canvas);
        drawNodes(canvas);
        canvas.restore();
    }

    private PortData findPort(NodeData node, String id) {
        if (node == null) return null;
        for (PortData p : node.ports) if (p.id.equals(id)) return p;
        return null;
    }

    private void drawEdges(Canvas canvas) {
        List<RouteData> routed = new ArrayList<>();
        List<RectF> labelRects = new ArrayList<>();
        float maxRight = 0f;
        for (NodeData n : nodes) maxRight = Math.max(maxRight, n.rect.right);

        for (int i = 0; i < edges.size(); i++) {
            EdgeData e = edges.get(i);
            RouteData route = buildRoute(e, i, routed, maxRight);
            if (route == null || route.points.size() < 2) continue;
            drawRoundedOrthogonalPath(canvas, route.points);
            placeAndDrawEdgeLabel(canvas, route, labelRects);
            routed.add(route);
        }
    }

    private RouteData buildRoute(EdgeData e, int edgeIndex, List<RouteData> routed, float maxRight) {
        NodeData a = nodeById.get(e.from);
        NodeData b = nodeById.get(e.to);
        if (a == null || b == null) return null;
        PortData ap = findPort(a, e.fromPort);
        PortData bp = findPort(b, e.toPort);
        float x1 = ap != null ? ap.cx : a.rect.right;
        float y1 = ap != null ? ap.cy : a.rect.centerY();
        float x2 = bp != null ? bp.cx : b.rect.left;
        float y2 = bp != null ? bp.cy : b.rect.centerY();

        float[] laneOffsets = new float[] {0f, -18f, 18f, -36f, 36f, -54f, 54f, -72f, 72f};
        boolean forward = b.rect.top > a.rect.bottom + dp(26) && b.depth >= a.depth;
        if (forward) {
            for (int k = 0; k < laneOffsets.length; k++) {
                RouteData candidate = forwardRoute(e, a, b, x1, y1, x2, y2, edgeIndex, dp(laneOffsets[k]));
                if (!routeHitsOtherNode(candidate, a, b) && !routeConflicts(candidate, routed)) return candidate;
            }
        }

        // Feedback, long jumps and congested forward edges use a dedicated outer corridor.
        for (int k = 0; k < 18; k++) {
            float laneX = maxRight + dp(54 + (edgeIndex + k) * 22);
            RouteData candidate = outerRoute(e, a, b, x1, y1, x2, y2, edgeIndex + k, laneX);
            if (!routeHitsOtherNode(candidate, a, b) && !routeConflicts(candidate, routed)) return candidate;
        }
        // Last-resort route remains orthogonal and outside nodes; edge-edge overlap is preferable to crossing a node.
        return outerRoute(e, a, b, x1, y1, x2, y2, edgeIndex + 20, maxRight + dp(90 + edgeIndex * 26));
    }

    private RouteData forwardRoute(EdgeData e, NodeData a, NodeData b, float x1, float y1, float x2, float y2, int slot, float laneOffset) {
        RouteData r = new RouteData();
        r.edge = e;
        float stub = dp(24 + (slot % 5) * 6);
        float outX = x1 + stub;
        float inX = x2 - stub;
        float gapTop = a.rect.bottom + dp(24);
        float gapBottom = b.rect.top - dp(24);
        float laneY = (gapTop + gapBottom) * 0.5f + laneOffset;
        laneY = clamp(laneY, Math.min(gapTop, gapBottom), Math.max(gapTop, gapBottom));
        addPoint(r, x1, y1);
        addPoint(r, outX, y1);
        addPoint(r, outX, laneY);
        addPoint(r, inX, laneY);
        addPoint(r, inX, y2);
        addPoint(r, x2, y2);
        simplify(r.points);
        return r;
    }

    private RouteData outerRoute(EdgeData e, NodeData a, NodeData b, float x1, float y1, float x2, float y2, int slot, float outerX) {
        RouteData r = new RouteData();
        r.edge = e;
        float stub = dp(24 + (slot % 6) * 6);
        float outX = x1 + stub;
        float inX = x2 - stub;
        boolean down = b.rect.centerY() >= a.rect.centerY();
        float separation = dp(24 + (slot % 7) * 7);
        float sourceEscapeY = down ? a.rect.bottom + separation : a.rect.top - separation;
        float targetEscapeY = down ? b.rect.top - separation : b.rect.bottom + separation;
        addPoint(r, x1, y1);
        addPoint(r, outX, y1);
        addPoint(r, outX, sourceEscapeY);
        addPoint(r, outerX, sourceEscapeY);
        addPoint(r, outerX, targetEscapeY);
        addPoint(r, inX, targetEscapeY);
        addPoint(r, inX, y2);
        addPoint(r, x2, y2);
        simplify(r.points);
        return r;
    }

    private void addPoint(RouteData r, float x, float y) {
        if (!r.points.isEmpty()) {
            PointF p = r.points.get(r.points.size() - 1);
            if (Math.abs(p.x - x) < 0.5f && Math.abs(p.y - y) < 0.5f) return;
        }
        r.points.add(new PointF(x, y));
    }

    private void simplify(List<PointF> pts) {
        int i = 1;
        while (i < pts.size() - 1) {
            PointF a = pts.get(i - 1), b = pts.get(i), c = pts.get(i + 1);
            boolean sameX = nearly(a.x, b.x) && nearly(b.x, c.x);
            boolean sameY = nearly(a.y, b.y) && nearly(b.y, c.y);
            if (sameX || sameY) pts.remove(i); else i++;
        }
    }

    private boolean routeHitsOtherNode(RouteData r, NodeData source, NodeData target) {
        for (int i = 0; i < r.points.size() - 1; i++) {
            PointF a = r.points.get(i), b = r.points.get(i + 1);
            for (NodeData n : nodes) {
                if (n == source || n == target) continue;
                if (segmentHitsRect(a, b, expanded(n.rect, dp(10)))) return true;
            }
        }
        return false;
    }

    private boolean routeConflicts(RouteData candidate, List<RouteData> routed) {
        for (RouteData prior : routed) {
            for (int i = 0; i < candidate.points.size() - 1; i++) {
                PointF a1 = candidate.points.get(i), a2 = candidate.points.get(i + 1);
                for (int j = 0; j < prior.points.size() - 1; j++) {
                    PointF b1 = prior.points.get(j), b2 = prior.points.get(j + 1);
                    if (orthogonalSegmentsConflict(a1, a2, b1, b2)) {
                        if (sharedEndpointOnly(a1, a2, b1, b2)) continue;
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private boolean sharedEndpointOnly(PointF a1, PointF a2, PointF b1, PointF b2) {
        PointF[] aa = {a1, a2};
        PointF[] bb = {b1, b2};
        int shared = 0;
        for (PointF a : aa) for (PointF b : bb) if (samePoint(a, b)) shared++;
        if (shared == 0) return false;
        // Sharing a branch/join port is legitimate if the segments do not overlap beyond the endpoint.
        if (isHorizontal(a1, a2) && isHorizontal(b1, b2) && nearly(a1.y, b1.y)) {
            float overlap = intervalOverlap(a1.x, a2.x, b1.x, b2.x);
            return overlap <= dp(1.5f);
        }
        if (isVertical(a1, a2) && isVertical(b1, b2) && nearly(a1.x, b1.x)) {
            float overlap = intervalOverlap(a1.y, a2.y, b1.y, b2.y);
            return overlap <= dp(1.5f);
        }
        return true;
    }

    private boolean orthogonalSegmentsConflict(PointF a1, PointF a2, PointF b1, PointF b2) {
        boolean ah = isHorizontal(a1, a2), av = isVertical(a1, a2);
        boolean bh = isHorizontal(b1, b2), bv = isVertical(b1, b2);
        if (ah && bh) return nearly(a1.y, b1.y) && intervalOverlap(a1.x, a2.x, b1.x, b2.x) > dp(1.0f);
        if (av && bv) return nearly(a1.x, b1.x) && intervalOverlap(a1.y, a2.y, b1.y, b2.y) > dp(1.0f);
        if (ah && bv) return between(b1.x, a1.x, a2.x) && between(a1.y, b1.y, b2.y);
        if (av && bh) return between(a1.x, b1.x, b2.x) && between(b1.y, a1.y, a2.y);
        return false;
    }

    private boolean segmentHitsRect(PointF a, PointF b, RectF r) {
        if (isHorizontal(a, b)) {
            if (a.y < r.top || a.y > r.bottom) return false;
            return rangesOverlap(a.x, b.x, r.left, r.right);
        }
        if (isVertical(a, b)) {
            if (a.x < r.left || a.x > r.right) return false;
            return rangesOverlap(a.y, b.y, r.top, r.bottom);
        }
        return false;
    }

    private void drawRoundedOrthogonalPath(Canvas canvas, List<PointF> points) {
        if (points.size() < 2) return;
        Path path = new Path();
        PointF first = points.get(0);
        path.moveTo(first.x, first.y);
        float radius = dp(8);
        for (int i = 1; i < points.size() - 1; i++) {
            PointF prev = points.get(i - 1);
            PointF cur = points.get(i);
            PointF next = points.get(i + 1);
            float d1 = distance(prev, cur);
            float d2 = distance(cur, next);
            float rr = Math.min(radius, Math.min(d1, d2) * 0.34f);
            if (rr < dp(0.5f)) {
                path.lineTo(cur.x, cur.y);
                continue;
            }
            PointF before = toward(cur, prev, rr);
            PointF after = toward(cur, next, rr);
            path.lineTo(before.x, before.y);

            float inX = axisSign(cur.x - prev.x);
            float inY = axisSign(cur.y - prev.y);
            float outX = axisSign(next.x - cur.x);
            float outY = axisSign(next.y - cur.y);
            float centerX = cur.x - inX * rr + outX * rr;
            float centerY = cur.y - inY * rr + outY * rr;
            RectF oval = new RectF(centerX - rr, centerY - rr, centerX + rr, centerY + rr);
            float startAngle = (float) Math.toDegrees(Math.atan2(before.y - centerY, before.x - centerX));
            float cross = inX * outY - inY * outX;
            float sweep = cross >= 0f ? 90f : -90f;
            path.arcTo(oval, startAngle, sweep, false);
        }
        PointF last = points.get(points.size() - 1);
        path.lineTo(last.x, last.y);
        canvas.drawPath(path, edgePaint);
    }

    private void placeAndDrawEdgeLabel(Canvas canvas, RouteData route, List<RectF> occupiedLabels) {
        String text = route.edge.eventType == null ? "" : shorten(route.edge.eventType, 22);
        if (text.isEmpty()) return;
        float tw = edgeTextPaint.measureText(text);
        float padX = dp(5);
        float padY = dp(3);
        float needed = tw + padX * 2 + dp(10);

        List<Integer> segments = new ArrayList<>();
        for (int i = 0; i < route.points.size() - 1; i++) {
            PointF a = route.points.get(i), b = route.points.get(i + 1);
            if (isHorizontal(a, b) && Math.abs(b.x - a.x) >= needed) segments.add(i);
        }
        Collections.sort(segments, new Comparator<Integer>() {
            @Override public int compare(Integer i1, Integer i2) {
                PointF a1 = route.points.get(i1), b1 = route.points.get(i1 + 1);
                PointF a2 = route.points.get(i2), b2 = route.points.get(i2 + 1);
                return Float.compare(Math.abs(b2.x - a2.x), Math.abs(b1.x - a1.x));
            }
        });

        RectF chosen = null;
        float cx = 0f, cy = 0f;
        final float[] fractions = {0.50f, 0.30f, 0.70f, 0.18f, 0.82f};
        for (Integer idx : segments) {
            PointF a = route.points.get(idx), b = route.points.get(idx + 1);
            float left = Math.min(a.x, b.x), right = Math.max(a.x, b.x);
            for (float f : fractions) {
                float candidateX = left + (right - left) * f;
                float candidateY = a.y;
                RectF box = new RectF(candidateX - tw / 2f - padX, candidateY - dp(9) - padY,
                        candidateX + tw / 2f + padX, candidateY + dp(3) + padY);
                if (labelBoxFree(box, occupiedLabels)) {
                    chosen = box;
                    cx = candidateX;
                    cy = candidateY;
                    break;
                }
            }
            if (chosen != null) break;
        }
        // Never paint a label on top of a node or another label. If the graph is too dense,
        // the label is suppressed until layout/routing frees a clean segment.
        if (chosen == null) return;
        route.labelRect = chosen;
        route.labelX = cx;
        route.labelY = cy;
        occupiedLabels.add(new RectF(chosen));
        canvas.drawRoundRect(chosen, dp(4), dp(4), edgeLabelBgPaint);
        canvas.drawText(text, cx, cy + dp(2.4f), edgeTextPaint);
    }

    private boolean labelBoxFree(RectF box, List<RectF> occupiedLabels) {
        for (NodeData n : nodes) if (RectF.intersects(box, expanded(n.rect, dp(6)))) return false;
        for (RectF other : occupiedLabels) if (RectF.intersects(box, expanded(other, dp(4)))) return false;
        return true;
    }

    private void drawNodes(Canvas canvas) {
        for (NodeData n : nodes) {
            nodePaint.setColor(nodeFill(n));
            nodeStrokePaint.setColor(nodeStroke(n));
            canvas.drawRoundRect(n.rect, dp(12), dp(12), nodePaint);
            canvas.drawRoundRect(n.rect, dp(12), dp(12), nodeStrokePaint);
            if (n.id.equals(selectedNodeId)) canvas.drawRoundRect(n.rect, dp(12), dp(12), selectionPaint);

            float left = n.rect.left + dp(11);
            canvas.drawText(shorten(n.label, 24), left, n.rect.top + dp(20), titlePaint);
            canvas.drawText(n.type + "  c" + n.cost + "  p" + n.priority, left, n.rect.top + dp(38), metaPaint);
            String latest = (n.latestKind == null || n.latestKind.isEmpty()) ? "" : "last: " + n.latestKind;
            if (!latest.isEmpty()) canvas.drawText(shorten(latest, 30), left, n.rect.top + dp(54), metaPaint);

            float bx = n.rect.right - dp(12);
            float by = n.rect.top + dp(13);
            if (n.queued > 0) { drawBadge(canvas, bx, by, "Q" + n.queued, Color.rgb(68, 114, 196)); by += dp(18); }
            if (n.running > 0) { drawBadge(canvas, bx, by, "R" + n.running, Color.rgb(56, 142, 60)); by += dp(18); }
            if (n.suspended > 0) drawBadge(canvas, bx, by, "S" + n.suspended, Color.rgb(198, 119, 34));

            drawPorts(canvas, n);
        }
    }

    private void drawPorts(Canvas canvas, NodeData n) {
        for (PortData p : n.ports) {
            boolean output = "Output".equals(p.direction);
            boolean isSelected = selectedOutput != null && selectedOutput.node.id.equals(n.id) && selectedOutput.port.id.equals(p.id);
            boolean compatible = editMode && selectedOutput != null && !output && selectedOutput.port.eventType.equals(p.eventType);
            if (isSelected) portPaint.setColor(Color.rgb(245, 196, 66));
            else if (compatible) portPaint.setColor(Color.rgb(86, 181, 112));
            else portPaint.setColor(output ? Color.rgb(95, 145, 210) : Color.rgb(120, 126, 133));
            canvas.drawCircle(p.cx, p.cy, dp(5.2f), portPaint);
            canvas.drawCircle(p.cx, p.cy, dp(5.2f), portStrokePaint);
            float tx = output ? p.cx - dp(8) : p.cx + dp(8);
            portTextPaint.setTextAlign(output ? Paint.Align.RIGHT : Paint.Align.LEFT);
            canvas.drawText(shorten(p.name, 12), tx, p.cy + dp(2.5f), portTextPaint);
        }
    }

    private int nodeFill(NodeData n) {
        if (n.suspended > 0) return Color.rgb(79, 55, 39);
        if (n.running > 0) return Color.rgb(38, 75, 48);
        if (n.queued > 0) return Color.rgb(39, 58, 82);
        if ("Commit".equals(n.type) && "Committed".equals(stop)) return Color.rgb(38, 72, 48);
        return Color.rgb(48, 52, 57);
    }

    private int nodeStroke(NodeData n) {
        if (n.suspended > 0) return Color.rgb(232, 152, 72);
        if (n.running > 0) return Color.rgb(103, 190, 113);
        if (n.queued > 0) return Color.rgb(100, 149, 237);
        return Color.rgb(104, 116, 128);
    }

    private void drawBadge(Canvas canvas, float cx, float cy, String text, int color) {
        badgePaint.setColor(color);
        float r = dp(10);
        canvas.drawCircle(cx, cy, r, badgePaint);
        Paint.FontMetrics fm = badgeTextPaint.getFontMetrics();
        float y = cy - (fm.ascent + fm.descent) / 2f;
        canvas.drawText(text, cx, y, badgeTextPaint);
    }

    private NodeData hitNode(float screenX, float screenY) {
        float gx = (screenX - translateX) / scale;
        float gy = (screenY - translateY) / scale;
        for (int i = nodes.size() - 1; i >= 0; i--) if (nodes.get(i).rect.contains(gx, gy)) return nodes.get(i);
        return null;
    }

    private PortHit hitPort(float screenX, float screenY) {
        float radius = dp(22);
        for (NodeData n : nodes) {
            for (PortData p : n.ports) {
                float sx = translateX + p.cx * scale;
                float sy = translateY + p.cy * scale;
                float dx = sx - screenX;
                float dy = sy - screenY;
                if (dx * dx + dy * dy <= radius * radius) {
                    PortHit h = new PortHit();
                    h.node = n;
                    h.port = p;
                    return h;
                }
            }
        }
        return null;
    }

    private void handlePortTap(PortHit hit) {
        if (!editMode || hit == null) return;
        if ("Output".equals(hit.port.direction)) {
            if (selectedOutput != null && selectedOutput.node.id.equals(hit.node.id) && selectedOutput.port.id.equals(hit.port.id)) {
                selectedOutput = null;
                tell("Связь: выбор OUT отменён");
            } else {
                selectedOutput = hit;
                tell("OUT выбран: " + hit.node.id + "." + hit.port.id + " : " + hit.port.eventType + " → выбери совместимый IN");
            }
            invalidate();
            return;
        }
        if (selectedOutput == null) {
            tell("Сначала выбери OUT-порт, затем IN-порт");
            return;
        }
        if (!selectedOutput.port.eventType.equals(hit.port.eventType)) {
            tell("TYPE MISMATCH: " + selectedOutput.port.eventType + " != " + hit.port.eventType);
            return;
        }
        if (listener != null) listener.onConnect(selectedOutput.node.id, selectedOutput.port.id, hit.node.id, hit.port.id);
        selectedOutput = null;
        invalidate();
    }

    private boolean overlapsOtherNode(NodeData movedNode) {
        RectF probe = expanded(movedNode.rect, dp(12));
        for (NodeData other : nodes) {
            if (other == movedNode) continue;
            if (RectF.intersects(probe, expanded(other.rect, dp(12)))) return true;
        }
        return false;
    }

    private void tell(String message) {
        if (listener != null) listener.onEditorMessage(message);
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        scaleDetector.onTouchEvent(event);
        if (event.getPointerCount() > 1) {
            panning = false;
            draggedNode = null;
            dragStartRect = null;
            downPort = null;
            return true;
        }
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = lastX = event.getX();
                downY = lastY = event.getY();
                moved = false;
                downPort = editMode ? hitPort(event.getX(), event.getY()) : null;
                if (downPort != null) return true;
                if (editMode) {
                    draggedNode = hitNode(event.getX(), event.getY());
                    if (draggedNode != null) {
                        dragStartRect = new RectF(draggedNode.rect);
                        selectedNodeId = draggedNode.id;
                        invalidate();
                        return true;
                    }
                }
                panning = true;
                return true;

            case MotionEvent.ACTION_MOVE:
                if (scaleDetector.isInProgress()) return true;
                float x = event.getX();
                float y = event.getY();
                if (Math.abs(x - downX) + Math.abs(y - downY) > dp(6)) moved = true;
                if (draggedNode != null && editMode) {
                    float dx = (x - lastX) / scale;
                    float dy = (y - lastY) / scale;
                    draggedNode.rect.offset(dx, dy);
                    draggedNode.rect.offsetTo(Math.max(0, draggedNode.rect.left), Math.max(0, draggedNode.rect.top));
                    layoutPorts();
                    recomputeContentBounds();
                } else if (panning) {
                    translateX += x - lastX;
                    translateY += y - lastY;
                }
                lastX = x;
                lastY = y;
                invalidate();
                return true;

            case MotionEvent.ACTION_UP:
                if (downPort != null && !moved) {
                    handlePortTap(downPort);
                    downPort = null;
                    return true;
                }
                if (draggedNode != null) {
                    NodeData n = draggedNode;
                    draggedNode = null;
                    if (moved) {
                        if (overlapsOtherNode(n)) {
                            if (dragStartRect != null) n.rect.set(dragStartRect);
                            layoutPorts();
                            recomputeContentBounds();
                            tell("Позиция отменена: узлы не могут накладываться друг на друга");
                        } else if (listener != null) {
                            listener.onNodeMoved(n.id, n.rect.left / density(), n.rect.top / density());
                        }
                    } else {
                        selectedNodeId = n.id;
                        if (listener != null) listener.onNodeSelected(n.id, n.label, n.type);
                    }
                    dragStartRect = null;
                    invalidate();
                    return true;
                }
                if (!moved && editMode) {
                    NodeData n = hitNode(event.getX(), event.getY());
                    if (n == null) {
                        selectedNodeId = null;
                        selectedOutput = null;
                        tell("Выбор снят");
                        invalidate();
                    }
                }
                panning = false;
                return true;

            case MotionEvent.ACTION_CANCEL:
                if (draggedNode != null && dragStartRect != null) draggedNode.rect.set(dragStartRect);
                panning = false;
                draggedNode = null;
                dragStartRect = null;
                downPort = null;
                layoutPorts();
                invalidate();
                return true;
            default:
                return true;
        }
    }

    public String compactSummary() {
        String history = "   ↶" + historyUndo + "/" + historyLimit + " ↷" + historyRedo;
        if (!active) return "runtime: не инициализирован" + history;
        return graphId + " r" + graphRevision + "   iter " + iteration + "   resource " + spent + "/" + totalBudget +
                "   осталось " + remaining + "   stop " + stop + history + (editMode ? "   EDIT" : "");
    }

    private static boolean nearly(float a, float b) { return Math.abs(a - b) < 0.75f; }
    private static boolean isHorizontal(PointF a, PointF b) { return nearly(a.y, b.y); }
    private static boolean isVertical(PointF a, PointF b) { return nearly(a.x, b.x); }
    private static boolean between(float v, float a, float b) { return v >= Math.min(a, b) - 0.75f && v <= Math.max(a, b) + 0.75f; }
    private static boolean rangesOverlap(float a1, float a2, float b1, float b2) { return Math.max(Math.min(a1, a2), Math.min(b1, b2)) <= Math.min(Math.max(a1, a2), Math.max(b1, b2)); }
    private static float intervalOverlap(float a1, float a2, float b1, float b2) { return Math.max(0f, Math.min(Math.max(a1, a2), Math.max(b1, b2)) - Math.max(Math.min(a1, a2), Math.min(b1, b2))); }
    private static boolean samePoint(PointF a, PointF b) { return Math.abs(a.x - b.x) < 1f && Math.abs(a.y - b.y) < 1f; }
    private static float distance(PointF a, PointF b) { float dx = b.x - a.x, dy = b.y - a.y; return (float)Math.sqrt(dx * dx + dy * dy); }
    private static PointF toward(PointF from, PointF to, float distance) {
        float dx = to.x - from.x, dy = to.y - from.y;
        float len = (float)Math.sqrt(dx * dx + dy * dy);
        if (len < 0.001f) return new PointF(from.x, from.y);
        float f = Math.min(1f, distance / len);
        return new PointF(from.x + dx * f, from.y + dy * f);
    }
    private static RectF expanded(RectF r, float margin) { return new RectF(r.left - margin, r.top - margin, r.right + margin, r.bottom + margin); }
    private static float axisSign(float v) { return v > 0.5f ? 1f : (v < -0.5f ? -1f : 0f); }

    private float density() { return getResources().getDisplayMetrics().density; }
    private float dp(float value) { return value * density(); }
    private static float clamp(float v, float min, float max) { return Math.max(min, Math.min(max, v)); }
    private static String shorten(String s, int max) {
        if (s == null) return "";
        if (s.length() <= max) return s;
        return s.substring(0, Math.max(1, max - 1)) + "…";
    }
}
