package io.typedcalculus.console;

public final class NativeBridge {
    private NativeBridge() {}

    public static void load() {
        System.loadLibrary("typed_calculus");
    }

    public static native long execute(int op, long a, long b);
}
