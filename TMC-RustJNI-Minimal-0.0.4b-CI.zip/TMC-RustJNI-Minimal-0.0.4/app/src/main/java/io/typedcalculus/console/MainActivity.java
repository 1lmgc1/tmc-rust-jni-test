package io.typedcalculus.console;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public final class MainActivity extends Activity {
    private TextView output;
    private EditText input;
    private boolean loaded = false;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
        println("TMC RUST JNI TEST");
        println("Ожидаю: SEND -> Rust execute(1,20,22)");
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(8), dp(8), dp(8), dp(8));
        root.setBackgroundColor(Color.rgb(46, 46, 46));

        ScrollView scroll = new ScrollView(this);
        output = new TextView(this);
        output.setTextColor(Color.LTGRAY);
        output.setTextSize(18f);
        output.setGravity(Gravity.START);
        scroll.addView(output, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT,
                ScrollView.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        input = new EditText(this);
        input.setHint("command");
        input.setSingleLine(true);
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(Color.LTGRAY);
        input.setImeOptions(EditorInfo.IME_ACTION_SEND);
        root.addView(input, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        Button send = new Button(this);
        send.setText("SEND");
        root.addView(send, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        View.OnClickListener action = v -> runRustTest();
        send.setOnClickListener(action);
        input.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                runRustTest();
                return true;
            }
            return false;
        });

        setContentView(root);
    }

    private void runRustTest() {
        try {
            if (!loaded) {
                NativeBridge.load();
                loaded = true;
                println("Rust library loaded");
            }
            long result = NativeBridge.execute(1, 20L, 22L);
            println("Rust execute(1,20,22) = " + result);
            if (result == 42L) {
                println("PASS: Java -> JNI -> Rust -> Java");
            } else {
                println("FAIL: expected 42");
            }
        } catch (Throwable t) {
            println("ERROR: " + t.getClass().getName() + ": " + t.getMessage());
        }
    }

    private void println(String s) {
        output.append(s);
        output.append("\n");
    }

    private int dp(int n) {
        return Math.round(n * getResources().getDisplayMetrics().density);
    }
}
