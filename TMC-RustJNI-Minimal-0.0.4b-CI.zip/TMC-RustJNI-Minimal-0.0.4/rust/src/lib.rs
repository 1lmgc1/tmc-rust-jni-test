use core::ffi::c_void;

#[no_mangle]
pub extern "system" fn Java_io_typedcalculus_console_NativeBridge_execute(
    _env: *mut c_void,
    _class: *mut c_void,
    op: i32,
    a: i64,
    b: i64,
) -> i64 {
    match op {
        1 => a.wrapping_add(b),
        2 => a.wrapping_sub(b),
        3 => a.wrapping_mul(b),
        _ => i64::MIN,
    }
}
