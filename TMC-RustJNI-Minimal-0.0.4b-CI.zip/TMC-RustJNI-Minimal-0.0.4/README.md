# TMC Rust JNI Minimal 0.0.4

Minimal Android 14 / arm64-v8a field test for the real target architecture:

`Java Android host -> JNI -> Rust cdylib -> Java UI`

No Kotlin, Compose, SQLite, updater, persistence, or calculus state machine is included in this milestone.
Those layers are intentionally excluded because Java UI, native loading, and JNI have already passed on the physical phone; this test changes only the native implementation language from the prior C prototype to genuine Rust.

## Expected field result
Tap **SEND** once. Expected:

```text
Rust library loaded
Rust execute(1,20,22) = 42
PASS: Java -> JNI -> Rust -> Java
```

## Build
Requires Java 17, Android SDK 34, Android NDK 26.3.11579264, Gradle 8.9, and Rust 1.85.1 with `aarch64-linux-android` target.

The included GitHub Actions workflow performs the complete build and uploads the APK artifact.


Test applicationId: `io.typedcalculus.rustjnitest` so it installs alongside earlier TMC test builds without signature conflict.
