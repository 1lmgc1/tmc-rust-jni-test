package io.typedcalculus.console;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class MainActivity extends Activity {
    private static final String VERSION = "0.2.1-graph-editor-v01";

    private TextView output;
    private EditText input;
    private ScrollView scroll;
    private SharedPreferences prefs;
    private boolean nativeReady;
    private boolean sqliteReady;
    private final ArrayDeque<String> commandQueue = new ArrayDeque<>();

    private LinearLayout graphPane;
    private LinearLayout consolePane;
    private GraphView graphView;
    private TextView graphTelemetry;
    private TextView graphAction;
    private Button graphTab;
    private Button consoleTab;
    private Button editorButton;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
        prefs = getSharedPreferences("tmc", MODE_PRIVATE);
        printGreeting();
        try {
            NativeBridge.load();
            nativeReady = true;

            String dbPath = new java.io.File(getFilesDir(), "tmc-runtime.sqlite3").getAbsolutePath();
            String storage = NativeBridge.initStorage(dbPath);
            if (storage != null && storage.startsWith("RESTORED")) {
                sqliteReady = true;
                println("SQLite: состояние восстановлено; " + storage);
            } else if (storage != null && storage.startsWith("EMPTY")) {
                sqliteReady = true;
                println("SQLite: создан новый durable store; " + storage);
                String saved = prefs.getString("rust_state_json_v2", null);
                if (saved != null && !saved.isEmpty()) {
                    boolean ok = NativeBridge.importState(saved);
                    println(ok ? "Миграция SharedPreferences → SQLite: OK" : "Миграция SharedPreferences → SQLite: отклонена");
                } else {
                    String checkpoint = NativeBridge.persistStorage();
                    println("SQLite: " + checkpoint);
                }
            } else {
                println("SQLite недоступен: " + storage);
                String saved = prefs.getString("rust_state_json_v2", null);
                if (saved != null && !saved.isEmpty()) {
                    boolean ok = NativeBridge.importState(saved);
                    println(ok ? "Fallback SharedPreferences: состояние восстановлено" : "Fallback SharedPreferences: состояние не принято");
                }
            }
            printExpectation();
            showGraph();
            refreshGraph();
        } catch (Throwable t) {
            println("ОШИБКА NATIVE: " + t.getClass().getSimpleName() + ": " + t.getMessage());
            graphAction.setText("NATIVE ERROR: " + t.getClass().getSimpleName());
        }
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(31, 33, 36));

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        tabs.setPadding(dp(6), dp(4), dp(6), dp(2));

        graphTab = new Button(this);
        graphTab.setText("ГРАФ");
        tabs.addView(graphTab, new LinearLayout.LayoutParams(0, -2, 1f));

        consoleTab = new Button(this);
        consoleTab.setText("КОНСОЛЬ");
        tabs.addView(consoleTab, new LinearLayout.LayoutParams(0, -2, 1f));
        root.addView(tabs, new LinearLayout.LayoutParams(-1, -2));

        graphPane = buildGraphPane();
        consolePane = buildConsolePane();
        root.addView(graphPane, new LinearLayout.LayoutParams(-1, 0, 1f));
        root.addView(consolePane, new LinearLayout.LayoutParams(-1, 0, 1f));

        graphTab.setOnClickListener(v -> showGraph());
        consoleTab.setOnClickListener(v -> showConsole());

        setContentView(root);
        showGraph();
    }

    private LinearLayout buildGraphPane() {
        LinearLayout pane = new LinearLayout(this);
        pane.setOrientation(LinearLayout.VERTICAL);
        pane.setPadding(dp(7), dp(4), dp(7), dp(7));

        graphTelemetry = new TextView(this);
        graphTelemetry.setTextColor(Color.WHITE);
        graphTelemetry.setTextSize(14f);
        graphTelemetry.setGravity(Gravity.START);
        graphTelemetry.setPadding(dp(6), dp(5), dp(6), dp(5));
        graphTelemetry.setText("runtime: загрузка…");
        pane.addView(graphTelemetry, new LinearLayout.LayoutParams(-1, -2));

        graphAction = new TextView(this);
        graphAction.setTextColor(Color.LTGRAY);
        graphAction.setTextSize(12f);
        graphAction.setPadding(dp(6), 0, dp(6), dp(5));
        graphAction.setMaxLines(4);
        graphAction.setText("VIEW: щипок — масштаб, палец — панорама. В EDIT: узел можно двигать; OUT → совместимый IN создаёт typed Edge.");
        pane.addView(graphAction, new LinearLayout.LayoutParams(-1, -2));

        graphView = new GraphView(this);
        graphView.setListener(new GraphView.Listener() {
            @Override public void onNodeMoved(String nodeId, float xDp, float yDp) {
                String cmd = String.format(Locale.US, "graph layout set %s %.1f %.1f", nodeId, xDp, yDp);
                runGraphCommand(cmd, false);
            }

            @Override public void onConnect(String fromNode, String fromPort, String toNode, String toPort) {
                runGraphCommand("graph edge add " + fromNode + "." + fromPort + " " + toNode + "." + toPort, false);
            }

            @Override public void onNodeSelected(String nodeId, String label, String type) {
                graphAction.setText("Выбран: " + label + "  [" + nodeId + "]  type=" + type);
            }

            @Override public void onEditorMessage(String message) {
                graphAction.setText(message);
            }
        });
        pane.addView(graphView, new LinearLayout.LayoutParams(-1, 0, 1f));

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        Button init = makeButton("INIT");
        Button step = makeButton("STEP");
        Button run = makeButton("RUN");
        Button refresh = makeButton("ОБНОВИТЬ");
        row1.addView(init, new LinearLayout.LayoutParams(0, -2, 1f));
        row1.addView(step, new LinearLayout.LayoutParams(0, -2, 1f));
        row1.addView(run, new LinearLayout.LayoutParams(0, -2, 1f));
        row1.addView(refresh, new LinearLayout.LayoutParams(0, -2, 1f));
        pane.addView(row1, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        Button fit = makeButton("ВПИСАТЬ");
        Button queue = makeButton("ОЧЕРЕДЬ");
        Button events = makeButton("СОБЫТИЯ");
        Button ledger = makeButton("РЕСУРС");
        row2.addView(fit, new LinearLayout.LayoutParams(0, -2, 1f));
        row2.addView(queue, new LinearLayout.LayoutParams(0, -2, 1f));
        row2.addView(events, new LinearLayout.LayoutParams(0, -2, 1f));
        row2.addView(ledger, new LinearLayout.LayoutParams(0, -2, 1f));
        pane.addView(row2, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout row3 = new LinearLayout(this);
        row3.setOrientation(LinearLayout.HORIZONTAL);
        editorButton = makeButton("РЕДАКТОР");
        Button addNode = makeButton("+ УЗЕЛ");
        Button deleteNode = makeButton("УДАЛИТЬ");
        Button autoLayout = makeButton("AUTO");
        row3.addView(editorButton, new LinearLayout.LayoutParams(0, -2, 1f));
        row3.addView(addNode, new LinearLayout.LayoutParams(0, -2, 1f));
        row3.addView(deleteNode, new LinearLayout.LayoutParams(0, -2, 1f));
        row3.addView(autoLayout, new LinearLayout.LayoutParams(0, -2, 1f));
        pane.addView(row3, new LinearLayout.LayoutParams(-1, -2));

        init.setOnClickListener(v -> runGraphCommand("runtime init demo", false));
        step.setOnClickListener(v -> runGraphCommand("runtime step", false));
        run.setOnClickListener(v -> runGraphCommand("runtime run", false));
        refresh.setOnClickListener(v -> refreshGraph());
        fit.setOnClickListener(v -> graphView.fitToScreen());
        queue.setOnClickListener(v -> runGraphCommand("runtime queue", true));
        events.setOnClickListener(v -> runGraphCommand("runtime events", true));
        ledger.setOnClickListener(v -> runGraphCommand("runtime ledger", true));
        editorButton.setOnClickListener(v -> {
            boolean enabled = !graphView.isEditMode();
            graphView.setEditMode(enabled);
            editorButton.setText(enabled ? "EDIT: ВКЛ" : "РЕДАКТОР");
            graphAction.setText(enabled
                    ? "EDIT: drag узла сохраняет layout; тап OUT → тап совместимого IN создаёт Edge. Структуру меняй до runtime emit/run."
                    : "VIEW: щипок — масштаб, палец — панорама.");
            graphTelemetry.setText(graphView.compactSummary());
        });
        addNode.setOnClickListener(v -> showNodePalette());
        deleteNode.setOnClickListener(v -> {
            String id = graphView.getSelectedNodeId();
            if (id == null || id.isEmpty()) {
                graphAction.setText("Сначала выбери пользовательский узел n-user-* в EDIT.");
                return;
            }
            runGraphCommand("graph node remove " + id, false);
            graphView.clearSelection();
        });
        autoLayout.setOnClickListener(v -> {
            runGraphCommand("graph layout clear", false);
            graphView.fitToScreen();
        });

        return pane;
    }

    private void showNodePalette() {
        final String[] types = {"SemanticCheck", "CounterCheck", "Compare", "Revision", "Commit"};
        new AlertDialog.Builder(this)
                .setTitle("Добавить Node")
                .setItems(types, (dialog, which) -> runGraphCommand("graph node add " + types[which], false))
                .setNegativeButton("ОТМЕНА", null)
                .show();
    }

    private LinearLayout buildConsolePane() {
        LinearLayout pane = new LinearLayout(this);
        pane.setOrientation(LinearLayout.VERTICAL);
        pane.setPadding(dp(8), dp(4), dp(8), dp(8));

        scroll = new ScrollView(this);
        output = new TextView(this);
        output.setTextColor(Color.LTGRAY);
        output.setTextSize(16f);
        output.setGravity(Gravity.START);
        output.setTextIsSelectable(true);
        scroll.addView(output, new ScrollView.LayoutParams(-1,-2));
        pane.addView(scroll, new LinearLayout.LayoutParams(-1,0,1f));

        input = new EditText(this);
        input.setHint("команды — по одной на строку");
        input.setSingleLine(false);
        input.setMinLines(3);
        input.setMaxLines(8);
        input.setGravity(Gravity.TOP | Gravity.START);
        input.setHorizontallyScrolling(false);
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(Color.LTGRAY);
        input.setImeOptions(EditorInfo.IME_FLAG_NO_ENTER_ACTION);
        pane.addView(input, new LinearLayout.LayoutParams(-1,-2));

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);

        Button execute = makeButton("ВЫПОЛНИТЬ");
        buttons.addView(execute, new LinearLayout.LayoutParams(0,-2,1f));

        Button clear = makeButton("ОЧИСТИТЬ");
        buttons.addView(clear, new LinearLayout.LayoutParams(0,-2,1f));

        pane.addView(buttons, new LinearLayout.LayoutParams(-1,-2));

        execute.setOnClickListener(v -> dispatchBatch());
        clear.setOnClickListener(v -> {
            input.setText("");
            commandQueue.clear();
        });

        return pane;
    }

    private Button makeButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(11f);
        b.setMinHeight(0);
        b.setMinWidth(0);
        b.setPadding(dp(2), dp(4), dp(2), dp(4));
        return b;
    }

    private void showGraph() {
        graphPane.setVisibility(View.VISIBLE);
        consolePane.setVisibility(View.GONE);
        if (nativeReady) refreshGraph();
    }

    private void showConsole() {
        graphPane.setVisibility(View.GONE);
        consolePane.setVisibility(View.VISIBLE);
    }

    private void refreshGraph() {
        if (!nativeReady) return;
        try {
            String json = NativeBridge.uiSnapshot();
            graphView.setSnapshot(json);
            graphTelemetry.setText(graphView.compactSummary());
        } catch (Throwable t) {
            graphAction.setText("Ошибка GraphView: " + t.getClass().getSimpleName() + ": " + t.getMessage());
        }
    }

    private void runGraphCommand(String cmd, boolean openConsole) {
        if (!nativeReady) return;
        try {
            String response = NativeBridge.command(cmd);
            println("> " + cmd);
            if (response != null && !response.isEmpty()) println(response);
            saveState();
            graphAction.setText(compactResponse(cmd, response));
            refreshGraph();
            if (openConsole) showConsole();
        } catch (Throwable t) {
            graphAction.setText("ОШИБКА: " + t.getClass().getSimpleName() + ": " + t.getMessage());
        }
    }

    private String compactResponse(String cmd, String response) {
        if (response == null || response.isEmpty()) return cmd;
        String line = response.split("\\n", 2)[0];
        return cmd + " → " + line;
    }

    private void printGreeting() {
        println(" /\\_/\\ ");
        println("( o.o )   TMC " + VERSION);
        println(" > ^ <    Graph Editor / Java host / Rust SQLite event-runtime / Android 14 arm64");
        println("");
        println(" /\\_/\\   /\\_/\\ ");
        println("( =^.^= ) ( =^.^= )");
        println("(\")_(\") (\")_(\")");
        println("");
        println("ГРАФ — основной интерфейс runtime; КОНСОЛЬ — пакетный ввод и диагностика.");
        println("РЕДАКТОР: двигай узлы; OUT → совместимый IN создаёт typed Edge; + УЗЕЛ открывает палитру.");
        println("Структурное редактирование блокируется после начала исполнения; layout можно менять всегда.");
        println("");
    }

    private void dispatchBatch() {
        String raw = input.getText().toString();
        if (raw == null || raw.trim().isEmpty()) return;

        List<String> commands = parseCommands(raw);
        if (commands.isEmpty()) {
            input.setText("");
            return;
        }

        input.setText("");
        commandQueue.clear();
        commandQueue.addAll(commands);

        if (!nativeReady) {
            println("native core недоступно");
            return;
        }

        if (commands.size() > 1) println("=== ПАКЕТ: " + commands.size() + " команд ===");

        int total = commands.size();
        int index = 0;
        while (!commandQueue.isEmpty()) {
            String cmd = commandQueue.removeFirst();
            index++;
            if (total > 1) println("[" + index + "/" + total + "] > " + cmd);
            else println("> " + cmd);

            try {
                String response = NativeBridge.command(cmd);
                if (response != null && !response.isEmpty()) println(response);
                saveState();

                if (isHardFailure(response)) {
                    preserveRemainingQueue();
                    println("=== ПАКЕТ ОСТАНОВЛЕН: ошибка на " + index + "/" + total +
                            "; оставшиеся команды возвращены в поле ввода ===");
                    printExpectation();
                    refreshGraph();
                    return;
                }
            } catch (Throwable t) {
                println("ОШИБКА: " + t.getClass().getSimpleName() + ": " + t.getMessage());
                preserveRemainingQueue();
                println("=== ПАКЕТ ОСТАНОВЛЕН: исключение; оставшиеся команды возвращены в поле ввода ===");
                printExpectation();
                refreshGraph();
                return;
            }
        }

        if (total > 1) println("=== ПАКЕТ ЗАВЕРШЁН: " + total + "/" + total + " ===");
        printExpectation();
        refreshGraph();
    }

    private List<String> parseCommands(String raw) {
        String normalized = raw.replace("\r\n", "\n").replace('\r', '\n');
        String[] lines = normalized.split("\n");
        ArrayList<String> result = new ArrayList<>();
        for (String line : lines) {
            String cmd = line.trim();
            if (cmd.isEmpty()) continue;
            if (cmd.startsWith("#")) continue;
            result.add(cmd);
        }
        return result;
    }

    private boolean isHardFailure(String response) {
        if (response == null) return false;
        String r = response.trim();
        return r.startsWith("ОШИБКА:") ||
               r.startsWith("ERROR:") ||
               r.startsWith("НЕИЗВЕСТНАЯ КОМАНДА") ||
               r.startsWith("TYPE MISMATCH:") ||
               r.startsWith("CARDINALITY:") ||
               r.startsWith("UNKNOWN;");
    }

    private void preserveRemainingQueue() {
        if (commandQueue.isEmpty()) return;
        StringBuilder sb = new StringBuilder();
        while (!commandQueue.isEmpty()) {
            if (sb.length() > 0) sb.append('\n');
            sb.append(commandQueue.removeFirst());
        }
        input.setText(sb.toString());
        input.setSelection(input.getText().length());
    }

    private void saveState() {
        if (sqliteReady) return;
        String data = NativeBridge.exportState();
        if (data != null) prefs.edit().putString("rust_state_json_v2", data).apply();
    }

    private void printExpectation() {
        if (!nativeReady) return;
        String e = NativeBridge.expectation();
        println("Ожидаю: " + e);
    }

    private void println(String s) {
        if (output == null) return;
        output.append(s); output.append("\n");
        if (scroll != null) scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }
}
