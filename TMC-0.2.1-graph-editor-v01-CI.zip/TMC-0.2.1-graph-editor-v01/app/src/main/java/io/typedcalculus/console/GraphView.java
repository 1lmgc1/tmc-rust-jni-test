package io.typedcalculus.console;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * TMC graph viewer/editor projection.
 * Rust owns GraphState; this View edits only through listener callbacks.
 */
public final class GraphView extends View {
    public interface Listener {
        void onNodeMoved(String nodeId, float xDp, float yDp);
        void onConnect(String fromNode, String fromPort, String toNode, String toPort);
        void onNodeSelected(String nodeId, String label, String type);
        void onEditorMessage(String message);
    }

    private static final class PortData {
        String id;
        String name;
        String direction;
        String eventType;
        String cardinality;
        float cx;
        float cy;
    }

    private static final class NodeData {
        String id;
        String label;
        String type;
        int cost;
        int priority;
        int queued;
        int running;
        int suspended;
        int completed;
        String latestKind;
        RectF rect = new RectF();
        int depth;
        boolean hasStoredPosition;
        float storedX;
        float storedY;
        final List<PortData> ports = new ArrayList<>();
    }

    private static final class EdgeData {
        String id;
        String from;
        String fromPort;
        String to;
        String toPort;
        String eventType;
    }

    private static final class PortHit {
        NodeData node;
        PortData port;
    }

    private final Paint edgePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint edgeTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint nodePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint nodeStrokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint titlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint metaPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint badgePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint badgeTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint emptyPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint portPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint portStrokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint portTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint selectionPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private final List<NodeData> nodes = new ArrayList<>();
    private final List<EdgeData> edges = new ArrayList<>();
    private final Map<String, NodeData> nodeById = new HashMap<>();

    private boolean active;
    private String graphId = "";
    private int graphRevision;
    private String stop = "<none>";
    private int iteration;
    private int totalBudget;
    private int spent;
    private int remaining;

    private float scale = 1f;
    private float translateX = 0f;
    private float translateY = 0f;
    private float lastX;
    private float lastY;
    private float downX;
    private float downY;
    private boolean panning;
    private boolean moved;
    private boolean initialFitDone;
    private final ScaleGestureDetector scaleDetector;

    private float contentWidth;
    private float contentHeight;
    private boolean editMode;
    private NodeData draggedNode;
    private PortHit downPort;
    private PortHit selectedOutput;
    private String selectedNodeId;
    private Listener listener;

    public GraphView(Context context) { this(context, null); }

    public GraphView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setBackgroundColor(Color.rgb(27, 29, 31));

        edgePaint.setColor(Color.rgb(108, 118, 128));
        edgePaint.setStyle(Paint.Style.STROKE);
        edgePaint.setStrokeWidth(dp(1.5f));

        edgeTextPaint.setColor(Color.rgb(156, 166, 176));
        edgeTextPaint.setTextSize(dp(8.5f));

        nodePaint.setColor(Color.rgb(48, 52, 57));
        nodePaint.setStyle(Paint.Style.FILL);

        nodeStrokePaint.setColor(Color.rgb(104, 116, 128));
        nodeStrokePaint.setStyle(Paint.Style.STROKE);
        nodeStrokePaint.setStrokeWidth(dp(1.3f));

        titlePaint.setColor(Color.WHITE);
        titlePaint.setTextSize(dp(12.5f));
        titlePaint.setFakeBoldText(true);

        metaPaint.setColor(Color.rgb(192, 199, 206));
        metaPaint.setTextSize(dp(8.8f));

        badgePaint.setStyle(Paint.Style.FILL);
        badgeTextPaint.setColor(Color.WHITE);
        badgeTextPaint.setTextSize(dp(8.5f));
        badgeTextPaint.setTextAlign(Paint.Align.CENTER);
        badgeTextPaint.setFakeBoldText(true);

        emptyPaint.setColor(Color.rgb(180, 186, 192));
        emptyPaint.setTextSize(dp(15));
        emptyPaint.setTextAlign(Paint.Align.CENTER);

        portPaint.setStyle(Paint.Style.FILL);
        portPaint.setColor(Color.rgb(94, 105, 116));
        portStrokePaint.setStyle(Paint.Style.STROKE);
        portStrokePaint.setStrokeWidth(dp(1.2f));
        portStrokePaint.setColor(Color.rgb(195, 205, 214));
        portTextPaint.setColor(Color.rgb(185, 193, 201));
        portTextPaint.setTextSize(dp(7.5f));

        selectionPaint.setStyle(Paint.Style.STROKE);
        selectionPaint.setStrokeWidth(dp(2.2f));
        selectionPaint.setColor(Color.rgb(245, 196, 66));

        scaleDetector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector detector) {
                float old = scale;
                scale = clamp(scale * detector.getScaleFactor(), 0.42f, 2.6f);
                float fx = detector.getFocusX();
                float fy = detector.getFocusY();
                if (old != 0f) {
                    float ratio = scale / old;
                    translateX = fx - (fx - translateX) * ratio;
                    translateY = fy - (fy - translateY) * ratio;
                }
                invalidate();
                return true;
            }
        });
    }

    public void setListener(Listener listener) { this.listener = listener; }

    public void setEditMode(boolean enabled) {
        editMode = enabled;
        if (!enabled) selectedOutput = null;
        invalidate();
    }

    public boolean isEditMode() { return editMode; }

    public String getSelectedNodeId() { return selectedNodeId; }

    public void clearSelection() {
        selectedNodeId = null;
        selectedOutput = null;
        invalidate();
    }

    public void setSnapshot(String json) {
        String oldSelected = selectedNodeId;
        boolean preserveView = active && initialFitDone;
        nodes.clear();
        edges.clear();
        nodeById.clear();
        active = false;
        selectedOutput = null;
        initialFitDone = preserveView;
        try {
            JSONObject root = new JSONObject(json == null ? "{}" : json);
            active = root.optBoolean("active", false);
            if (!active) {
                selectedNodeId = null;
                selectedOutput = null;
                invalidate();
                return;
            }
            JSONObject graph = root.getJSONObject("graph");
            graphId = graph.optString("id", "graph");
            graphRevision = graph.optInt("revision", 0);
            JSONArray nodeArray = graph.optJSONArray("nodes");
            if (nodeArray != null) {
                for (int i = 0; i < nodeArray.length(); i++) {
                    JSONObject j = nodeArray.getJSONObject(i);
                    NodeData n = new NodeData();
                    n.id = j.optString("id");
                    n.label = j.optString("label", n.id);
                    n.type = j.optString("type", "Node");
                    n.cost = j.optInt("estimated_cost", 0);
                    n.priority = j.optInt("priority", 0);
                    n.queued = j.optInt("queued", 0);
                    n.running = j.optInt("running", 0);
                    n.suspended = j.optInt("suspended", 0);
                    n.completed = j.optInt("completed", 0);
                    n.latestKind = j.optString("latest_event_kind", "");
                    if (!j.isNull("x") && !j.isNull("y")) {
                        n.hasStoredPosition = true;
                        n.storedX = (float) j.optDouble("x", 0.0);
                        n.storedY = (float) j.optDouble("y", 0.0);
                    }
                    JSONArray ports = j.optJSONArray("ports");
                    if (ports != null) {
                        for (int k = 0; k < ports.length(); k++) {
                            JSONObject pj = ports.getJSONObject(k);
                            PortData p = new PortData();
                            p.id = pj.optString("id");
                            p.name = pj.optString("name", p.id);
                            p.direction = pj.optString("direction", "Input");
                            p.eventType = pj.optString("event_type", "");
                            p.cardinality = pj.optString("cardinality", "One");
                            n.ports.add(p);
                        }
                    }
                    nodes.add(n);
                    nodeById.put(n.id, n);
                }
            }
            JSONArray edgeArray = graph.optJSONArray("edges");
            if (edgeArray != null) {
                for (int i = 0; i < edgeArray.length(); i++) {
                    JSONObject j = edgeArray.getJSONObject(i);
                    EdgeData e = new EdgeData();
                    e.id = j.optString("id");
                    e.from = j.optString("from_node");
                    e.fromPort = j.optString("from_port");
                    e.to = j.optString("to_node");
                    e.toPort = j.optString("to_port");
                    e.eventType = j.optString("event_type", "");
                    edges.add(e);
                }
            }
            JSONObject runtime = root.optJSONObject("runtime");
            if (runtime != null) {
                iteration = runtime.optInt("iteration", 0);
                stop = runtime.isNull("stop") ? "<none>" : runtime.optString("stop", "<none>");
            }
            JSONObject resource = root.optJSONObject("resource");
            if (resource != null) {
                totalBudget = resource.optInt("total", 0);
                spent = resource.optInt("spent", 0);
                remaining = resource.optInt("remaining", 0);
            }
            computeLayout();
            if (oldSelected != null && nodeById.containsKey(oldSelected)) selectedNodeId = oldSelected;
            else selectedNodeId = null;
            if (selectedOutput != null && !nodeById.containsKey(selectedOutput.node.id)) selectedOutput = null;
        } catch (Throwable ignored) {
            active = false;
            selectedNodeId = null;
            selectedOutput = null;
        }
        invalidate();
    }

    private void computeLayout() {
        if (nodes.isEmpty()) return;
        Map<String, Integer> indegree = new HashMap<>();
        Map<String, List<String>> outgoing = new HashMap<>();
        for (NodeData n : nodes) {
            indegree.put(n.id, 0);
            outgoing.put(n.id, new ArrayList<String>());
            n.depth = -1;
        }
        for (EdgeData e : edges) {
            if (indegree.containsKey(e.to)) indegree.put(e.to, indegree.get(e.to) + 1);
            List<String> out = outgoing.get(e.from);
            if (out != null) out.add(e.to);
        }

        ArrayDeque<String> queue = new ArrayDeque<>();
        for (NodeData n : nodes) {
            if (indegree.get(n.id) == 0) {
                n.depth = 0;
                queue.add(n.id);
            }
        }
        if (queue.isEmpty()) {
            nodes.get(0).depth = 0;
            queue.add(nodes.get(0).id);
        }
        Set<String> visited = new HashSet<>();
        while (!queue.isEmpty()) {
            String id = queue.removeFirst();
            if (!visited.add(id)) continue;
            NodeData current = nodeById.get(id);
            List<String> out = outgoing.get(id);
            if (current == null || out == null) continue;
            for (String to : out) {
                NodeData child = nodeById.get(to);
                if (child == null) continue;
                if (child.depth < 0) child.depth = current.depth + 1;
                if (!visited.contains(to)) queue.addLast(to);
            }
        }
        int maxDepth = 0;
        for (NodeData n : nodes) {
            if (n.depth < 0) n.depth = maxDepth + 1;
            maxDepth = Math.max(maxDepth, n.depth);
        }

        Map<Integer, List<NodeData>> levels = new HashMap<>();
        for (NodeData n : nodes) {
            List<NodeData> list = levels.get(n.depth);
            if (list == null) {
                list = new ArrayList<>();
                levels.put(n.depth, list);
            }
            list.add(n);
        }

        float nodeW = dp(170);
        float nodeH = dp(112);
        float hGap = dp(30);
        float vGap = dp(58);
        int maxPerLevel = 1;
        for (List<NodeData> list : levels.values()) maxPerLevel = Math.max(maxPerLevel, list.size());
        contentWidth = Math.max(dp(400), maxPerLevel * nodeW + (maxPerLevel - 1) * hGap + dp(70));
        contentHeight = Math.max(dp(500), (maxDepth + 1) * nodeH + maxDepth * vGap + dp(80));

        for (int d = 0; d <= maxDepth; d++) {
            List<NodeData> list = levels.get(d);
            if (list == null) continue;
            float rowW = list.size() * nodeW + (list.size() - 1) * hGap;
            float startX = (contentWidth - rowW) / 2f;
            float baseY = dp(28) + d * (nodeH + vGap);
            for (int i = 0; i < list.size(); i++) {
                NodeData n = list.get(i);
                float x = startX + i * (nodeW + hGap);
                float y = baseY;
                if (n.hasStoredPosition) {
                    x = dp(n.storedX);
                    y = dp(n.storedY);
                }
                n.rect.set(x, y, x + nodeW, y + nodeH);
            }
        }
        recomputeContentBounds();
        layoutPorts();
    }

    private void recomputeContentBounds() {
        float maxR = dp(400);
        float maxB = dp(500);
        for (NodeData n : nodes) {
            maxR = Math.max(maxR, n.rect.right + dp(70));
            maxB = Math.max(maxB, n.rect.bottom + dp(70));
        }
        contentWidth = maxR;
        contentHeight = maxB;
    }

    private void layoutPorts() {
        for (NodeData n : nodes) {
            List<PortData> ins = new ArrayList<>();
            List<PortData> outs = new ArrayList<>();
            for (PortData p : n.ports) {
                if ("Output".equals(p.direction)) outs.add(p); else ins.add(p);
            }
            layoutPortSide(n, ins, false);
            layoutPortSide(n, outs, true);
        }
    }

    private void layoutPortSide(NodeData n, List<PortData> ports, boolean output) {
        if (ports.isEmpty()) return;
        float top = n.rect.top + dp(63);
        float bottom = n.rect.bottom - dp(14);
        float step = ports.size() == 1 ? 0f : (bottom - top) / (ports.size() - 1f);
        for (int i = 0; i < ports.size(); i++) {
            PortData p = ports.get(i);
            p.cx = output ? n.rect.right : n.rect.left;
            p.cy = ports.size() == 1 ? (top + bottom) / 2f : top + i * step;
        }
    }

    @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        fitToScreen();
    }

    public void fitToScreen() {
        if (getWidth() <= 0 || contentWidth <= 0) return;
        float sx = (getWidth() - dp(16)) / contentWidth;
        float sy = (getHeight() - dp(16)) / Math.max(contentHeight, dp(1));
        scale = clamp(Math.min(sx, sy), 0.48f, 1.05f);
        translateX = (getWidth() - contentWidth * scale) / 2f;
        translateY = dp(8);
        initialFitDone = true;
        invalidate();
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (!active || nodes.isEmpty()) {
            canvas.drawText("Runtime не инициализирован — нажми INIT", getWidth() / 2f, getHeight() / 2f, emptyPaint);
            return;
        }
        if (!initialFitDone) fitToScreen();

        canvas.save();
        canvas.translate(translateX, translateY);
        canvas.scale(scale, scale);
        drawEdges(canvas);
        drawNodes(canvas);
        canvas.restore();
    }

    private PortData findPort(NodeData node, String id) {
        if (node == null) return null;
        for (PortData p : node.ports) if (p.id.equals(id)) return p;
        return null;
    }

    private void drawEdges(Canvas canvas) {
        for (EdgeData e : edges) {
            NodeData a = nodeById.get(e.from);
            NodeData b = nodeById.get(e.to);
            if (a == null || b == null) continue;
            PortData ap = findPort(a, e.fromPort);
            PortData bp = findPort(b, e.toPort);
            float x1 = ap != null ? ap.cx : a.rect.centerX();
            float y1 = ap != null ? ap.cy : a.rect.bottom;
            float x2 = bp != null ? bp.cx : b.rect.centerX();
            float y2 = bp != null ? bp.cy : b.rect.top;
            boolean back = y2 <= y1 || x2 < x1 - dp(160);
            Path path = new Path();
            path.moveTo(x1, y1);
            if (!back) {
                float dy = Math.max(dp(34), Math.abs(y2 - y1) * 0.45f);
                path.cubicTo(x1 + dp(45), y1 + dy * 0.25f, x2 - dp(45), y2 - dy * 0.25f, x2, y2);
            } else {
                float side = Math.max(a.rect.right, b.rect.right) + dp(40);
                path.cubicTo(side, y1 + dp(18), side, y2 - dp(18), x2, y2);
            }
            canvas.drawPath(path, edgePaint);
            float mx = back ? Math.max(a.rect.right, b.rect.right) + dp(10) : (x1 + x2) / 2f;
            float my = (y1 + y2) / 2f - dp(4);
            if (e.eventType != null && !e.eventType.isEmpty()) canvas.drawText(shorten(e.eventType, 18), mx, my, edgeTextPaint);
        }
    }

    private void drawNodes(Canvas canvas) {
        for (NodeData n : nodes) {
            nodePaint.setColor(nodeFill(n));
            nodeStrokePaint.setColor(nodeStroke(n));
            canvas.drawRoundRect(n.rect, dp(12), dp(12), nodePaint);
            canvas.drawRoundRect(n.rect, dp(12), dp(12), nodeStrokePaint);
            if (n.id.equals(selectedNodeId)) canvas.drawRoundRect(n.rect, dp(12), dp(12), selectionPaint);

            float left = n.rect.left + dp(11);
            canvas.drawText(shorten(n.label, 23), left, n.rect.top + dp(20), titlePaint);
            canvas.drawText(n.type + "  c" + n.cost + "  p" + n.priority, left, n.rect.top + dp(38), metaPaint);
            String latest = (n.latestKind == null || n.latestKind.isEmpty()) ? "" : "last: " + n.latestKind;
            if (!latest.isEmpty()) canvas.drawText(shorten(latest, 28), left, n.rect.top + dp(54), metaPaint);

            float bx = n.rect.right - dp(12);
            float by = n.rect.top + dp(13);
            if (n.queued > 0) { drawBadge(canvas, bx, by, "Q" + n.queued, Color.rgb(68, 114, 196)); by += dp(18); }
            if (n.running > 0) { drawBadge(canvas, bx, by, "R" + n.running, Color.rgb(56, 142, 60)); by += dp(18); }
            if (n.suspended > 0) drawBadge(canvas, bx, by, "S" + n.suspended, Color.rgb(198, 119, 34));

            drawPorts(canvas, n);
        }
    }

    private void drawPorts(Canvas canvas, NodeData n) {
        for (PortData p : n.ports) {
            boolean output = "Output".equals(p.direction);
            boolean isSelected = selectedOutput != null && selectedOutput.node.id.equals(n.id) && selectedOutput.port.id.equals(p.id);
            boolean compatible = editMode && selectedOutput != null && !output && selectedOutput.port.eventType.equals(p.eventType);
            if (isSelected) portPaint.setColor(Color.rgb(245, 196, 66));
            else if (compatible) portPaint.setColor(Color.rgb(86, 181, 112));
            else portPaint.setColor(output ? Color.rgb(95, 145, 210) : Color.rgb(120, 126, 133));
            canvas.drawCircle(p.cx, p.cy, dp(5.2f), portPaint);
            canvas.drawCircle(p.cx, p.cy, dp(5.2f), portStrokePaint);
            float tx = output ? p.cx - dp(8) : p.cx + dp(8);
            portTextPaint.setTextAlign(output ? Paint.Align.RIGHT : Paint.Align.LEFT);
            canvas.drawText(shorten(p.name, 12), tx, p.cy + dp(2.5f), portTextPaint);
        }
    }

    private int nodeFill(NodeData n) {
        if (n.suspended > 0) return Color.rgb(79, 55, 39);
        if (n.running > 0) return Color.rgb(38, 75, 48);
        if (n.queued > 0) return Color.rgb(39, 58, 82);
        if ("Commit".equals(n.type) && "Committed".equals(stop)) return Color.rgb(38, 72, 48);
        return Color.rgb(48, 52, 57);
    }

    private int nodeStroke(NodeData n) {
        if (n.suspended > 0) return Color.rgb(232, 152, 72);
        if (n.running > 0) return Color.rgb(103, 190, 113);
        if (n.queued > 0) return Color.rgb(100, 149, 237);
        return Color.rgb(104, 116, 128);
    }

    private void drawBadge(Canvas canvas, float cx, float cy, String text, int color) {
        badgePaint.setColor(color);
        float r = dp(10);
        canvas.drawCircle(cx, cy, r, badgePaint);
        Paint.FontMetrics fm = badgeTextPaint.getFontMetrics();
        float y = cy - (fm.ascent + fm.descent) / 2f;
        canvas.drawText(text, cx, y, badgeTextPaint);
    }

    private NodeData hitNode(float screenX, float screenY) {
        float gx = (screenX - translateX) / scale;
        float gy = (screenY - translateY) / scale;
        for (int i = nodes.size() - 1; i >= 0; i--) if (nodes.get(i).rect.contains(gx, gy)) return nodes.get(i);
        return null;
    }

    private PortHit hitPort(float screenX, float screenY) {
        float radius = dp(22);
        for (NodeData n : nodes) {
            for (PortData p : n.ports) {
                float sx = translateX + p.cx * scale;
                float sy = translateY + p.cy * scale;
                float dx = sx - screenX;
                float dy = sy - screenY;
                if (dx * dx + dy * dy <= radius * radius) {
                    PortHit h = new PortHit();
                    h.node = n;
                    h.port = p;
                    return h;
                }
            }
        }
        return null;
    }

    private void handlePortTap(PortHit hit) {
        if (!editMode || hit == null) return;
        if ("Output".equals(hit.port.direction)) {
            if (selectedOutput != null && selectedOutput.node.id.equals(hit.node.id) && selectedOutput.port.id.equals(hit.port.id)) {
                selectedOutput = null;
                tell("Связь: выбор OUT отменён");
            } else {
                selectedOutput = hit;
                tell("OUT выбран: " + hit.node.id + "." + hit.port.id + " : " + hit.port.eventType + " → выбери совместимый IN");
            }
            invalidate();
            return;
        }
        if (selectedOutput == null) {
            tell("Сначала выбери OUT-порт, затем IN-порт");
            return;
        }
        if (!selectedOutput.port.eventType.equals(hit.port.eventType)) {
            tell("TYPE MISMATCH: " + selectedOutput.port.eventType + " != " + hit.port.eventType);
            return;
        }
        if (listener != null) {
            listener.onConnect(selectedOutput.node.id, selectedOutput.port.id, hit.node.id, hit.port.id);
        }
        selectedOutput = null;
        invalidate();
    }

    private void tell(String message) {
        if (listener != null) listener.onEditorMessage(message);
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        scaleDetector.onTouchEvent(event);
        if (event.getPointerCount() > 1) {
            panning = false;
            draggedNode = null;
            downPort = null;
            return true;
        }
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = lastX = event.getX();
                downY = lastY = event.getY();
                moved = false;
                downPort = editMode ? hitPort(event.getX(), event.getY()) : null;
                if (downPort != null) return true;
                if (editMode) {
                    draggedNode = hitNode(event.getX(), event.getY());
                    if (draggedNode != null) {
                        selectedNodeId = draggedNode.id;
                        invalidate();
                        return true;
                    }
                }
                panning = true;
                return true;

            case MotionEvent.ACTION_MOVE:
                if (scaleDetector.isInProgress()) return true;
                float x = event.getX();
                float y = event.getY();
                if (Math.abs(x - downX) + Math.abs(y - downY) > dp(6)) moved = true;
                if (draggedNode != null && editMode) {
                    float dx = (x - lastX) / scale;
                    float dy = (y - lastY) / scale;
                    draggedNode.rect.offset(dx, dy);
                    draggedNode.rect.offsetTo(Math.max(0, draggedNode.rect.left), Math.max(0, draggedNode.rect.top));
                    layoutPorts();
                    recomputeContentBounds();
                } else if (panning) {
                    translateX += x - lastX;
                    translateY += y - lastY;
                }
                lastX = x;
                lastY = y;
                invalidate();
                return true;

            case MotionEvent.ACTION_UP:
                if (downPort != null && !moved) {
                    handlePortTap(downPort);
                    downPort = null;
                    return true;
                }
                if (draggedNode != null) {
                    NodeData n = draggedNode;
                    draggedNode = null;
                    if (moved) {
                        if (listener != null) listener.onNodeMoved(n.id, n.rect.left / density(), n.rect.top / density());
                    } else {
                        selectedNodeId = n.id;
                        if (listener != null) listener.onNodeSelected(n.id, n.label, n.type);
                    }
                    invalidate();
                    return true;
                }
                if (!moved && editMode) {
                    NodeData n = hitNode(event.getX(), event.getY());
                    if (n == null) {
                        selectedNodeId = null;
                        selectedOutput = null;
                        tell("Выбор снят");
                        invalidate();
                    }
                }
                panning = false;
                return true;

            case MotionEvent.ACTION_CANCEL:
                panning = false;
                draggedNode = null;
                downPort = null;
                return true;
            default:
                return true;
        }
    }

    public String compactSummary() {
        if (!active) return "runtime: не инициализирован";
        return graphId + " r" + graphRevision + "   iter " + iteration + "   resource " + spent + "/" + totalBudget +
                "   осталось " + remaining + "   stop " + stop + (editMode ? "   EDIT" : "");
    }

    private float density() { return getResources().getDisplayMetrics().density; }
    private float dp(float value) { return value * density(); }
    private static float clamp(float v, float min, float max) { return Math.max(min, Math.min(max, v)); }
    private static String shorten(String s, int max) {
        if (s == null) return "";
        if (s.length() <= max) return s;
        return s.substring(0, Math.max(1, max - 1)) + "…";
    }
}
