# FIELD TEST — TMC 0.2.1-graph-editor-v01

## A. Upgrade / restore

Установить поверх 0.2.0. Старый SQLite runtime должен открыться без сброса. Старый checkpoint не содержит layout-поля — Rust должен принять его через `serde(default)`.

Для чистого editor-теста выполнить в консоли:

```text
runtime reset
runtime init demo
runtime validate
```

Ожидается:

```text
VALID graph=demo-resource-graph revision=3 nodes=6 edges=8
```

## B. Drag + durable layout

1. Открыть ГРАФ.
2. Нажать `РЕДАКТОР` → `EDIT: ВКЛ`.
3. Перетащить, например, Counter Check.
4. Закрыть приложение полностью и открыть снова.

Узел должен остаться в новой позиции. SQLite `storage verify` должен оставаться VALID.

## C. Add Node

До `runtime emit` нажать `+ УЗЕЛ` → `SemanticCheck`.

Ожидается новый `n-user-*` узел. В консоли `runtime validate`:

```text
nodes=7 edges=8
```

В `runtime events` должен быть `GraphNodeAdded`.

## D. Typed connection пальцем

В EDIT:

1. тапнуть OUT `claim` у Claim Input;
2. тапнуть IN `claim` нового SemanticCheck.

Ожидается новый Edge. `runtime validate`:

```text
nodes=7 edges=9
```

`runtime events` содержит `GraphEdgeAdded`.

Проверка type guard: OUT `result` SemanticCheck нельзя соединить с IN `stable` Commit; UI должен показать `TYPE MISMATCH` и Edge не создаётся.

## E. Runtime через изменённый Graph

После успешного Input → user SemanticCheck:

```text
runtime emit claim <editor test>
runtime queue
```

Контрольная точка:

```text
routed=3 newly_queued=3
```

На графе queued badge должен быть у исходных Semantic/Counter и у нового SemanticCheck.

Затем:

```text
runtime run
runtime ledger
storage verify
```

При только дополнительной dangling SemanticCheck ожидается commit основной ветки и общий расход 19 (17 базовых + 2 дополнительной проверки), если topology не менялась дополнительно.

## F. Topology lock

После `runtime emit claim` попытка `+ УЗЕЛ` должна быть отклонена сообщением о topology lock. Перемещение существующего Node при этом должно продолжать сохранять layout.
