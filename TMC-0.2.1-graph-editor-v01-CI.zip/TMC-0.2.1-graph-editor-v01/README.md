# TMC 0.2.1-graph-editor-v01

Первый редактируемый Graph UI поверх Rust SQLite event-runtime.

## Что добавлено

- Graph Viewer переведён в VIEW / EDIT режимы.
- Узлы можно перемещать пальцем; layout хранится в Rust GraphState и SQLite checkpoint.
- Узлы показывают реальные typed ports из Rust `uiSnapshot()`.
- Соединение на телефоне: тап OUT-порта → тап совместимого IN-порта.
- Несовместимый event type блокируется до изменения Graph.
- Для `PortCardinality::One` второй incoming Edge отклоняется.
- Палитра `+ УЗЕЛ`: SemanticCheck, CounterCheck, Compare, Revision, Commit.
- Пользовательские узлы получают id `n-user-*`.
- Удаление пользовательского узла удаляет также его edges.
- `AUTO` сбрасывает ручные позиции и возвращает auto-layout.
- Структурные Graph edits пишут audit events `GraphNodeAdded`, `GraphEdgeAdded`, `GraphNodeRemoved`, `GraphEdgeRemoved`.
- Структурное редактирование блокируется после начала вычисления; перемещение/layout остаётся разрешённым.

## Rust commands

```text
graph node add <type>
graph node remove <n-user-id>
graph edge add <from-node>.<from-port> <to-node>.<to-port>
graph edge remove <edge-id>
graph layout set <node-id> <x> <y>
graph layout clear
```

Текущий resource runtime, SQLite EventLog, batch console, typed-operator и dispute core сохранены.

## Архитектурная граница

Android GraphView не изменяет topology локально как источник истины. Любой structural edit проходит через JNI command в Rust; после ответа UI заново читает `uiSnapshot()`.
