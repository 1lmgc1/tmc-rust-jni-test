package io.typedcalculus.console;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public final class MainActivity extends Activity {
    private static final String VERSION = "0.1.7-ru-v02";
    private TextView output;
    private EditText input;
    private ScrollView scroll;
    private SharedPreferences prefs;
    private boolean nativeReady;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
        prefs = getSharedPreferences("tmc", MODE_PRIVATE);
        printGreeting();
        try {
            NativeBridge.load();
            nativeReady = true;
            String saved = prefs.getString("rust_state_json_v2", null);
            if (saved != null && !saved.isEmpty()) {
                boolean ok = NativeBridge.importState(saved);
                println(ok ? "Состояние восстановлено [content-v2]" : "Состояние не принято [content-v2]");
            }
            printExpectation();
        } catch (Throwable t) {
            println("ОШИБКА NATIVE: " + t.getClass().getSimpleName() + ": " + t.getMessage());
        }
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(8), dp(8), dp(8), dp(8));
        root.setBackgroundColor(Color.rgb(46,46,46));

        scroll = new ScrollView(this);
        output = new TextView(this);
        output.setTextColor(Color.LTGRAY);
        output.setTextSize(17f);
        output.setGravity(Gravity.START);
        output.setTextIsSelectable(true);
        scroll.addView(output, new ScrollView.LayoutParams(-1,-2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1f));

        input = new EditText(this);
        input.setHint("> команда");
        input.setSingleLine(true);
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(Color.LTGRAY);
        input.setImeOptions(EditorInfo.IME_ACTION_SEND);
        root.addView(input, new LinearLayout.LayoutParams(-1,-2));

        Button send = new Button(this);
        send.setText("ВВОД");
        root.addView(send, new LinearLayout.LayoutParams(-1,-2));
        send.setOnClickListener(v -> dispatch());
        input.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                dispatch(); return true;
            }
            return false;
        });
        setContentView(root);
    }

    private void printGreeting() {
        println(" /\\_/\\ ");
        println("( o.o )   TMC " + VERSION);
        println(" > ^ <    Java host / Rust content core / Android 14 arm64");
        println("");
        println(" /\\_/\\   /\\_/\\ ");
        println("( =^.^= ) ( =^.^= )");
        println("(\")_(\") (\")_(\")");
        println("");
        println("Привет. Это консоль калькулятора коллизий и фиксации модели.");
        println("Как работать кратко:");
        println("1) Набери help, чтобы увидеть команды и синтаксис.");
        println("2) Иди по строке 'Ожидаю: ...' шаг за шагом.");
        println("3) Сначала создай debate, затем задай resolution, collision, function и criterion.");
        println("4) После commit используй model audit / model status / model revise / model concede.");
        println("");
    }

    private void dispatch() {
        String cmd = input.getText().toString().trim();
        input.setText("");
        if (cmd.isEmpty()) return;
        println("> " + cmd);
        if (!nativeReady) { println("native core недоступно"); return; }
        try {
            String response = NativeBridge.command(cmd);
            if (response != null && !response.isEmpty()) println(response);
            saveState();
        } catch (Throwable t) {
            println("ОШИБКА: " + t.getClass().getSimpleName() + ": " + t.getMessage());
        }
        printExpectation();
    }

    private void saveState() {
        String data = NativeBridge.exportState();
        if (data != null) prefs.edit().putString("rust_state_json_v2", data).apply();
    }

    private void printExpectation() {
        if (!nativeReady) return;
        String e = NativeBridge.expectation();
        println("Ожидаю: " + e);
    }

    private void println(String s) {
        output.append(s); output.append("\n");
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }
}
