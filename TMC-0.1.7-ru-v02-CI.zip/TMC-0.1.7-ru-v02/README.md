# TMC 0.1.7-ru-v02

Русифицированный патч поверх 0.1.6-content-v01.

Что изменено:
- интерфейс приветствия на русском;
- ASCII art приветствие с котиками;
- краткое описание работы на стартовом экране;
- развёрнутая русская команда `help`;
- русские системные сообщения и ошибки;
- сохранена прежняя командная поверхность calculus/dispute-v0;
- приложение ставится поверх 0.1.6 той же CI-ветки.

Команды остаются англоязычными:
- `debate new <name>`
- `resolution <text>`
- `collision open <A> | <B>`
- `function accept <function/context>`
- `criterion accept <criterion>`
- `commit`
- `model audit`
- `model status`
- `model revise <text>`
- `model concede <target> | <reason>`

Дополнительные русские aliases:
- `помощь`
- `версия`
- `версия системы`
- `состояние`
- `состояние системы`
