# FIELD TEST — TMC 0.2.0-graph-viewer-v01

## 1. Запуск поверх 0.1.13

После обновления приложение должно открыть вкладку `ГРАФ`.
Если runtime уже сохранён в SQLite, graph должен появиться без `runtime init demo`.

Проверить telemetry: graph/revision, iteration, resource spent/total, remaining, stop.

## 2. Новый runtime

Если граф пуст:

- нажать `INIT`;
- graph должен показать 6 Nodes:
  - Claim Input
  - Semantic Check
  - Counter Check
  - Compare / Join
  - Revision
  - Commit
- должны быть видны 8 Edges, включая обратные Revision → Checks.

## 3. Runtime badges

В КОНСОЛИ выполнить пакет:

runtime reset
runtime init demo
runtime emit claim <graph viewer test>

Вернуться в ГРАФ.
Ожидается: Semantic Check и Counter Check имеют queued badges.

Нажать `STEP` один раз.
Ожидается: первый check Completed, у второго остаётся queued badge; telemetry resource увеличивается на 2.

Нажать `RUN`.
Ожидается: цикл заканчивается Commit, iteration=1, resource=17/30, stop=Committed.

## 4. Навигация

- pinch zoom работает;
- drag одним пальцем панорамирует;
- `ВПИСАТЬ` возвращает весь graph в экран.

## 5. Подробные представления

Кнопки `ОЧЕРЕДЬ`, `СОБЫТИЯ`, `РЕСУРС` должны открыть КОНСОЛЬ и показать соответствующий Rust output.

## 6. Persistence regression

Закрыть приложение, открыть снова. ГРАФ должен восстановиться из SQLite с теми же runtime/telemetry данными.

## 7. Batch-console regression

Во вкладке КОНСОЛЬ вставить несколько команд строками и выполнить одним пакетом. Поведение 0.1.13 должно сохраниться.
