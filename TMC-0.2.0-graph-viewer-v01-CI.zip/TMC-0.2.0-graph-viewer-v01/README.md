# TMC 0.2.0-graph-viewer-v01

Первый визуальный интерфейс поверх уже работающего Rust event/resource runtime.

## Что изменилось

- ГРАФ становится основным экраном приложения.
- КОНСОЛЬ сохранена отдельной вкладкой и остаётся пакетной/диагностической.
- Rust остаётся source of truth; Java GraphView получает только read-only JSON projection через JNI `uiSnapshot()`.
- На графе видны Nodes, Edges, типы событий, cost/priority и runtime badges очереди/исполнения/suspend.
- Верхняя telemetry показывает graph revision, iteration, resource spent/remaining и stop reason.
- Есть управление `INIT`, `STEP`, `RUN`, `ОБНОВИТЬ`, `ВПИСАТЬ`.
- Кнопки `ОЧЕРЕДЬ`, `СОБЫТИЯ`, `РЕСУРС` выполняют соответствующую Rust-команду и открывают консоль для подробного вывода.
- GraphView поддерживает pan одним пальцем и pinch zoom.
- Существующие SQLite EventLog, WorkQueue, ResourceLedger, batch console, typed/dispute команды сохранены.

## Текущий статус интерфейса

Это viewer, не editor. Topology пока нельзя редактировать пальцем. Это намеренно: сначала проверяется читаемость визуального языка и связь UI с Rust runtime, затем будет добавлен graph editor.
