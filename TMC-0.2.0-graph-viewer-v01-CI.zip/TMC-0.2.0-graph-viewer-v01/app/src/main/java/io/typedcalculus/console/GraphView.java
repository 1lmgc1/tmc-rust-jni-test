package io.typedcalculus.console;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Read-only semantic graph viewer for the first visual TMC runtime.
 * Rust remains the source of truth; this View only projects uiSnapshot().
 */
public final class GraphView extends View {
    private static final class NodeData {
        String id;
        String label;
        String type;
        int cost;
        int priority;
        int queued;
        int running;
        int suspended;
        int completed;
        String latestKind;
        RectF rect = new RectF();
        int depth;
    }

    private static final class EdgeData {
        String from;
        String to;
        String eventType;
    }

    private final Paint edgePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint edgeTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint nodePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint nodeStrokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint titlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint metaPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint badgePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint badgeTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint emptyPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private final List<NodeData> nodes = new ArrayList<>();
    private final List<EdgeData> edges = new ArrayList<>();
    private final Map<String, NodeData> nodeById = new HashMap<>();

    private boolean active;
    private String graphId = "";
    private int graphRevision;
    private String stop = "<none>";
    private int iteration;
    private int totalBudget;
    private int spent;
    private int remaining;

    private float scale = 1f;
    private float translateX = 0f;
    private float translateY = 0f;
    private float lastX;
    private float lastY;
    private boolean dragging;
    private boolean initialFitDone;
    private final ScaleGestureDetector scaleDetector;

    private float contentWidth;
    private float contentHeight;

    public GraphView(Context context) {
        this(context, null);
    }

    public GraphView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setBackgroundColor(Color.rgb(27, 29, 31));

        edgePaint.setColor(Color.rgb(108, 118, 128));
        edgePaint.setStyle(Paint.Style.STROKE);
        edgePaint.setStrokeWidth(dp(1.5f));

        edgeTextPaint.setColor(Color.rgb(156, 166, 176));
        edgeTextPaint.setTextSize(dp(9));

        nodePaint.setColor(Color.rgb(48, 52, 57));
        nodePaint.setStyle(Paint.Style.FILL);

        nodeStrokePaint.setColor(Color.rgb(104, 116, 128));
        nodeStrokePaint.setStyle(Paint.Style.STROKE);
        nodeStrokePaint.setStrokeWidth(dp(1.3f));

        titlePaint.setColor(Color.WHITE);
        titlePaint.setTextSize(dp(13));
        titlePaint.setFakeBoldText(true);

        metaPaint.setColor(Color.rgb(192, 199, 206));
        metaPaint.setTextSize(dp(9.5f));

        badgePaint.setStyle(Paint.Style.FILL);
        badgeTextPaint.setColor(Color.WHITE);
        badgeTextPaint.setTextSize(dp(8.5f));
        badgeTextPaint.setTextAlign(Paint.Align.CENTER);
        badgeTextPaint.setFakeBoldText(true);

        emptyPaint.setColor(Color.rgb(180, 186, 192));
        emptyPaint.setTextSize(dp(15));
        emptyPaint.setTextAlign(Paint.Align.CENTER);

        scaleDetector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector detector) {
                float old = scale;
                scale = clamp(scale * detector.getScaleFactor(), 0.45f, 2.4f);
                float fx = detector.getFocusX();
                float fy = detector.getFocusY();
                if (old != 0f) {
                    float ratio = scale / old;
                    translateX = fx - (fx - translateX) * ratio;
                    translateY = fy - (fy - translateY) * ratio;
                }
                invalidate();
                return true;
            }
        });
    }

    public void setSnapshot(String json) {
        nodes.clear();
        edges.clear();
        nodeById.clear();
        active = false;
        initialFitDone = false;
        try {
            JSONObject root = new JSONObject(json == null ? "{}" : json);
            active = root.optBoolean("active", false);
            if (!active) {
                invalidate();
                return;
            }
            JSONObject graph = root.getJSONObject("graph");
            graphId = graph.optString("id", "graph");
            graphRevision = graph.optInt("revision", 0);
            JSONArray nodeArray = graph.optJSONArray("nodes");
            if (nodeArray != null) {
                for (int i = 0; i < nodeArray.length(); i++) {
                    JSONObject j = nodeArray.getJSONObject(i);
                    NodeData n = new NodeData();
                    n.id = j.optString("id");
                    n.label = j.optString("label", n.id);
                    n.type = j.optString("type", "Node");
                    n.cost = j.optInt("estimated_cost", 0);
                    n.priority = j.optInt("priority", 0);
                    n.queued = j.optInt("queued", 0);
                    n.running = j.optInt("running", 0);
                    n.suspended = j.optInt("suspended", 0);
                    n.completed = j.optInt("completed", 0);
                    n.latestKind = j.optString("latest_event_kind", "");
                    nodes.add(n);
                    nodeById.put(n.id, n);
                }
            }
            JSONArray edgeArray = graph.optJSONArray("edges");
            if (edgeArray != null) {
                for (int i = 0; i < edgeArray.length(); i++) {
                    JSONObject j = edgeArray.getJSONObject(i);
                    EdgeData e = new EdgeData();
                    e.from = j.optString("from_node");
                    e.to = j.optString("to_node");
                    e.eventType = j.optString("event_type", "");
                    edges.add(e);
                }
            }
            JSONObject runtime = root.optJSONObject("runtime");
            if (runtime != null) {
                iteration = runtime.optInt("iteration", 0);
                stop = runtime.isNull("stop") ? "<none>" : runtime.optString("stop", "<none>");
            }
            JSONObject resource = root.optJSONObject("resource");
            if (resource != null) {
                totalBudget = resource.optInt("total", 0);
                spent = resource.optInt("spent", 0);
                remaining = resource.optInt("remaining", 0);
            }
            computeLayout();
        } catch (Throwable ignored) {
            active = false;
        }
        invalidate();
    }

    private void computeLayout() {
        if (nodes.isEmpty()) return;
        Map<String, Integer> indegree = new HashMap<>();
        Map<String, List<String>> outgoing = new HashMap<>();
        for (NodeData n : nodes) {
            indegree.put(n.id, 0);
            outgoing.put(n.id, new ArrayList<String>());
            n.depth = -1;
        }
        for (EdgeData e : edges) {
            if (indegree.containsKey(e.to)) indegree.put(e.to, indegree.get(e.to) + 1);
            List<String> out = outgoing.get(e.from);
            if (out != null) out.add(e.to);
        }

        ArrayDeque<String> queue = new ArrayDeque<>();
        for (NodeData n : nodes) {
            if (indegree.get(n.id) == 0) {
                n.depth = 0;
                queue.add(n.id);
            }
        }
        if (queue.isEmpty()) {
            nodes.get(0).depth = 0;
            queue.add(nodes.get(0).id);
        }
        Set<String> visited = new HashSet<>();
        while (!queue.isEmpty()) {
            String id = queue.removeFirst();
            if (!visited.add(id)) continue;
            NodeData current = nodeById.get(id);
            List<String> out = outgoing.get(id);
            if (current == null || out == null) continue;
            for (String to : out) {
                NodeData child = nodeById.get(to);
                if (child == null) continue;
                if (child.depth < 0) child.depth = current.depth + 1;
                if (!visited.contains(to)) queue.addLast(to);
            }
        }
        int maxDepth = 0;
        for (NodeData n : nodes) {
            if (n.depth < 0) n.depth = maxDepth + 1;
            maxDepth = Math.max(maxDepth, n.depth);
        }

        Map<Integer, List<NodeData>> levels = new HashMap<>();
        for (NodeData n : nodes) {
            List<NodeData> list = levels.get(n.depth);
            if (list == null) {
                list = new ArrayList<>();
                levels.put(n.depth, list);
            }
            list.add(n);
        }

        float nodeW = dp(150);
        float nodeH = dp(82);
        float hGap = dp(24);
        float vGap = dp(66);
        int maxPerLevel = 1;
        for (List<NodeData> list : levels.values()) maxPerLevel = Math.max(maxPerLevel, list.size());
        contentWidth = Math.max(dp(360), maxPerLevel * nodeW + (maxPerLevel - 1) * hGap + dp(48));
        contentHeight = (maxDepth + 1) * nodeH + maxDepth * vGap + dp(48);

        for (int d = 0; d <= maxDepth; d++) {
            List<NodeData> list = levels.get(d);
            if (list == null) continue;
            float rowW = list.size() * nodeW + (list.size() - 1) * hGap;
            float startX = (contentWidth - rowW) / 2f;
            float y = dp(24) + d * (nodeH + vGap);
            for (int i = 0; i < list.size(); i++) {
                float x = startX + i * (nodeW + hGap);
                list.get(i).rect.set(x, y, x + nodeW, y + nodeH);
            }
        }
    }

    @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        fitToScreen();
    }

    public void fitToScreen() {
        if (getWidth() <= 0 || contentWidth <= 0) return;
        float sx = (getWidth() - dp(16)) / contentWidth;
        float sy = (getHeight() - dp(16)) / Math.max(contentHeight, dp(1));
        scale = clamp(Math.min(sx, sy), 0.55f, 1.05f);
        translateX = (getWidth() - contentWidth * scale) / 2f;
        translateY = dp(8);
        initialFitDone = true;
        invalidate();
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (!active || nodes.isEmpty()) {
            canvas.drawText("Runtime не инициализирован — нажми INIT", getWidth() / 2f, getHeight() / 2f, emptyPaint);
            return;
        }
        if (!initialFitDone) fitToScreen();

        canvas.save();
        canvas.translate(translateX, translateY);
        canvas.scale(scale, scale);

        drawEdges(canvas);
        drawNodes(canvas);

        canvas.restore();
    }

    private void drawEdges(Canvas canvas) {
        for (EdgeData e : edges) {
            NodeData a = nodeById.get(e.from);
            NodeData b = nodeById.get(e.to);
            if (a == null || b == null) continue;
            float x1 = a.rect.centerX();
            float y1 = a.rect.bottom;
            float x2 = b.rect.centerX();
            float y2 = b.rect.top;
            boolean back = y2 <= y1;
            Path p = new Path();
            p.moveTo(x1, y1);
            if (!back) {
                float mid = (y1 + y2) / 2f;
                p.cubicTo(x1, mid, x2, mid, x2, y2);
            } else {
                float side = Math.max(a.rect.right, b.rect.right) + dp(35);
                p.cubicTo(side, y1 + dp(24), side, y2 - dp(24), x2, y2);
            }
            canvas.drawPath(p, edgePaint);
            float mx = back ? Math.max(a.rect.right, b.rect.right) + dp(10) : (x1 + x2) / 2f;
            float my = back ? (y1 + y2) / 2f : (y1 + y2) / 2f - dp(4);
            if (e.eventType != null && !e.eventType.isEmpty()) {
                canvas.drawText(shorten(e.eventType, 20), mx, my, edgeTextPaint);
            }
        }
    }

    private void drawNodes(Canvas canvas) {
        for (NodeData n : nodes) {
            nodePaint.setColor(nodeFill(n));
            nodeStrokePaint.setColor(nodeStroke(n));
            canvas.drawRoundRect(n.rect, dp(12), dp(12), nodePaint);
            canvas.drawRoundRect(n.rect, dp(12), dp(12), nodeStrokePaint);

            float left = n.rect.left + dp(10);
            canvas.drawText(shorten(n.label, 22), left, n.rect.top + dp(21), titlePaint);
            canvas.drawText(n.type + "  cost " + n.cost + "  p" + n.priority,
                    left, n.rect.top + dp(40), metaPaint);
            String latest = (n.latestKind == null || n.latestKind.isEmpty()) ? "" : "last: " + n.latestKind;
            if (!latest.isEmpty()) canvas.drawText(shorten(latest, 27), left, n.rect.top + dp(57), metaPaint);

            float bx = n.rect.right - dp(11);
            float by = n.rect.top + dp(13);
            if (n.queued > 0) {
                drawBadge(canvas, bx, by, "Q" + n.queued, Color.rgb(68, 114, 196));
                by += dp(17);
            }
            if (n.running > 0) {
                drawBadge(canvas, bx, by, "R" + n.running, Color.rgb(56, 142, 60));
                by += dp(17);
            }
            if (n.suspended > 0) {
                drawBadge(canvas, bx, by, "S" + n.suspended, Color.rgb(198, 119, 34));
            }
        }
    }

    private int nodeFill(NodeData n) {
        if (n.suspended > 0) return Color.rgb(79, 55, 39);
        if (n.running > 0) return Color.rgb(38, 75, 48);
        if (n.queued > 0) return Color.rgb(39, 58, 82);
        if ("Commit".equals(n.type) && "Committed".equals(stop)) return Color.rgb(38, 72, 48);
        return Color.rgb(48, 52, 57);
    }

    private int nodeStroke(NodeData n) {
        if (n.suspended > 0) return Color.rgb(232, 152, 72);
        if (n.running > 0) return Color.rgb(103, 190, 113);
        if (n.queued > 0) return Color.rgb(100, 149, 237);
        return Color.rgb(104, 116, 128);
    }

    private void drawBadge(Canvas canvas, float cx, float cy, String text, int color) {
        badgePaint.setColor(color);
        float r = dp(10);
        canvas.drawCircle(cx, cy, r, badgePaint);
        Paint.FontMetrics fm = badgeTextPaint.getFontMetrics();
        float y = cy - (fm.ascent + fm.descent) / 2f;
        canvas.drawText(text, cx, y, badgeTextPaint);
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        scaleDetector.onTouchEvent(event);
        if (event.getPointerCount() > 1) {
            dragging = false;
            return true;
        }
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                lastX = event.getX();
                lastY = event.getY();
                dragging = true;
                return true;
            case MotionEvent.ACTION_MOVE:
                if (dragging && !scaleDetector.isInProgress()) {
                    float x = event.getX();
                    float y = event.getY();
                    translateX += x - lastX;
                    translateY += y - lastY;
                    lastX = x;
                    lastY = y;
                    invalidate();
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                dragging = false;
                return true;
            default:
                return true;
        }
    }

    public String compactSummary() {
        if (!active) return "runtime: не инициализирован";
        return graphId + " r" + graphRevision + "   iter " + iteration + "   resource " + spent + "/" + totalBudget +
                "   осталось " + remaining + "   stop " + stop;
    }

    private float dp(float value) {
        return value * getResources().getDisplayMetrics().density;
    }

    private static float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }

    private static String shorten(String s, int max) {
        if (s == null) return "";
        if (s.length() <= max) return s;
        return s.substring(0, Math.max(1, max - 1)) + "…";
    }
}
