# TMC 0.2.1-graph-editor-v05

Graph Editor поверх Rust SQLite event-runtime. Патч v05 добавляет reset/undo/redo и перерабатывает визуальную маршрутизацию графа.

## UI

- `СБРОС` выполняет `runtime reset` прямо с графа.
- `ОТМЕНИТЬ` / `ПОВТОРИТЬ` выполняют `graph undo` / `graph redo`.
- История GraphState: последние 6 изменений; хранится в Rust ModelState/SQLite checkpoint и не очищается `runtime reset`.
- После `runtime reset` `ОТМЕНИТЬ` может восстановить предыдущую topology/layout без обязательного `INIT`.
- Счётчики истории видны в telemetry: `↶undo/6 ↷redo`.
- Нижняя `ПАЛИТРА` сворачивается.
- Палитра функций подписана по-русски; Rust node types остаются прежними.

## Трубопровод

Связи больше не рисуются одной диагональю и не используют Bezier/spline routing.

- центр линии состоит только из горизонтальных/вертикальных участков;
- повороты оформлены круговыми `arcTo`-локтями;
- node rectangles считаются препятствиями;
- routing пробует свободные промежуточные lanes и внешний corridor;
- auto-layout оставляет увеличенные зазоры под трубы и подписи;
- пользовательский drag не позволяет положить один Node поверх другого;
- label размещается только в свободном месте и не рисуется поверх Node/другой подписи.

## История: что считается одним ходом

Один ход записывается перед успешным изменением GraphState:

- add/remove Node;
- add/remove Edge;
- перемещение Node (`graph layout set`);
- `AUTO` / `graph layout clear`.

Новый ход после undo очищает redo-ветку. Хранятся максимум 6 предыдущих GraphState.

## Rust commands

```text
graph node add <type>
graph node remove <n-user-id>
graph edge add <from-node>.<from-port> <to-node>.<to-port>
graph edge remove <edge-id>
graph layout set <node-id> <x> <y>
graph layout clear
graph undo
graph redo
graph history
runtime reset
```

Структурный undo/redo блокируется, пока есть вычислительные events/work items. `СБРОС` очищает runtime execution state, но оставляет шестиходовую историю и тем самым снова разрешает undo/redo.

## Сохранено

Rust остаётся источником истины. SQLite EventLog/resource runtime, batch console, typed-operator и dispute core не заменяются Java-состоянием.
