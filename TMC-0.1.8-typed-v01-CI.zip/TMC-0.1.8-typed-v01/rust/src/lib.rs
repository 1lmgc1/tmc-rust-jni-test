use jni::objects::{JClass, JString};
use jni::sys::{jboolean, jstring, JNI_FALSE, JNI_TRUE};
use jni::JNIEnv;
use serde::{Deserialize, Serialize};
use std::ptr;
use std::sync::{Mutex, OnceLock};

const VERSION: &str = "0.1.8-typed-v01";
const VERSION_CODE: u32 = 15;

#[derive(Debug, Clone, Serialize, Deserialize)]
struct RevisionRecord {
    note: String,
    previous_function_context: Option<String>,
    previous_criterion: Option<String>,
    previous_hash: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct ConcessionRecord {
    target: String,
    reason: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct DefinitionRecord {
    name: String,
    frame: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct BindingRecord {
    relation: String,
    value: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
struct ProjectState {
    active: bool,
    name: Option<String>,
    claim: Option<String>,
    operator: Option<String>,
    phase: u8,
    expected_concept_frame: Option<String>,
    expected_relation: Option<String>,
    result: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
struct ModelState {
    schema: u32,
    debate_name: Option<String>,
    resolution: Option<String>,
    collision_a: Option<String>,
    collision_b: Option<String>,
    function_context: Option<String>,
    criterion: Option<String>,
    committed: bool,
    step: u8,
    status_resource: u8,
    robustness: u8,
    revisions: Vec<RevisionRecord>,
    concessions: Vec<ConcessionRecord>,
    project: ProjectState,
    definitions: Vec<DefinitionRecord>,
    bindings: Vec<BindingRecord>,
}

impl Default for ModelState {
    fn default() -> Self {
        Self {
            schema: 2,
            debate_name: None,
            resolution: None,
            collision_a: None,
            collision_b: None,
            function_context: None,
            criterion: None,
            committed: false,
            step: 0,
            status_resource: 100,
            robustness: 100,
            revisions: Vec::new(),
            concessions: Vec::new(),
            project: ProjectState::default(),
            definitions: Vec::new(),
            bindings: Vec::new(),
        }
    }
}

static STATE: OnceLock<Mutex<ModelState>> = OnceLock::new();
fn state() -> &'static Mutex<ModelState> { STATE.get_or_init(|| Mutex::new(ModelState::default())) }

fn fnv1a64(bytes: &[u8]) -> u64 {
    let mut h = 0xcbf29ce484222325u64;
    for &b in bytes {
        h ^= b as u64;
        h = h.wrapping_mul(0x100000001b3);
    }
    h
}

#[derive(Serialize)]
struct DisputeHashState<'a> {
    schema: u32,
    debate_name: &'a Option<String>,
    resolution: &'a Option<String>,
    collision_a: &'a Option<String>,
    collision_b: &'a Option<String>,
    function_context: &'a Option<String>,
    criterion: &'a Option<String>,
    committed: bool,
    step: u8,
    status_resource: u8,
    robustness: u8,
    revisions: &'a Vec<RevisionRecord>,
    concessions: &'a Vec<ConcessionRecord>,
}

fn canonical_model_hash(s: &ModelState) -> String {
    let view = DisputeHashState {
        schema: s.schema,
        debate_name: &s.debate_name,
        resolution: &s.resolution,
        collision_a: &s.collision_a,
        collision_b: &s.collision_b,
        function_context: &s.function_context,
        criterion: &s.criterion,
        committed: s.committed,
        step: s.step,
        status_resource: s.status_resource,
        robustness: s.robustness,
        revisions: &s.revisions,
        concessions: &s.concessions,
    };
    let data = serde_json::to_vec(&view).unwrap_or_default();
    format!("{:016x}", fnv1a64(&data))
}

#[derive(Serialize)]
struct ProofHashState<'a> {
    project: &'a ProjectState,
    definitions: &'a Vec<DefinitionRecord>,
    bindings: &'a Vec<BindingRecord>,
}

fn canonical_proof_hash(s: &ModelState) -> String {
    let view = ProofHashState {
        project: &s.project,
        definitions: &s.definitions,
        bindings: &s.bindings,
    };
    let data = serde_json::to_vec(&view).unwrap_or_default();
    format!("{:016x}", fnv1a64(&data))
}

fn require_debate(s: &ModelState) -> Result<(), String> {
    if s.debate_name.is_none() { Err("ОШИБКА: debate ещё не создан".into()) } else { Ok(()) }
}

fn project_expectation(p: &ProjectState) -> Option<String> {
    if !p.active { return None; }
    Some(match p.phase {
        1 => "claim <name>".into(),
        2 => "run classify.exclude".into(),
        3 => "definition create functional".into(),
        4 => "bind follows_communist_principles <true|false>".into(),
        5 => "resume".into(),
        _ => "proof audit | project state | project reset".into(),
    })
}

fn expectation_for(s: &ModelState) -> String {
    if let Some(e) = project_expectation(&s.project) { return e; }
    match s.step {
        0 => "debate new <name> | project new <name>".into(),
        1 => "resolution <text>".into(),
        2 => "collision open <position-a> | <position-b>".into(),
        3 => "function accept <function/context>".into(),
        4 => "criterion accept <criterion>".into(),
        5 => "commit".into(),
        _ => "model audit | model status | model revise <text> | model concede <target> | <reason> | project new <name>".into(),
    }
}

fn help_text() -> String {
    [
        "=== TMC HELP / СПРАВКА ===",
        "",
        "ДВА РЕЖИМА:",
        "A) dispute-модель: формализация коллизии и фиксация frame",
        "B) typed-operator: операция, которая при нехватке данных останавливается, запрашивает их и затем resume",
        "",
        "--- A. DISPUTE ---",
        "1) debate new <name>",
        "2) resolution <text>",
        "3) collision open <position-a> | <position-b>",
        "4) function accept <function/context>",
        "5) criterion accept <criterion>",
        "6) commit",
        "после commit: model audit / model status / model revise <text> / model concede <target> | <reason>",
        "",
        "--- B. TYPED OPERATOR ---",
        "project new <name>             — создать проект вычисления",
        "claim <name>                   — задать объект/утверждение",
        "run classify.exclude           — запустить оператор исключающей классификации",
        "definition create functional   — создать локальный concept frame",
        "bind follows_communist_principles <true|false> — связать требуемое отношение со значением",
        "resume                         — продолжить приостановленную операцию",
        "proof audit                    — hash доказательного состояния",
        "project state                  — состояние typed-операции",
        "project reset                  — сбросить только текущий typed-проект",
        "",
        "Эталонный вертикальный сценарий:",
        "project new demo",
        "claim kpss",
        "run classify.exclude",
        "definition create functional",
        "bind follows_communist_principles false",
        "resume",
        "proof audit",
        "",
        "Смысл NEED_INPUT:",
        "оператор не угадывает отсутствующее значение. Он фиксирует, чего не хватает, приостанавливается и ждёт definition/bind. После этого команда resume продолжает ту же операцию.",
        "",
        "--- СИСТЕМА ---",
        "system version  — версия приложения и Rust-ядра",
        "system state    — dispute + typed состояние целиком",
        "system reset    — полный сброс обоих режимов и локальных значений",
        "help / помощь   — эта справка",
        "calc 7 + 5      — простая Rust-проверка",
        "",
        "Подсказки:",
        "— Следуй строке 'Ожидаю: ...'",
        "— Для collision и concede разделитель — вертикальная черта |",
        "— Команды остаются латиницей: русский язык используется в интерфейсе и пояснениях.",
    ].join("\n")
}

fn project_state_text(s: &ModelState) -> String {
    let p = &s.project;
    let mut out = Vec::new();
    out.push(format!("project.active={} phase={}", p.active, p.phase));
    out.push(format!("project.name={}", p.name.as_deref().unwrap_or("<none>")));
    out.push(format!("claim={}", p.claim.as_deref().unwrap_or("<none>")));
    out.push(format!("operator={}", p.operator.as_deref().unwrap_or("<none>")));
    out.push(format!("expected_concept_frame={}", p.expected_concept_frame.as_deref().unwrap_or("<none>")));
    out.push(format!("expected_relation={}", p.expected_relation.as_deref().unwrap_or("<none>")));
    out.push(format!("result={}", p.result.as_deref().unwrap_or("<none>")));
    out.push(format!("definitions={} bindings={}", s.definitions.len(), s.bindings.len()));
    for (i, d) in s.definitions.iter().enumerate() {
        out.push(format!("definition[{}]={} -> {}", i + 1, d.name, d.frame));
    }
    for (i, b) in s.bindings.iter().enumerate() {
        out.push(format!("binding[{}]={}={}", i + 1, b.relation, b.value));
    }
    out.join("\n")
}

fn system_state_text(s: &ModelState) -> String {
    let mut out = Vec::new();
    out.push("[DISPUTE]".into());
    out.push(format!("step={} committed={}", s.step, s.committed));
    out.push(format!("debate={}", s.debate_name.as_deref().unwrap_or("<none>")));
    out.push(format!("resolution={}", s.resolution.as_deref().unwrap_or("<none>")));
    out.push(format!("collision.a={}", s.collision_a.as_deref().unwrap_or("<none>")));
    out.push(format!("collision.b={}", s.collision_b.as_deref().unwrap_or("<none>")));
    out.push(format!("function_context={}", s.function_context.as_deref().unwrap_or("<none>")));
    out.push(format!("criterion={}", s.criterion.as_deref().unwrap_or("<none>")));
    out.push(format!(
        "status_resource={} robustness={} revisions={} concessions={}",
        s.status_resource, s.robustness, s.revisions.len(), s.concessions.len()
    ));
    for (i, r) in s.revisions.iter().enumerate() {
        out.push(format!("revision[{}].note={}", i + 1, r.note));
        out.push(format!("revision[{}].previous_hash={}", i + 1, r.previous_hash));
    }
    for (i, c) in s.concessions.iter().enumerate() {
        out.push(format!("concession[{}].target={}", i + 1, c.target));
        out.push(format!("concession[{}].reason={}", i + 1, c.reason));
    }
    out.push("[TYPED]".into());
    out.push(project_state_text(s));
    out.join("\n")
}

fn parse_binary(rest: &str) -> Result<(&str, &str), String> {
    let (a, b) = rest.split_once('|').ok_or_else(|| "НУЖЕН ВВОД: используйте форму <позиция-A> | <позиция-B>".to_string())?;
    let a = a.trim();
    let b = b.trim();
    if a.is_empty() || b.is_empty() { return Err("НУЖЕН ВВОД: обе части обязательны".into()); }
    Ok((a, b))
}

fn parse_bool(text: &str) -> Option<bool> {
    match text.trim().to_lowercase().as_str() {
        "true" | "1" | "yes" | "да" => Some(true),
        "false" | "0" | "no" | "нет" => Some(false),
        _ => None,
    }
}

fn definition_frame(name: &str) -> String {
    if name.eq_ignore_ascii_case("functional") {
        "communist-party:functional".into()
    } else {
        name.to_string()
    }
}

fn find_definition<'a>(s: &'a ModelState, name: &str) -> Option<&'a DefinitionRecord> {
    s.definitions.iter().rev().find(|d| d.name.eq_ignore_ascii_case(name))
}

fn find_binding<'a>(s: &'a ModelState, relation: &str) -> Option<&'a BindingRecord> {
    s.bindings.iter().rev().find(|b| b.relation.eq_ignore_ascii_case(relation))
}

fn reset_dispute(s: &mut ModelState) {
    s.debate_name = None;
    s.resolution = None;
    s.collision_a = None;
    s.collision_b = None;
    s.function_context = None;
    s.criterion = None;
    s.committed = false;
    s.step = 0;
    s.status_resource = 100;
    s.robustness = 100;
    s.revisions.clear();
    s.concessions.clear();
}

fn command_impl(input: &str) -> String {
    let cmd = input.trim();
    let lc = cmd.to_lowercase();

    if lc == "help" || lc == "помощь" { return help_text(); }
    if lc == "system version" || lc == "beta version" || lc == "версия" || lc == "версия системы" {
        return format!("version={} code={} [Rust typed+dispute core]", VERSION, VERSION_CODE);
    }
    if lc == "system state" || lc == "debate state" || lc == "состояние" || lc == "состояние системы" {
        let s = state().lock().unwrap();
        return system_state_text(&s);
    }
    if lc == "system reset" {
        *state().lock().unwrap() = ModelState::default();
        return "OK system reset: dispute + typed + local values cleared".into();
    }
    if lc == "model audit" {
        let s = state().lock().unwrap();
        return format!("model_hash={}", canonical_model_hash(&s));
    }
    if lc == "proof audit" {
        let s = state().lock().unwrap();
        if !s.project.active || s.project.phase != 6 || s.project.result.is_none() {
            return "ОШИБКА: proof ещё не завершён; сначала доведите typed-операцию до resume".into();
        }
        return format!("proof_hash={}", canonical_proof_hash(&s));
    }
    if lc == "model status" {
        let s = state().lock().unwrap();
        return format!(
            "model={} status_resource={} robustness={} concessions={} committed={}",
            if s.revisions.is_empty() { "base".to_string() } else { format!("rev-{}", s.revisions.len()) },
            s.status_resource,
            s.robustness,
            s.concessions.len(),
            s.committed
        );
    }
    if lc == "project state" {
        let s = state().lock().unwrap();
        return project_state_text(&s);
    }
    if lc.starts_with("calc ") {
        let expr = cmd[5..].trim();
        let p: Vec<&str> = expr.split_whitespace().collect();
        if p.len() != 3 { return "использование: calc <int> <+|-|*> <int>".into(); }
        let a: i64 = match p[0].parse() { Ok(v) => v, Err(_) => return "ОШИБКА: неверное левое целое".into() };
        let b: i64 = match p[2].parse() { Ok(v) => v, Err(_) => return "ОШИБКА: неверное правое целое".into() };
        let r = match p[1] {
            "+" => a.wrapping_add(b),
            "-" => a.wrapping_sub(b),
            "*" => a.wrapping_mul(b),
            _ => return "оператор должен быть одним из: + - *".into(),
        };
        return format!("{} {} {} = {} [Rust]", a, p[1], b, r);
    }

    // --- typed operator vertical slice ---
    if lc == "project reset" {
        let mut s = state().lock().unwrap();
        s.project = ProjectState::default();
        s.bindings.clear();
        return "OK project reset; local definitions preserved; project bindings cleared".into();
    }
    if lc.starts_with("project new ") {
        let name = cmd["project new ".len()..].trim();
        if name.is_empty() { return "НУЖЕН ВВОД: project new <name>".into(); }
        let mut s = state().lock().unwrap();
        if s.project.active { return "ОШИБКА: typed-проект уже активен; сначала project reset".into(); }
        s.project = ProjectState {
            active: true,
            name: Some(name.to_string()),
            claim: None,
            operator: None,
            phase: 1,
            expected_concept_frame: None,
            expected_relation: None,
            result: None,
        };
        return format!("OK project created: {}", name);
    }
    if lc.starts_with("claim ") {
        let claim = cmd["claim ".len()..].trim();
        if claim.is_empty() { return "НУЖЕН ВВОД: claim <name>".into(); }
        let mut s = state().lock().unwrap();
        if !s.project.active || s.project.phase != 1 { return "ОШИБКА: claim сейчас не ожидается".into(); }
        s.project.claim = Some(claim.to_string());
        s.project.phase = 2;
        return format!("OK claim accepted: {}", claim);
    }
    if lc == "run classify.exclude" {
        let mut s = state().lock().unwrap();
        if !s.project.active || s.project.phase != 2 || s.project.claim.is_none() {
            return "ОШИБКА: сначала project new <name> и claim <name>".into();
        }
        s.project.operator = Some("classify.exclude".into());
        let expected_frame = "communist-party:functional".to_string();
        s.project.expected_concept_frame = Some(expected_frame.clone());
        let claim_upper = s.project.claim.as_deref().unwrap_or("").to_uppercase();
        let expected_relation = format!("follows_communist_principles({})", claim_upper);
        s.project.expected_relation = Some(expected_relation.clone());

        if find_definition(&s, "functional").is_none() {
            s.project.phase = 3;
            return format!("NEED_INPUT concept_frame: {}", expected_frame);
        }
        if find_binding(&s, "follows_communist_principles").is_none() {
            s.project.phase = 4;
            return format!("NEED_INPUT relation: {}", expected_relation);
        }
        s.project.phase = 5;
        return "READY: resume".into();
    }
    if lc.starts_with("definition create ") {
        let name = cmd["definition create ".len()..].trim();
        if name.is_empty() { return "НУЖЕН ВВОД: definition create <name>".into(); }
        let mut s = state().lock().unwrap();
        if !s.project.active || s.project.phase != 3 {
            return "ОШИБКА: definition сейчас не запрошена активной операцией".into();
        }
        let frame = definition_frame(name);
        s.definitions.retain(|d| !d.name.eq_ignore_ascii_case(name));
        s.definitions.push(DefinitionRecord { name: name.to_string(), frame: frame.clone() });
        s.project.expected_concept_frame = Some(frame.clone());
        s.project.phase = 4;
        let relation = s.project.expected_relation.clone().unwrap_or_else(|| "follows_communist_principles(?)".into());
        return format!("OK definition created: {} -> {}\nNEED_INPUT relation: {}", name, frame, relation);
    }
    if lc.starts_with("bind ") {
        let rest = cmd["bind ".len()..].trim();
        let mut parts = rest.split_whitespace();
        let relation = match parts.next() { Some(v) => v.trim(), None => return "НУЖЕН ВВОД: bind <relation> <true|false>".into() };
        let value_text = match parts.next() { Some(v) => v.trim(), None => return "НУЖЕН ВВОД: bind <relation> <true|false>".into() };
        if parts.next().is_some() { return "ОШИБКА: bind принимает relation и одно boolean-значение".into(); }
        let value = match parse_bool(value_text) { Some(v) => v, None => return "ОШИБКА: значение должно быть true/false (также да/нет)".into() };
        let mut s = state().lock().unwrap();
        if !s.project.active || s.project.phase != 4 {
            return "ОШИБКА: bind сейчас не запрошен активной операцией".into();
        }
        if !relation.eq_ignore_ascii_case("follows_communist_principles") {
            return format!("ОШИБКА: ожидается relation follows_communist_principles, получено {}", relation);
        }
        s.bindings.retain(|b| !b.relation.eq_ignore_ascii_case(relation));
        s.bindings.push(BindingRecord { relation: relation.to_string(), value });
        s.project.phase = 5;
        return format!("OK binding accepted: {}={}", relation, value);
    }
    if lc == "resume" {
        let mut s = state().lock().unwrap();
        if !s.project.active || s.project.phase != 5 {
            return "ОШИБКА: нет операции, готовой к resume".into();
        }
        if s.project.operator.as_deref() != Some("classify.exclude") {
            return "ОШИБКА: неизвестная приостановленная операция".into();
        }
        let claim = match s.project.claim.clone() { Some(v) => v, None => return "ОШИБКА: claim отсутствует".into() };
        let frame = match find_definition(&s, "functional") {
            Some(v) => v.frame.clone(),
            None => return "NEED_INPUT concept_frame: communist-party:functional".into(),
        };
        let relation_value = match find_binding(&s, "follows_communist_principles") {
            Some(v) => v.value,
            None => {
                let rel = s.project.expected_relation.clone().unwrap_or_else(|| "follows_communist_principles(?)".into());
                return format!("NEED_INPUT relation: {}", rel);
            }
        };
        let verdict = if relation_value { "IN" } else { "OUT" };
        let result = format!("{} {} {}", claim.to_uppercase(), verdict, frame);
        s.project.result = Some(result.clone());
        s.project.phase = 6;
        return result;
    }

    // --- dispute state machine ---
    if lc == "debate reset" {
        let mut s = state().lock().unwrap();
        reset_dispute(&mut s);
        return "OK debate reset".into();
    }
    if lc.starts_with("debate new ") {
        let name = cmd["debate new ".len()..].trim();
        if name.is_empty() { return "НУЖЕН ВВОД: debate new <name>".into(); }
        let mut s = state().lock().unwrap();
        if s.debate_name.is_some() { return "ОШИБКА: активное dispute-состояние уже существует; сначала debate reset".into(); }
        s.debate_name = Some(name.to_string());
        s.step = 1;
        return format!("OK debate created: {}", name);
    }
    if lc == "resolution" {
        return "НУЖЕН ВВОД: resolution <text>".into();
    }
    if lc.starts_with("resolution ") {
        let text = cmd["resolution ".len()..].trim();
        if text.is_empty() { return "НУЖЕН ВВОД: resolution <text>".into(); }
        let mut s = state().lock().unwrap();
        if let Err(e) = require_debate(&s) { return e; }
        if s.step != 1 { return "ОШИБКА: неверный порядок перехода".into(); }
        s.resolution = Some(text.to_string());
        s.step = 2;
        return format!("OK resolution accepted: {}", text);
    }
    if lc == "collision open" {
        return "НУЖЕН ВВОД: collision open <position-a> | <position-b>".into();
    }
    if lc.starts_with("collision open ") {
        let rest = cmd["collision open ".len()..].trim();
        let (a, b) = match parse_binary(rest) { Ok(v) => v, Err(e) => return e };
        let mut s = state().lock().unwrap();
        if s.step != 2 || s.resolution.is_none() { return "ОШИБКА: неверный порядок перехода".into(); }
        s.collision_a = Some(a.to_string());
        s.collision_b = Some(b.to_string());
        s.step = 3;
        return format!("OK collision open\nA: {}\nB: {}", a, b);
    }
    if lc == "function accept" {
        return "НУЖЕН ВВОД: function accept <function/context>".into();
    }
    if lc.starts_with("function accept ") {
        let text = cmd["function accept ".len()..].trim();
        if text.is_empty() { return "НУЖЕН ВВОД: function accept <function/context>".into(); }
        let mut s = state().lock().unwrap();
        if s.step != 3 || s.collision_a.is_none() || s.collision_b.is_none() { return "ОШИБКА: неверный порядок перехода".into(); }
        s.function_context = Some(text.to_string());
        s.step = 4;
        return format!("OK function/context accepted: {}", text);
    }
    if lc == "criterion accept" {
        return "НУЖЕН ВВОД: criterion accept <criterion>".into();
    }
    if lc.starts_with("criterion accept ") {
        let text = cmd["criterion accept ".len()..].trim();
        if text.is_empty() { return "НУЖЕН ВВОД: criterion accept <criterion>".into(); }
        let mut s = state().lock().unwrap();
        if s.step != 4 || s.function_context.is_none() { return "ОШИБКА: неверный порядок перехода".into(); }
        s.criterion = Some(text.to_string());
        s.step = 5;
        return format!("OK criterion accepted: {}", text);
    }
    if lc == "commit" {
        let mut s = state().lock().unwrap();
        if s.step != 5 || s.criterion.is_none() { return "ОШИБКА: неверный порядок перехода".into(); }
        s.committed = true;
        s.step = 6;
        s.robustness = s.robustness.saturating_add(1);
        return format!("COMMITTED: frame locked\nmodel_hash={}", canonical_model_hash(&s));
    }
    if lc == "model revise" {
        return "НУЖЕН ВВОД: model revise <text>".into();
    }
    if lc.starts_with("model revise ") {
        let note = cmd["model revise ".len()..].trim();
        if note.is_empty() { return "НУЖЕН ВВОД: model revise <text>".into(); }
        let mut s = state().lock().unwrap();
        if !s.committed { return "ОШИБКА: модель ещё не commit".into(); }
        let old_hash = canonical_model_hash(&s);
        let old_fn = s.function_context.clone();
        let old_cr = s.criterion.clone();
        s.revisions.push(RevisionRecord {
            note: note.to_string(),
            previous_function_context: old_fn,
            previous_criterion: old_cr,
            previous_hash: old_hash,
        });
        s.status_resource = s.status_resource.saturating_sub(10);
        s.robustness = s.robustness.saturating_sub(5);
        s.function_context = None;
        s.criterion = None;
        s.committed = false;
        s.step = 3;
        return format!("OK revision recorded; frame reopened: {}", note);
    }
    if lc == "model concede" {
        return "НУЖЕН ВВОД: model concede <target> | <reason>".into();
    }
    if lc.starts_with("model concede ") {
        let rest = cmd["model concede ".len()..].trim();
        let parsed = if rest.contains('|') {
            parse_binary(rest).map(|(a,b)| (a.to_string(), b.to_string()))
        } else {
            match rest.split_once(' ') {
                Some((a,b)) if !a.trim().is_empty() && !b.trim().is_empty() => Ok((a.trim().to_string(), b.trim().to_string())),
                _ => Err("НУЖЕН ВВОД: model concede <target> | <reason>".into()),
            }
        };
        let (target, reason) = match parsed { Ok(v) => v, Err(e) => return e };
        let mut s = state().lock().unwrap();
        if let Err(e) = require_debate(&s) { return e; }
        s.concessions.push(ConcessionRecord { target: target.clone(), reason: reason.clone() });
        s.status_resource = s.status_resource.saturating_sub(2);
        s.robustness = s.robustness.saturating_add(1);
        return format!("OK local concession recorded\ntarget={}\nreason={}", target, reason);
    }

    "НЕИЗВЕСТНАЯ КОМАНДА; введи help".into()
}

fn to_jstring(mut env: JNIEnv, text: String) -> jstring {
    match env.new_string(text) {
        Ok(s) => s.into_raw(),
        Err(_) => ptr::null_mut(),
    }
}

#[no_mangle]
pub extern "system" fn Java_io_typedcalculus_console_NativeBridge_command(
    mut env: JNIEnv,
    _class: JClass,
    input: JString,
) -> jstring {
    let text: String = match env.get_string(&input) {
        Ok(s) => s.into(),
        Err(_) => return to_jstring(env, "ОШИБКА: некорректный UTF-8 ввод".into()),
    };
    to_jstring(env, command_impl(&text))
}

#[no_mangle]
pub extern "system" fn Java_io_typedcalculus_console_NativeBridge_expectation(
    env: JNIEnv,
    _class: JClass,
) -> jstring {
    let s = state().lock().unwrap();
    to_jstring(env, expectation_for(&s))
}

#[no_mangle]
pub extern "system" fn Java_io_typedcalculus_console_NativeBridge_exportState(
    env: JNIEnv,
    _class: JClass,
) -> jstring {
    let s = state().lock().unwrap();
    let text = serde_json::to_string(&*s).unwrap_or_else(|_| "{}".into());
    to_jstring(env, text)
}

#[no_mangle]
pub extern "system" fn Java_io_typedcalculus_console_NativeBridge_importState(
    mut env: JNIEnv,
    _class: JClass,
    input: JString,
) -> jboolean {
    let text: String = match env.get_string(&input) {
        Ok(s) => s.into(),
        Err(_) => return JNI_FALSE,
    };
    let parsed: ModelState = match serde_json::from_str(&text) {
        Ok(v) => v,
        Err(_) => return JNI_FALSE,
    };
    if parsed.schema != 2 { return JNI_FALSE; }
    *state().lock().unwrap() = parsed;
    JNI_TRUE
}
