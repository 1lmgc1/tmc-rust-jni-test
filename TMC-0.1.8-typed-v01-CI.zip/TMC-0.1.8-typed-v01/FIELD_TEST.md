# FIELD TEST — TMC 0.1.8-typed-v01

## 1. Обновление и сохранение старого dispute-state

Установить поверх 0.1.7-ru-v02 без удаления.

Сразу выполнить:

```text
system version
system state
```

Ожидается:
- `version=0.1.8-typed-v01 code=15`;
- ранее сохранённый dispute-state 0.1.7 присутствует;
- в конце появился раздел `[TYPED]`.

## 2. Typed vertical slice

Если typed-проект уже активен:

```text
project reset
```

Затем:

```text
project new demo
claim kpss
run classify.exclude
```

Ожидание после `run`:

```text
NEED_INPUT concept_frame: communist-party:functional
Ожидаю: definition create functional
```

Далее:

```text
definition create functional
```

Ожидание содержит:

```text
NEED_INPUT relation: follows_communist_principles(KPSS)
```

Далее:

```text
bind follows_communist_principles false
resume
```

Ожидаемый результат:

```text
KPSS OUT communist-party:functional
```

Затем:

```text
proof audit
project state
```

`proof audit` должен вернуть `proof_hash=<16 hex>`.

## 3. Persistence

Запомнить `proof_hash`, принудительно остановить приложение, открыть снова:

```text
proof audit
project state
```

Ожидается тот же `proof_hash` и сохранённый результат `KPSS OUT communist-party:functional`.

## 4. Проверка обратной ветки

```text
project reset
project new demo2
claim kpss
run classify.exclude
bind follows_communist_principles true
resume
```

Поскольку локальное `functional` определение уже сохранено, `run` должен сразу запросить relation; результат после `resume`:

```text
KPSS IN communist-party:functional
```
