# TMC 0.1.8-typed-v01

Следующий рабочий слой поверх 0.1.7-ru-v02.

## Что добавлено

Возвращён обязательный typed-operator вертикальный сценарий раннего TMC:

```text
project new demo
claim kpss
run classify.exclude
definition create functional
bind follows_communist_principles false
resume
proof audit
```

Оператор работает с явной приостановкой:

- `run classify.exclude` не угадывает отсутствующие данные;
- при отсутствии concept frame возвращается `NEED_INPUT concept_frame`;
- `definition create functional` создаёт локальное определение `communist-party:functional`;
- затем запрашивается relation `follows_communist_principles(<CLAIM>)`;
- `bind ... true|false` сохраняет значение;
- `resume` продолжает именно приостановленную операцию;
- `proof audit` считает детерминированный hash typed-состояния.

## Параллельные состояния

Существующая dispute-машина не удалена. В одном Rust state теперь живут:

- dispute: debate/resolution/collision/function/criterion/commit/revise/concede;
- typed project: project/claim/operator/definitions/bindings/resume/proof.

`system state` показывает оба раздела.

## Совместимость

State schema оставлена `2`, а новые поля имеют serde-default. Сохранённое состояние 0.1.7 должно импортироваться без сброса.

`model_hash` вычисляется только по прежней dispute-части, чтобы добавление typed-полей само по себе не меняло audit существующей модели.

## Новые команды

```text
project new <name>
project state
project reset
claim <name>
run classify.exclude
definition create <name>
bind <relation> <true|false>
resume
proof audit
system reset
```
