# FIELD TEST — TMC 0.1.13-batch-console-v01

## 1. Пакетный ввод

Вставить одним блоком:

```text
# demo batch
runtime reset
runtime init demo
runtime validate
runtime emit claim <batch test>
runtime run
runtime ledger
runtime state
storage verify
```

Нажать `ВЫПОЛНИТЬ` один раз.

Ожидается:
- заголовок `=== ПАКЕТ: 7 команд ===` (строка-комментарий не считается);
- команды выполняются сверху вниз;
- виден прогресс `[1/7] ... [7/7]`;
- `runtime run` приходит к `Committed`;
- `storage verify` заканчивается `STORAGE VALID`;
- в конце `=== ПАКЕТ ЗАВЕРШЁН: 7/7 ===`;
- `Ожидаю: ...` печатается один раз после пакета.

## 2. NEED_INPUT внутри списка не должен останавливать пакет

Отдельным блоком:

```text
project reset
project new demo-batch
claim kpss
run classify.exclude
definition create functional
bind follows_communist_principles false
resume
proof audit
```

Ожидается, что `run classify.exclude` выдаст `NEED_INPUT`, но следующие строки выполнятся автоматически и сценарий дойдёт до результата/proof audit.

## 3. Жёсткая ошибка останавливает пакет

Отдельным блоком:

```text
runtime reset
runtime emit claim <must fail>
runtime init demo
runtime validate
```

На второй строке ожидается ошибка `runtime не инициализирован`. Пакет должен остановиться. Оставшиеся строки:

```text
runtime init demo
runtime validate
```

должны автоматически вернуться в поле ввода, чтобы их можно было запустить после исправления/осмотра.

## 4. Перезапуск процесса

Для persistence-теста пакет по-прежнему делится вручную:

До закрытия приложения:

```text
runtime reset
runtime init demo
runtime emit claim <persistent batch>
runtime step
runtime queue
```

Закрыть приложение / открыть снова.

После открытия одним блоком:

```text
runtime queue
runtime events
storage status
storage verify
```

Незавершённая Rust WorkQueue должна восстановиться из SQLite так же, как в 0.1.12.
