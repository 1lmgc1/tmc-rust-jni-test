package io.typedcalculus.console;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

public final class MainActivity extends Activity {
    private static final String VERSION = "0.1.13-batch-console-v01";
    private TextView output;
    private EditText input;
    private ScrollView scroll;
    private SharedPreferences prefs;
    private boolean nativeReady;
    private boolean sqliteReady;
    private final ArrayDeque<String> commandQueue = new ArrayDeque<>();

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
        prefs = getSharedPreferences("tmc", MODE_PRIVATE);
        printGreeting();
        try {
            NativeBridge.load();
            nativeReady = true;

            String dbPath = new java.io.File(getFilesDir(), "tmc-runtime.sqlite3").getAbsolutePath();
            String storage = NativeBridge.initStorage(dbPath);
            if (storage != null && storage.startsWith("RESTORED")) {
                sqliteReady = true;
                println("SQLite: состояние восстановлено; " + storage);
            } else if (storage != null && storage.startsWith("EMPTY")) {
                sqliteReady = true;
                println("SQLite: создан новый durable store; " + storage);
                String saved = prefs.getString("rust_state_json_v2", null);
                if (saved != null && !saved.isEmpty()) {
                    boolean ok = NativeBridge.importState(saved);
                    println(ok ? "Миграция SharedPreferences → SQLite: OK" : "Миграция SharedPreferences → SQLite: отклонена");
                } else {
                    String checkpoint = NativeBridge.persistStorage();
                    println("SQLite: " + checkpoint);
                }
            } else {
                println("SQLite недоступен: " + storage);
                String saved = prefs.getString("rust_state_json_v2", null);
                if (saved != null && !saved.isEmpty()) {
                    boolean ok = NativeBridge.importState(saved);
                    println(ok ? "Fallback SharedPreferences: состояние восстановлено" : "Fallback SharedPreferences: состояние не принято");
                }
            }
            printExpectation();
        } catch (Throwable t) {
            println("ОШИБКА NATIVE: " + t.getClass().getSimpleName() + ": " + t.getMessage());
        }
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(8), dp(8), dp(8), dp(8));
        root.setBackgroundColor(Color.rgb(46,46,46));

        scroll = new ScrollView(this);
        output = new TextView(this);
        output.setTextColor(Color.LTGRAY);
        output.setTextSize(17f);
        output.setGravity(Gravity.START);
        output.setTextIsSelectable(true);
        scroll.addView(output, new ScrollView.LayoutParams(-1,-2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1f));

        input = new EditText(this);
        input.setHint("команды — по одной на строку");
        input.setSingleLine(false);
        input.setMinLines(3);
        input.setMaxLines(8);
        input.setGravity(Gravity.TOP | Gravity.START);
        input.setHorizontallyScrolling(false);
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(Color.LTGRAY);
        input.setImeOptions(EditorInfo.IME_FLAG_NO_ENTER_ACTION);
        root.addView(input, new LinearLayout.LayoutParams(-1,-2));

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);

        Button run = new Button(this);
        run.setText("ВЫПОЛНИТЬ");
        buttons.addView(run, new LinearLayout.LayoutParams(0,-2,1f));

        Button clear = new Button(this);
        clear.setText("ОЧИСТИТЬ");
        buttons.addView(clear, new LinearLayout.LayoutParams(0,-2,1f));

        root.addView(buttons, new LinearLayout.LayoutParams(-1,-2));

        run.setOnClickListener(v -> dispatchBatch());
        clear.setOnClickListener(v -> {
            input.setText("");
            commandQueue.clear();
        });

        setContentView(root);
    }

    private void printGreeting() {
        println(" /\\_/\\ ");
        println("( o.o )   TMC " + VERSION);
        println(" > ^ <    Java batch console / Rust SQLite event-store + resource-runtime / Android 14 arm64");
        println("");
        println(" /\\_/\\   /\\_/\\ ");
        println("( =^.^= ) ( =^.^= )");
        println("(\")_(\") (\")_(\")");
        println("");
        println("Привет. Это консоль типизированного калькулятора, коллизий и фиксации модели.");
        println("Можно вставить список команд: одна команда на строку. Они выполнятся сверху вниз.");
        println("Пустые строки и строки, начинающиеся с #, игнорируются.");
        println("Для перезапуска приложения или одиночного контрольного шага отправляй отдельный список.");
        println("Набери help для полной справки.");
        println("");
    }

    private void dispatchBatch() {
        String raw = input.getText().toString();
        if (raw == null || raw.trim().isEmpty()) return;

        List<String> commands = parseCommands(raw);
        if (commands.isEmpty()) {
            input.setText("");
            return;
        }

        input.setText("");
        commandQueue.clear();
        commandQueue.addAll(commands);

        if (!nativeReady) {
            println("native core недоступно");
            return;
        }

        if (commands.size() > 1) {
            println("=== ПАКЕТ: " + commands.size() + " команд ===");
        }

        int total = commands.size();
        int index = 0;
        while (!commandQueue.isEmpty()) {
            String cmd = commandQueue.removeFirst();
            index++;
            if (total > 1) {
                println("[" + index + "/" + total + "] > " + cmd);
            } else {
                println("> " + cmd);
            }

            try {
                String response = NativeBridge.command(cmd);
                if (response != null && !response.isEmpty()) println(response);
                saveState();

                if (isHardFailure(response)) {
                    preserveRemainingQueue();
                    println("=== ПАКЕТ ОСТАНОВЛЕН: ошибка на " + index + "/" + total +
                            "; оставшиеся команды возвращены в поле ввода ===");
                    printExpectation();
                    return;
                }
            } catch (Throwable t) {
                println("ОШИБКА: " + t.getClass().getSimpleName() + ": " + t.getMessage());
                preserveRemainingQueue();
                println("=== ПАКЕТ ОСТАНОВЛЕН: исключение; оставшиеся команды возвращены в поле ввода ===");
                printExpectation();
                return;
            }
        }

        if (total > 1) {
            println("=== ПАКЕТ ЗАВЕРШЁН: " + total + "/" + total + " ===");
        }
        printExpectation();
    }

    private List<String> parseCommands(String raw) {
        String normalized = raw.replace("\r\n", "\n").replace('\r', '\n');
        String[] lines = normalized.split("\n");
        ArrayList<String> result = new ArrayList<>();
        for (String line : lines) {
            String cmd = line.trim();
            if (cmd.isEmpty()) continue;
            if (cmd.startsWith("#")) continue;
            result.add(cmd);
        }
        return result;
    }

    private boolean isHardFailure(String response) {
        if (response == null) return false;
        String r = response.trim();
        return r.startsWith("ОШИБКА:") ||
               r.startsWith("ERROR:") ||
               r.startsWith("НЕИЗВЕСТНАЯ КОМАНДА") ||
               r.startsWith("UNKNOWN;");
    }

    private void preserveRemainingQueue() {
        if (commandQueue.isEmpty()) return;
        StringBuilder sb = new StringBuilder();
        while (!commandQueue.isEmpty()) {
            if (sb.length() > 0) sb.append('\n');
            sb.append(commandQueue.removeFirst());
        }
        input.setText(sb.toString());
        input.setSelection(input.getText().length());
    }

    private void saveState() {
        if (sqliteReady) {
            // Rust command() checkpoints SQLite transactionally after each command.
            return;
        }
        String data = NativeBridge.exportState();
        if (data != null) prefs.edit().putString("rust_state_json_v2", data).apply();
    }

    private void printExpectation() {
        if (!nativeReady) return;
        String e = NativeBridge.expectation();
        println("Ожидаю: " + e);
    }

    private void println(String s) {
        output.append(s); output.append("\n");
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }
}
