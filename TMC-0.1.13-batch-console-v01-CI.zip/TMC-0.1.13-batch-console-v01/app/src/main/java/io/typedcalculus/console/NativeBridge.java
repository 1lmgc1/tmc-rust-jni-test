package io.typedcalculus.console;

public final class NativeBridge {
    private NativeBridge() {}
    public static void load() { System.loadLibrary("typed_calculus"); }
    public static native String command(String input);
    public static native String expectation();
    public static native String exportState();
    public static native boolean importState(String stateJson);
    public static native String initStorage(String dbPath);
    public static native String persistStorage();
}
