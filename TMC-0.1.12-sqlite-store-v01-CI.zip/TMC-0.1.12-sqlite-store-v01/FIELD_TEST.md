# FIELD TEST — TMC 0.1.12-sqlite-store-v01

Цель: проверить не прежний resource-loop, а новый durable SQLite слой, миграцию и восстановление после убийства Activity/process.

## A. Первый запуск поверх 0.1.11

После установки поверх работающей 0.1.11 ожидается один из вариантов:

```text
SQLite: создан новый durable store; EMPTY durable_events=0
Миграция SharedPreferences → SQLite: OK
```

Если 0.1.12 уже запускалась ранее, вместо этого:

```text
SQLite: состояние восстановлено; RESTORED offset=... durable_events=...
```

Проверить:

```text
system version
storage status
storage verify
```

Ожидается версия `0.1.12-sqlite-store-v01` и:

```text
storage.active=true
backend=SQLite WAL
...
STORAGE VALID integrity=ok ... current_chain=ok
```

Если из 0.1.11 мигрировался уже завершённый resource test, `durable_events` может быть больше нуля сразу — это нормально.

## B. Новый analysis должен продолжить глобальный seq

```text
runtime reset
runtime init demo
runtime emit claim <государство управляет ресурсами>
runtime run
storage status
storage verify
runtime events
```

Проверить:
- `correlation` уже не обязан быть `analysis-0`;
- первый `ev-N` нового анализа должен использовать offset после старого `max_seq`, если старые events были мигрированы;
- run заканчивается `stop=Committed`;
- `storage verify` остаётся VALID;
- каждый event в `runtime events` имеет `hash=`.

## C. Главный тест: restore после закрытия процесса

После завершения B запомнить минимум:
- `correlation_id`;
- `iteration`;
- `spent`;
- `stop`;
- `next_seq` / последний event id.

Затем полностью закрыть приложение (лучше убрать из recent apps; при возможности Force stop), открыть снова.

На старте должно быть:

```text
SQLite: состояние восстановлено; RESTORED offset=... durable_events=...
```

После старта выполнить:

```text
runtime state
runtime ledger
runtime events
storage status
storage verify
```

Все значения текущего analysis должны сохраниться. Нельзя получать пустой runtime или откат к старому SharedPreferences состоянию.

## D. Persistence pending queue

Проверка восстановления не только финального state, но и незавершённой очереди:

```text
runtime reset
runtime init demo
runtime emit claim <pending persistence test>
runtime step
runtime queue
storage status
```

После одного step один check уже Completed, второй должен оставаться Queued.

Полностью закрыть приложение и открыть снова.

Проверить:

```text
runtime queue
runtime events
storage verify
```

Queued/Completed состояния и InputFrames должны восстановиться. Затем:

```text
runtime run
```

Analysis должен продолжиться с сохранённой очереди, а не начаться заново.

## E. Append-only между runtime reset

После завершения анализа:

```text
storage status
```

запомнить `durable_events` и `max_seq`.

Затем:

```text
runtime reset
runtime init demo
runtime emit claim <second durable analysis>
runtime step
storage status
```

Ожидается:
- `durable_events` вырос;
- `max_seq` вырос;
- seq нового analysis не начинается снова с 1;
- предыдущие durable events не удалены `runtime reset`.
