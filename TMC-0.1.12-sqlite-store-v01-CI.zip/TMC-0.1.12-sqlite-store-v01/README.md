# TMC 0.1.12-sqlite-store-v01

Первый durable storage patch новой graph/event архитектуры.

## Что уже подтверждено предыдущей версией

0.1.11 на реальном Android 14 / arm64 подтвердил:
- fan-out ClaimEvent в две ветви;
- join только после готовности обоих входов;
- WorkQueue/Scheduler;
- цикл Conflict -> Revision -> следующая iteration;
- отдельный ResourceLedger;
- остановку `Committed`;
- остановку `ResourceExhausted` без превращения модели в `Rejected`.

## Что добавляет 0.1.12

### SQLite внутри Rust

`rusqlite` + bundled SQLite. База хранится в private files dir Android:

`tmc-runtime.sqlite3`

Включены:
- WAL;
- `event_log` — append-only durable events;
- `state_checkpoint` — технический checkpoint/projection для быстрого восстановления;
- `work_projection` — текущая operational queue projection;
- `frame_projection` — InputFrame projection;
- `resource_projection` — ResourceLedger projection.

### Миграция с 0.1.11

При первом запуске 0.1.12:
1. Rust создаёт SQLite store.
2. Если checkpoint в SQLite отсутствует, Java читает прежний `SharedPreferences` state.
3. Старый state импортируется в Rust.
4. События 0.1.11 нормализуются: получают `graph_id`, `schema_version` и hash-chain.
5. State и runtime записываются в SQLite.

После этого SQLite является основным persistence backend. SharedPreferences остаётся только аварийным fallback, если SQLite initialization не удалась.

### Hash-chain

Каждый новый Event содержит:
- `previous_hash`;
- `event_hash`.

Hash покрывает schema, graph, seq/id, kind, payload, source, parent, branch, correlation и iteration.

Это пока локальный audit chain, а не криптографическая подпись.

### Глобальный durable seq

`event_log.seq` не сбрасывается при `runtime reset`.
Новый `runtime init demo` берёт `MAX(seq)+1`, поэтому event ids/offsets не конфликтуют между последовательными анализами.
`correlation_id` нового анализа также строится от durable offset (`analysis-<next_seq>`).

## Новые команды

- `storage status`
- `storage verify`
- `storage checkpoint`

`storage status` показывает backend, path, durable event count, max seq/checkpoint offset и размеры operational projections.

`storage verify` выполняет SQLite `PRAGMA integrity_check`, проверку duplicate event ids и hash-chain текущего analysis stream.

## Persistence semantics

Каждая команда через JNI после исполнения делает SQLite checkpoint transaction.

В одной транзакции:
- новые Events добавляются в append-only `event_log` через `INSERT OR IGNORE`;
- work/frame/resource projections заменяются актуальной projection;
- полный `ModelState` сохраняется как `state_checkpoint` cache.

Это первый durable слой. Полное восстановление исключительно replay-ом из EventLog без checkpoint остаётся следующим развитием event sourcing; в 0.1.12 checkpoint используется как технический cache/projection.
