# TMC 0.1.11-resource-runtime-v01

Первый ресурсный scheduler поверх event-router runtime.

## Что добавлено

- priority FIFO scheduler;
- стоимость WorkItem (`estimated_cost`, `actual_cost`);
- `ResourcePolicy`: общий budget, branch cap, budget cap одной iteration, safety limit iterations;
- append-only `ResourceSpent` events;
- `ResourceLedger` как отдельная проекция расхода;
- остановка `ResourceExhausted` без объявления модели ложной;
- циклический demo graph с одной ревизией и повторной check-iteration;
- `runtime run` для автоматического исполнения очереди;
- `runtime budget set <n>` для проверки поведения при ограниченном ресурсе;
- `runtime ledger` для просмотра расхода.

## Demo graph

```text
                    +--> SemanticCheck --+
                    |                    |
Claim/Input --------+                    +--> Compare -- Stable --> Commit
                    |                    |
                    +--> CounterCheck ---+             \
                                                       Conflict
                                                          |
                                                          v
                                                       Revision
                                                          |
                                                          +---- ClaimEvent ----> checks (next iteration)
```

В iteration 0 CounterCheck намеренно возвращает `Conflict`. Revision порождает новую `ClaimEvent` для iteration 1. В iteration 1 CounterCheck возвращает `Support`, поэтому Compare выдаёт `Stable`, после чего Commit завершает ветвь.

Это тестовая механика runtime, а не содержательный философский оператор.

## Стоимости demo

- SemanticCheck = 2
- CounterCheck = 3
- Compare = 1
- Revision = 4
- Commit = 1

Default policy:

```text
total_budget = 30
branch_cap = 30
iteration_budget_cap = 12
max_iterations = 8
```

## Команды

```text
runtime reset
runtime init demo
runtime validate
runtime budget set <n>
runtime emit claim <text>
runtime queue
runtime step
runtime run
runtime run <steps>
runtime ledger
runtime events
runtime state
```

## Два обязательных сценария

### A. Достаточный ресурс

```text
runtime reset
runtime init demo
runtime emit claim <государство управляет ресурсами>
runtime run
runtime ledger
runtime state
```

Ожидается одна Revision, переход `iteration=0 -> iteration=1`, затем `Committed`.

### B. Недостаточный ресурс

```text
runtime reset
runtime init demo
runtime budget set 8
runtime emit claim <государство управляет ресурсами>
runtime run
runtime queue
runtime ledger
runtime state
```

После SemanticCheck + CounterCheck + Compare будет потрачено 6. Revision стоит 4 при остатке 2 и должна перейти в `Suspended(ResourceInsufficient)`. Runtime фиксирует `stop=ResourceExhausted`, но не маркирует модель `false/rejected`.

## Совместимость

Dispute и typed vertical slice сохранены. Состояние 0.1.10 импортируется: новые resource-поля имеют serde defaults. Для теста нового demo после обновления выполнить `runtime reset` и `runtime init demo`.
