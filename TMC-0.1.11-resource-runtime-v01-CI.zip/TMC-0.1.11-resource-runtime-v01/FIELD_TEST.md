# FIELD TEST — TMC 0.1.11-resource-runtime-v01

Цель теста: проверить scheduler + аналитический budget + revision loop, не повторяя Android/JNI/Rust platform smoke-tests.

## 1. Graph

```text
runtime reset
runtime init demo
runtime validate
runtime state
```

Контроль:

```text
VALID graph=demo-resource-graph revision=3 nodes=6 edges=8
```

В state должны быть:

```text
resource total=30 spent=0 remaining=30 branch_cap=30 iteration_budget_cap=12 max_iterations=8
```

## 2. Полный прогон с достаточным ресурсом

```text
runtime emit claim <государство управляет ресурсами>
runtime run
runtime ledger
runtime state
```

Ожидаемая траектория:

```text
iteration 0:
SemanticCheck -> Support      cost 2
CounterCheck  -> Conflict     cost 3
Compare       -> Conflict     cost 1
Revision      -> iteration 1  cost 4

iteration 1:
SemanticCheck -> Support      cost 2
CounterCheck  -> Support      cost 3
Compare       -> Stable       cost 1
Commit                         cost 1
```

Итого ожидаемый analytic spend: `17`.

Финальный state:

```text
iteration=1
stop=Committed
resource total=30 spent=17 remaining=13
```

EventLog дополнительно содержит `ResourceSpent` и `BranchCommitted`.

## 3. Ресурсное прекращение

```text
runtime reset
runtime init demo
runtime budget set 8
runtime emit claim <государство управляет ресурсами>
runtime run
runtime queue
runtime ledger
runtime state
```

Ожидается:

```text
SemanticCheck -> Support   (2)
CounterCheck  -> Conflict  (3)
Compare       -> Conflict  (1)
spent=6
```

Revision требует 4 при доступном остатке 2, поэтому:

```text
work ... node=n-revision status=Suspended ... reason=ResourceInsufficient: need=4 remaining=2
stop=ResourceExhausted
```

Важно: `ResourceExhausted` — причина остановки процедуры, не `Rejected` и не утверждение о ложности модели.
