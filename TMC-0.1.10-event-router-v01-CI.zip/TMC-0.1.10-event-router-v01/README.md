# TMC 0.1.10-event-router-v01

Первый исполняемый event-driven runtime поверх работающей ветки 0.1.9.

## Что добавлено

- fan-out graph: `Input -> SemanticCheck / CounterCheck -> Compare -> Output`;
- append-only `EventRecord[]` в текущем Rust state;
- Router по typed `Edge`;
- сбор `InputFrame` по входным портам;
- создание `WorkItem` только после ready-frame;
- WorkQueue со статусами;
- `runtime step`: ровно один WorkItem за команду;
- join: Compare становится runnable только после двух CheckResult;
- live `Ожидаю:` переключается на runtime, пока runtime активен.

## Команды

```text
runtime reset
runtime init demo
runtime validate
runtime emit claim <text>
runtime queue
runtime step
runtime events
runtime state
```

## Демонстрационный маршрут

```text
ClaimEvent
   |\
   | \-> CounterCheck ----\
   +----> SemanticCheck ----> Compare -> Output
```

После `runtime emit claim <text>` должно появиться два `Queued WorkItem`.
Два первых `runtime step` исполняют независимые checks. Только после второго результата создаётся WorkItem `Compare` — это проверяет настоящий join через InputFrame, а не прямой Node->Node вызов.

## Что намеренно ещё отсутствует

- resource accounting;
- priority scheduler;
- iteration budget;
- SQLite EventStore;
- replay/fork;
- GUI graph viewer.

Это следующие слои. В 0.1.10 проверяется именно связка `Event -> Router -> InputFrame -> WorkItem -> STEP -> Event`.

Старые dispute/typed команды сохранены как regression surface.
