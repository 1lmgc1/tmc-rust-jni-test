use jni::objects::{JClass, JString};
use jni::sys::{jboolean, jstring, JNI_FALSE, JNI_TRUE};
use jni::JNIEnv;
use serde::{Deserialize, Serialize};
use std::collections::HashSet;
use std::ptr;
use std::sync::{Mutex, OnceLock};

const VERSION: &str = "0.1.10-event-router-v01";
const VERSION_CODE: u32 = 17;

#[derive(Debug, Clone, Serialize, Deserialize)]
struct RevisionRecord {
    note: String,
    previous_function_context: Option<String>,
    previous_criterion: Option<String>,
    previous_hash: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct ConcessionRecord {
    target: String,
    reason: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct DefinitionRecord {
    name: String,
    frame: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct BindingRecord {
    relation: String,
    value: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
struct ProjectState {
    active: bool,
    name: Option<String>,
    claim: Option<String>,
    operator: Option<String>,
    phase: u8,
    expected_concept_frame: Option<String>,
    expected_relation: Option<String>,
    result: Option<String>,
}


#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
enum PortDirection {
    Input,
    Output,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
enum PortCardinality {
    One,
    Optional,
    All,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct PortSpec {
    id: String,
    name: String,
    direction: PortDirection,
    event_type: String,
    cardinality: PortCardinality,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct NodeSpec {
    id: String,
    node_type: String,
    label: String,
    implementation_version: u32,
    ports: Vec<PortSpec>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct EdgeSpec {
    id: String,
    from_node: String,
    from_port: String,
    to_node: String,
    to_port: String,
    event_type: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
struct GraphState {
    graph_id: String,
    revision: u32,
    nodes: Vec<NodeSpec>,
    edges: Vec<EdgeSpec>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct EventRecord {
    seq: u64,
    event_id: String,
    kind: String,
    payload_json: String,
    source_node: Option<String>,
    source_port: Option<String>,
    branch_id: String,
    correlation_id: String,
    iteration: u32,
    parent_event_id: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
enum WorkStatus {
    Queued,
    Running,
    Suspended,
    Completed,
    Rejected,
    DeadEnd,
    Cancelled,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct WorkItem {
    id: String,
    node_id: String,
    input_event_ids: Vec<String>,
    iteration: u32,
    priority: i32,
    budget: u32,
    status: WorkStatus,
    attempts: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct InputBinding {
    port_id: String,
    event_id: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct InputFrame {
    id: String,
    node_id: String,
    branch_id: String,
    correlation_id: String,
    iteration: u32,
    bindings: Vec<InputBinding>,
    ready: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct RuntimeState {
    active: bool,
    graph: GraphState,
    events: Vec<EventRecord>,
    input_frames: Vec<InputFrame>,
    work_items: Vec<WorkItem>,
    branch_id: String,
    correlation_id: String,
    iteration: u32,
    next_seq: u64,
}

impl Default for RuntimeState {
    fn default() -> Self {
        Self {
            active: false,
            graph: GraphState::default(),
            events: Vec::new(),
            input_frames: Vec::new(),
            work_items: Vec::new(),
            branch_id: "root".into(),
            correlation_id: "analysis-0".into(),
            iteration: 0,
            next_seq: 1,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
struct ModelState {
    schema: u32,
    debate_name: Option<String>,
    resolution: Option<String>,
    collision_a: Option<String>,
    collision_b: Option<String>,
    function_context: Option<String>,
    criterion: Option<String>,
    committed: bool,
    step: u8,
    status_resource: u8,
    robustness: u8,
    revisions: Vec<RevisionRecord>,
    concessions: Vec<ConcessionRecord>,
    project: ProjectState,
    definitions: Vec<DefinitionRecord>,
    bindings: Vec<BindingRecord>,
    runtime: RuntimeState,
}

impl Default for ModelState {
    fn default() -> Self {
        Self {
            schema: 2,
            debate_name: None,
            resolution: None,
            collision_a: None,
            collision_b: None,
            function_context: None,
            criterion: None,
            committed: false,
            step: 0,
            status_resource: 100,
            robustness: 100,
            revisions: Vec::new(),
            concessions: Vec::new(),
            project: ProjectState::default(),
            definitions: Vec::new(),
            bindings: Vec::new(),
            runtime: RuntimeState::default(),
        }
    }
}

static STATE: OnceLock<Mutex<ModelState>> = OnceLock::new();
fn state() -> &'static Mutex<ModelState> { STATE.get_or_init(|| Mutex::new(ModelState::default())) }

fn fnv1a64(bytes: &[u8]) -> u64 {
    let mut h = 0xcbf29ce484222325u64;
    for &b in bytes {
        h ^= b as u64;
        h = h.wrapping_mul(0x100000001b3);
    }
    h
}

#[derive(Serialize)]
struct DisputeHashState<'a> {
    schema: u32,
    debate_name: &'a Option<String>,
    resolution: &'a Option<String>,
    collision_a: &'a Option<String>,
    collision_b: &'a Option<String>,
    function_context: &'a Option<String>,
    criterion: &'a Option<String>,
    committed: bool,
    step: u8,
    status_resource: u8,
    robustness: u8,
    revisions: &'a Vec<RevisionRecord>,
    concessions: &'a Vec<ConcessionRecord>,
}

fn canonical_model_hash(s: &ModelState) -> String {
    let view = DisputeHashState {
        schema: s.schema,
        debate_name: &s.debate_name,
        resolution: &s.resolution,
        collision_a: &s.collision_a,
        collision_b: &s.collision_b,
        function_context: &s.function_context,
        criterion: &s.criterion,
        committed: s.committed,
        step: s.step,
        status_resource: s.status_resource,
        robustness: s.robustness,
        revisions: &s.revisions,
        concessions: &s.concessions,
    };
    let data = serde_json::to_vec(&view).unwrap_or_default();
    format!("{:016x}", fnv1a64(&data))
}

#[derive(Serialize)]
struct ProofHashState<'a> {
    project: &'a ProjectState,
    definitions: &'a Vec<DefinitionRecord>,
    bindings: &'a Vec<BindingRecord>,
}

fn canonical_proof_hash(s: &ModelState) -> String {
    let view = ProofHashState {
        project: &s.project,
        definitions: &s.definitions,
        bindings: &s.bindings,
    };
    let data = serde_json::to_vec(&view).unwrap_or_default();
    format!("{:016x}", fnv1a64(&data))
}

fn require_debate(s: &ModelState) -> Result<(), String> {
    if s.debate_name.is_none() { Err("ОШИБКА: debate ещё не создан".into()) } else { Ok(()) }
}

fn project_expectation(p: &ProjectState) -> Option<String> {
    if !p.active { return None; }
    Some(match p.phase {
        1 => "claim <name>".into(),
        2 => "run classify.exclude".into(),
        3 => "definition create functional".into(),
        4 => "bind follows_communist_principles <true|false>".into(),
        5 => "resume".into(),
        _ => "proof audit | project state | project reset".into(),
    })
}

fn expectation_for(s: &ModelState) -> String {
    if s.runtime.active {
        let queued = s.runtime.work_items.iter().any(|w| w.status == WorkStatus::Queued);
        if queued {
            return "runtime step | runtime queue | runtime events | runtime state | runtime reset".into();
        }
        if s.runtime.events.is_empty() {
            return "runtime emit claim <text> | runtime validate | runtime state | runtime reset".into();
        }
        return "runtime events | runtime state | runtime reset".into();
    }
    if let Some(e) = project_expectation(&s.project) { return e; }
    match s.step {
        0 => "debate new <name> | project new <name> | runtime init demo".into(),
        1 => "resolution <text>".into(),
        2 => "collision open <position-a> | <position-b>".into(),
        3 => "function accept <function/context>".into(),
        4 => "criterion accept <criterion>".into(),
        5 => "commit".into(),
        _ => "model audit | model status | model revise <text> | model concede <target> | <reason> | project new <name>".into(),
    }
}

fn help_text() -> String {
    [
        "=== TMC HELP / СПРАВКА ===",
        "",
        "ТРИ СЛОЯ:",
        "A) dispute-модель: формализация коллизии и фиксация frame",
        "B) typed-operator: NEED_INPUT → definition/bind → resume",
        "C) event-router runtime: typed Graph → Event → InputFrame → WorkItem → STEP",
        "",
        "--- A. DISPUTE ---",
        "1) debate new <name>",
        "2) resolution <text>",
        "3) collision open <position-a> | <position-b>",
        "4) function accept <function/context>",
        "5) criterion accept <criterion>",
        "6) commit",
        "после commit: model audit / model status / model revise <text> / model concede <target> | <reason>",
        "",
        "--- B. TYPED OPERATOR ---",
        "project new <name>             — создать проект вычисления",
        "claim <name>                   — задать объект/утверждение",
        "run classify.exclude           — запустить оператор исключающей классификации",
        "definition create functional   — создать локальный concept frame",
        "bind follows_communist_principles <true|false> — связать требуемое отношение со значением",
        "resume                         — продолжить приостановленную операцию",
        "proof audit                    — hash доказательного состояния",
        "project state                  — состояние typed-операции",
        "project reset                  — сбросить только текущий typed-проект",
        "",
        "Эталонный вертикальный сценарий:",
        "project new demo",
        "claim kpss",
        "run classify.exclude",
        "definition create functional",
        "bind follows_communist_principles false",
        "resume",
        "proof audit",
        "",
        "--- C. EVENT ROUTER RUNTIME ---",
        "runtime init demo       — создать Graph Input → Semantic/Counter → Compare → Output",
        "runtime validate        — проверить topology и event types",
        "runtime emit claim <t>  — записать ClaimEvent и маршрутизировать по Graph",
        "runtime queue           — показать InputFrames и WorkQueue",
        "runtime step            — выполнить ровно один Queued WorkItem",
        "runtime events          — показать append-only EventLog в памяти",
        "runtime state           — topology + operational counters",
        "runtime reset           — сбросить только runtime",
        "",
        "0.1.10 исполняет минимальный цикл: Event → Router → InputFrame → WorkItem → STEP → Event.",
        "",
        "Смысл NEED_INPUT:",
        "оператор не угадывает отсутствующее значение. Он фиксирует, чего не хватает, приостанавливается и ждёт definition/bind. После этого команда resume продолжает ту же операцию.",
        "",
        "--- СИСТЕМА ---",
        "system version  — версия приложения и Rust-ядра",
        "system state    — dispute + typed + runtime состояние целиком",
        "system reset    — полный сброс dispute + typed + runtime и локальных значений",
        "help / помощь   — эта справка",
        "calc 7 + 5      — простая Rust-проверка",
        "",
        "Подсказки:",
        "— Следуй строке 'Ожидаю: ...'",
        "— Для collision и concede разделитель — вертикальная черта |",
        "— Команды остаются латиницей: русский язык используется в интерфейсе и пояснениях.",
    ].join("\n")
}

fn project_state_text(s: &ModelState) -> String {
    let p = &s.project;
    let mut out = Vec::new();
    out.push(format!("project.active={} phase={}", p.active, p.phase));
    out.push(format!("project.name={}", p.name.as_deref().unwrap_or("<none>")));
    out.push(format!("claim={}", p.claim.as_deref().unwrap_or("<none>")));
    out.push(format!("operator={}", p.operator.as_deref().unwrap_or("<none>")));
    out.push(format!("expected_concept_frame={}", p.expected_concept_frame.as_deref().unwrap_or("<none>")));
    out.push(format!("expected_relation={}", p.expected_relation.as_deref().unwrap_or("<none>")));
    out.push(format!("result={}", p.result.as_deref().unwrap_or("<none>")));
    out.push(format!("definitions={} bindings={}", s.definitions.len(), s.bindings.len()));
    for (i, d) in s.definitions.iter().enumerate() {
        out.push(format!("definition[{}]={} -> {}", i + 1, d.name, d.frame));
    }
    for (i, b) in s.bindings.iter().enumerate() {
        out.push(format!("binding[{}]={}={}", i + 1, b.relation, b.value));
    }
    out.join("\n")
}

fn system_state_text(s: &ModelState) -> String {
    let mut out = Vec::new();
    out.push("[DISPUTE]".into());
    out.push(format!("step={} committed={}", s.step, s.committed));
    out.push(format!("debate={}", s.debate_name.as_deref().unwrap_or("<none>")));
    out.push(format!("resolution={}", s.resolution.as_deref().unwrap_or("<none>")));
    out.push(format!("collision.a={}", s.collision_a.as_deref().unwrap_or("<none>")));
    out.push(format!("collision.b={}", s.collision_b.as_deref().unwrap_or("<none>")));
    out.push(format!("function_context={}", s.function_context.as_deref().unwrap_or("<none>")));
    out.push(format!("criterion={}", s.criterion.as_deref().unwrap_or("<none>")));
    out.push(format!(
        "status_resource={} robustness={} revisions={} concessions={}",
        s.status_resource, s.robustness, s.revisions.len(), s.concessions.len()
    ));
    for (i, r) in s.revisions.iter().enumerate() {
        out.push(format!("revision[{}].note={}", i + 1, r.note));
        out.push(format!("revision[{}].previous_hash={}", i + 1, r.previous_hash));
    }
    for (i, c) in s.concessions.iter().enumerate() {
        out.push(format!("concession[{}].target={}", i + 1, c.target));
        out.push(format!("concession[{}].reason={}", i + 1, c.reason));
    }
    out.push("[TYPED]".into());
    out.push(project_state_text(s));
    out.push("[RUNTIME FOUNDATION]".into());
    out.push(runtime_state_text(&s.runtime));
    out.join("\n")
}

fn parse_binary(rest: &str) -> Result<(&str, &str), String> {
    let (a, b) = rest.split_once('|').ok_or_else(|| "НУЖЕН ВВОД: используйте форму <позиция-A> | <позиция-B>".to_string())?;
    let a = a.trim();
    let b = b.trim();
    if a.is_empty() || b.is_empty() { return Err("НУЖЕН ВВОД: обе части обязательны".into()); }
    Ok((a, b))
}

fn parse_bool(text: &str) -> Option<bool> {
    match text.trim().to_lowercase().as_str() {
        "true" | "1" | "yes" | "да" => Some(true),
        "false" | "0" | "no" | "нет" => Some(false),
        _ => None,
    }
}

fn definition_frame(name: &str) -> String {
    if name.eq_ignore_ascii_case("functional") {
        "communist-party:functional".into()
    } else {
        name.to_string()
    }
}

fn find_definition<'a>(s: &'a ModelState, name: &str) -> Option<&'a DefinitionRecord> {
    s.definitions.iter().rev().find(|d| d.name.eq_ignore_ascii_case(name))
}

fn find_binding<'a>(s: &'a ModelState, relation: &str) -> Option<&'a BindingRecord> {
    s.bindings.iter().rev().find(|b| b.relation.eq_ignore_ascii_case(relation))
}

fn port(
    id: &str,
    name: &str,
    direction: PortDirection,
    event_type: &str,
    cardinality: PortCardinality,
) -> PortSpec {
    PortSpec {
        id: id.into(),
        name: name.into(),
        direction,
        event_type: event_type.into(),
        cardinality,
    }
}

fn demo_runtime_state() -> RuntimeState {
    let input = NodeSpec {
        id: "n-input".into(),
        node_type: "Input".into(),
        label: "Claim Input".into(),
        implementation_version: 1,
        ports: vec![port("out-claim", "claim", PortDirection::Output, "ClaimEvent", PortCardinality::One)],
    };
    let semantic = NodeSpec {
        id: "n-semantic".into(),
        node_type: "SemanticCheck".into(),
        label: "Semantic Check".into(),
        implementation_version: 1,
        ports: vec![
            port("in-claim", "claim", PortDirection::Input, "ClaimEvent", PortCardinality::One),
            port("out-result", "result", PortDirection::Output, "CheckResult", PortCardinality::One),
        ],
    };
    let counter = NodeSpec {
        id: "n-counter".into(),
        node_type: "CounterCheck".into(),
        label: "Counter Check".into(),
        implementation_version: 1,
        ports: vec![
            port("in-claim", "claim", PortDirection::Input, "ClaimEvent", PortCardinality::One),
            port("out-result", "result", PortDirection::Output, "CheckResult", PortCardinality::One),
        ],
    };
    let compare = NodeSpec {
        id: "n-compare".into(),
        node_type: "Compare".into(),
        label: "Compare / Join".into(),
        implementation_version: 1,
        ports: vec![
            port("in-semantic", "semantic", PortDirection::Input, "CheckResult", PortCardinality::One),
            port("in-counter", "counter", PortDirection::Input, "CheckResult", PortCardinality::One),
            port("out-comparison", "comparison", PortDirection::Output, "CompareResult", PortCardinality::One),
        ],
    };
    let output = NodeSpec {
        id: "n-output".into(),
        node_type: "Output".into(),
        label: "Result Output".into(),
        implementation_version: 1,
        ports: vec![port("in-comparison", "comparison", PortDirection::Input, "CompareResult", PortCardinality::One)],
    };
    let graph = GraphState {
        graph_id: "demo-router-graph".into(),
        revision: 2,
        nodes: vec![input, semantic, counter, compare, output],
        edges: vec![
            EdgeSpec { id: "e-input-semantic".into(), from_node: "n-input".into(), from_port: "out-claim".into(), to_node: "n-semantic".into(), to_port: "in-claim".into(), event_type: "ClaimEvent".into() },
            EdgeSpec { id: "e-input-counter".into(), from_node: "n-input".into(), from_port: "out-claim".into(), to_node: "n-counter".into(), to_port: "in-claim".into(), event_type: "ClaimEvent".into() },
            EdgeSpec { id: "e-semantic-compare".into(), from_node: "n-semantic".into(), from_port: "out-result".into(), to_node: "n-compare".into(), to_port: "in-semantic".into(), event_type: "CheckResult".into() },
            EdgeSpec { id: "e-counter-compare".into(), from_node: "n-counter".into(), from_port: "out-result".into(), to_node: "n-compare".into(), to_port: "in-counter".into(), event_type: "CheckResult".into() },
            EdgeSpec { id: "e-compare-output".into(), from_node: "n-compare".into(), from_port: "out-comparison".into(), to_node: "n-output".into(), to_port: "in-comparison".into(), event_type: "CompareResult".into() },
        ],
    };
    RuntimeState {
        active: true,
        graph,
        events: Vec::new(),
        input_frames: Vec::new(),
        work_items: Vec::new(),
        branch_id: "root".into(),
        correlation_id: "analysis-0".into(),
        iteration: 0,
        next_seq: 1,
    }
}

fn find_node<'a>(graph: &'a GraphState, id: &str) -> Option<&'a NodeSpec> {
    graph.nodes.iter().find(|node| node.id == id)
}

fn find_port<'a>(node: &'a NodeSpec, id: &str) -> Option<&'a PortSpec> {
    node.ports.iter().find(|port| port.id == id)
}

fn validate_graph(graph: &GraphState) -> Vec<String> {
    let mut errors = Vec::new();
    if graph.graph_id.trim().is_empty() {
        errors.push("graph_id пуст".into());
    }

    let mut node_ids: HashSet<&str> = HashSet::new();
    for node in &graph.nodes {
        if !node_ids.insert(node.id.as_str()) {
            errors.push(format!("duplicate node id: {}", node.id));
        }
        let mut port_ids: HashSet<&str> = HashSet::new();
        for port in &node.ports {
            if !port_ids.insert(port.id.as_str()) {
                errors.push(format!("duplicate port id in {}: {}", node.id, port.id));
            }
        }
    }

    let mut edge_ids: HashSet<&str> = HashSet::new();
    for edge in &graph.edges {
        if !edge_ids.insert(edge.id.as_str()) {
            errors.push(format!("duplicate edge id: {}", edge.id));
        }

        let from_node = match find_node(graph, &edge.from_node) {
            Some(node) => node,
            None => {
                errors.push(format!("edge {}: missing from_node {}", edge.id, edge.from_node));
                continue;
            }
        };
        let to_node = match find_node(graph, &edge.to_node) {
            Some(node) => node,
            None => {
                errors.push(format!("edge {}: missing to_node {}", edge.id, edge.to_node));
                continue;
            }
        };
        let from_port = match find_port(from_node, &edge.from_port) {
            Some(port) => port,
            None => {
                errors.push(format!("edge {}: missing output port {}.{}", edge.id, edge.from_node, edge.from_port));
                continue;
            }
        };
        let to_port = match find_port(to_node, &edge.to_port) {
            Some(port) => port,
            None => {
                errors.push(format!("edge {}: missing input port {}.{}", edge.id, edge.to_node, edge.to_port));
                continue;
            }
        };
        if from_port.direction != PortDirection::Output {
            errors.push(format!("edge {}: source port is not Output", edge.id));
        }
        if to_port.direction != PortDirection::Input {
            errors.push(format!("edge {}: target port is not Input", edge.id));
        }
        if from_port.event_type != edge.event_type {
            errors.push(format!(
                "edge {}: source type {} != edge type {}",
                edge.id, from_port.event_type, edge.event_type
            ));
        }
        if to_port.event_type != edge.event_type {
            errors.push(format!(
                "edge {}: target type {} != edge type {}",
                edge.id, to_port.event_type, edge.event_type
            ));
        }
    }
    errors
}


fn append_runtime_event(
    runtime: &mut RuntimeState,
    kind: &str,
    payload_json: String,
    source_node: Option<&str>,
    source_port: Option<&str>,
    parent_event_id: Option<String>,
) -> EventRecord {
    let seq = runtime.next_seq;
    runtime.next_seq = runtime.next_seq.saturating_add(1);
    let event = EventRecord {
        seq,
        event_id: format!("ev-{}", seq),
        kind: kind.into(),
        payload_json,
        source_node: source_node.map(|v| v.to_string()),
        source_port: source_port.map(|v| v.to_string()),
        branch_id: runtime.branch_id.clone(),
        correlation_id: runtime.correlation_id.clone(),
        iteration: runtime.iteration,
        parent_event_id,
    };
    runtime.events.push(event.clone());
    event
}

fn event_by_id<'a>(runtime: &'a RuntimeState, id: &str) -> Option<&'a EventRecord> {
    runtime.events.iter().find(|event| event.event_id == id)
}

fn required_input_ports(graph: &GraphState, node_id: &str) -> Vec<String> {
    match find_node(graph, node_id) {
        Some(node) => node.ports.iter()
            .filter(|p| p.direction == PortDirection::Input && p.cardinality != PortCardinality::Optional)
            .map(|p| p.id.clone())
            .collect(),
        None => Vec::new(),
    }
}

fn route_event(runtime: &mut RuntimeState, event: &EventRecord) -> (usize, usize) {
    let source_node = match event.source_node.as_deref() { Some(v) => v, None => return (0, 0) };
    let source_port = match event.source_port.as_deref() { Some(v) => v, None => return (0, 0) };
    let edges: Vec<EdgeSpec> = runtime.graph.edges.iter()
        .filter(|edge| edge.from_node == source_node && edge.from_port == source_port && edge.event_type == event.kind)
        .cloned()
        .collect();
    let mut routed = 0usize;
    let mut queued = 0usize;

    for edge in edges {
        routed += 1;
        let required = required_input_ports(&runtime.graph, &edge.to_node);
        let frame_idx = match runtime.input_frames.iter().position(|frame|
            frame.node_id == edge.to_node &&
            frame.branch_id == event.branch_id &&
            frame.correlation_id == event.correlation_id &&
            frame.iteration == event.iteration &&
            !frame.ready
        ) {
            Some(i) => i,
            None => {
                let id = format!("frame-{}", runtime.input_frames.len() + 1);
                runtime.input_frames.push(InputFrame {
                    id,
                    node_id: edge.to_node.clone(),
                    branch_id: event.branch_id.clone(),
                    correlation_id: event.correlation_id.clone(),
                    iteration: event.iteration,
                    bindings: Vec::new(),
                    ready: false,
                });
                runtime.input_frames.len() - 1
            }
        };

        let mut became_ready = false;
        let mut input_ids = Vec::new();
        let frame_id;
        {
            let frame = &mut runtime.input_frames[frame_idx];
            frame_id = frame.id.clone();
            if !frame.bindings.iter().any(|b| b.port_id == edge.to_port) {
                frame.bindings.push(InputBinding { port_id: edge.to_port.clone(), event_id: event.event_id.clone() });
            }
            let ready_now = required.iter().all(|port_id| frame.bindings.iter().any(|b| &b.port_id == port_id));
            if ready_now && !frame.ready {
                frame.ready = true;
                became_ready = true;
                input_ids = frame.bindings.iter().map(|b| b.event_id.clone()).collect();
            }
        }
        if became_ready {
            runtime.work_items.push(WorkItem {
                id: format!("work-{}", runtime.work_items.len() + 1),
                node_id: edge.to_node.clone(),
                input_event_ids: input_ids,
                iteration: event.iteration,
                priority: 0,
                budget: 0,
                status: WorkStatus::Queued,
                attempts: 0,
            });
            queued += 1;
            let _ = frame_id;
        }
    }
    (routed, queued)
}

fn runtime_queue_text(runtime: &RuntimeState) -> String {
    let mut out = Vec::new();
    out.push(format!("input_frames={} work_items={}", runtime.input_frames.len(), runtime.work_items.len()));
    for frame in &runtime.input_frames {
        let bindings = frame.bindings.iter()
            .map(|b| format!("{}={}", b.port_id, b.event_id))
            .collect::<Vec<_>>()
            .join(",");
        out.push(format!("frame {} node={} ready={} [{}]", frame.id, frame.node_id, frame.ready, bindings));
    }
    for work in &runtime.work_items {
        out.push(format!(
            "work {} node={} status={:?} attempts={} inputs=[{}]",
            work.id, work.node_id, work.status, work.attempts, work.input_event_ids.join(",")
        ));
    }
    out.join("\n")
}

fn runtime_events_text(runtime: &RuntimeState) -> String {
    if runtime.events.is_empty() { return "events=0".into(); }
    let mut out = vec![format!("events={}", runtime.events.len())];
    for event in &runtime.events {
        out.push(format!(
            "#{} {} kind={} source={}.{} parent={} payload={}",
            event.seq,
            event.event_id,
            event.kind,
            event.source_node.as_deref().unwrap_or("<external>"),
            event.source_port.as_deref().unwrap_or("<none>"),
            event.parent_event_id.as_deref().unwrap_or("<none>"),
            event.payload_json
        ));
    }
    out.join("\n")
}

fn payload_claim(event: &EventRecord) -> String {
    serde_json::from_str::<serde_json::Value>(&event.payload_json)
        .ok()
        .and_then(|v| v.get("claim").and_then(|x| x.as_str()).map(|x| x.to_string()))
        .unwrap_or_else(|| event.payload_json.clone())
}

fn execute_one_runtime_work(runtime: &mut RuntimeState) -> String {
    let work_idx = match runtime.work_items.iter().position(|w| w.status == WorkStatus::Queued) {
        Some(i) => i,
        None => return "QUEUE EMPTY: нет Queued WorkItem".into(),
    };
    runtime.work_items[work_idx].status = WorkStatus::Running;
    runtime.work_items[work_idx].attempts = runtime.work_items[work_idx].attempts.saturating_add(1);
    let work = runtime.work_items[work_idx].clone();
    let node = match find_node(&runtime.graph, &work.node_id).cloned() {
        Some(n) => n,
        None => {
            runtime.work_items[work_idx].status = WorkStatus::Rejected;
            return format!("REJECTED {}: node {} missing", work.id, work.node_id);
        }
    };

    let mut emitted: Option<EventRecord> = None;
    let detail: String;
    match node.node_type.as_str() {
        "SemanticCheck" => {
            let input = work.input_event_ids.first().and_then(|id| event_by_id(runtime, id));
            let claim = input.map(payload_claim).unwrap_or_else(|| "<missing>".into());
            let parent = input.map(|e| e.event_id.clone());
            let payload = serde_json::json!({"check":"semantic","outcome":"Support","claim":claim}).to_string();
            let event = append_runtime_event(runtime, "CheckResult", payload, Some(&node.id), Some("out-result"), parent);
            detail = "SemanticCheck -> Support".into();
            emitted = Some(event);
        }
        "CounterCheck" => {
            let input = work.input_event_ids.first().and_then(|id| event_by_id(runtime, id));
            let claim = input.map(payload_claim).unwrap_or_else(|| "<missing>".into());
            let parent = input.map(|e| e.event_id.clone());
            let payload = serde_json::json!({"check":"counter","outcome":"Conflict","claim":claim}).to_string();
            let event = append_runtime_event(runtime, "CheckResult", payload, Some(&node.id), Some("out-result"), parent);
            detail = "CounterCheck -> Conflict".into();
            emitted = Some(event);
        }
        "Compare" => {
            let mut semantic = "<missing>".to_string();
            let mut counter = "<missing>".to_string();
            for id in &work.input_event_ids {
                if let Some(event) = event_by_id(runtime, id) {
                    if let Ok(v) = serde_json::from_str::<serde_json::Value>(&event.payload_json) {
                        let check = v.get("check").and_then(|x| x.as_str()).unwrap_or("");
                        let outcome = v.get("outcome").and_then(|x| x.as_str()).unwrap_or("<unknown>");
                        if check == "semantic" { semantic = outcome.to_string(); }
                        if check == "counter" { counter = outcome.to_string(); }
                    }
                }
            }
            let overall = if semantic == "Conflict" || counter == "Conflict" { "Conflict" } else { "Support" };
            let payload = serde_json::json!({"semantic":semantic,"counter":counter,"outcome":overall}).to_string();
            let parent = work.input_event_ids.last().cloned();
            let event = append_runtime_event(runtime, "CompareResult", payload, Some(&node.id), Some("out-comparison"), parent);
            detail = format!("Compare -> {}", overall);
            emitted = Some(event);
        }
        "Output" => {
            let payload = work.input_event_ids.first()
                .and_then(|id| event_by_id(runtime, id))
                .map(|e| e.payload_json.clone())
                .unwrap_or_else(|| "<missing>".into());
            detail = format!("Output consumed {}", payload);
        }
        _ => {
            if let Some(item) = runtime.work_items.iter_mut().find(|w| w.id == work.id) {
                item.status = WorkStatus::Rejected;
            }
            return format!("REJECTED {}: unsupported node_type={}", work.id, node.node_type);
        }
    }

    if let Some(item) = runtime.work_items.iter_mut().find(|w| w.id == work.id) {
        item.status = WorkStatus::Completed;
    }
    let mut routed = 0usize;
    let mut queued = 0usize;
    let emitted_id = if let Some(event) = emitted.as_ref() {
        let id = event.event_id.clone();
        let result = route_event(runtime, event);
        routed = result.0;
        queued = result.1;
        id
    } else {
        "<none>".into()
    };
    format!(
        "STEP {} node={} COMPLETED\n{}\nemitted={} routed={} newly_queued={}",
        work.id, work.node_id, detail, emitted_id, routed, queued
    )
}

fn runtime_state_text(runtime: &RuntimeState) -> String {
    if !runtime.active {
        return "runtime.active=false\nОжидаю: runtime init demo".into();
    }
    let mut out = Vec::new();
    out.push(format!("runtime.active={}", runtime.active));
    out.push(format!(
        "graph={} revision={} nodes={} edges={}",
        runtime.graph.graph_id,
        runtime.graph.revision,
        runtime.graph.nodes.len(),
        runtime.graph.edges.len()
    ));
    out.push(format!(
        "branch={} correlation={} iteration={} next_seq={}",
        runtime.branch_id, runtime.correlation_id, runtime.iteration, runtime.next_seq
    ));
    out.push(format!(
        "events={} input_frames={} work_items={}",
        runtime.events.len(), runtime.input_frames.len(), runtime.work_items.len()
    ));
    for node in &runtime.graph.nodes {
        out.push(format!(
            "node {} type={} impl=v{} label={}",
            node.id, node.node_type, node.implementation_version, node.label
        ));
        for port in &node.ports {
            out.push(format!(
                "  port {} {:?} type={} cardinality={:?}",
                port.id, port.direction, port.event_type, port.cardinality
            ));
        }
    }
    for edge in &runtime.graph.edges {
        out.push(format!(
            "edge {} {}.{} -> {}.{} type={}",
            edge.id, edge.from_node, edge.from_port, edge.to_node, edge.to_port, edge.event_type
        ));
    }
    out.join("\n")
}

fn reset_dispute(s: &mut ModelState) {
    s.debate_name = None;
    s.resolution = None;
    s.collision_a = None;
    s.collision_b = None;
    s.function_context = None;
    s.criterion = None;
    s.committed = false;
    s.step = 0;
    s.status_resource = 100;
    s.robustness = 100;
    s.revisions.clear();
    s.concessions.clear();
}

fn command_impl(input: &str) -> String {
    let cmd = input.trim();
    let lc = cmd.to_lowercase();

    if lc == "help" || lc == "помощь" { return help_text(); }
    if lc == "system version" || lc == "beta version" || lc == "версия" || lc == "версия системы" {
        return format!("version={} code={} [Rust graph-runtime foundation + typed + dispute]", VERSION, VERSION_CODE);
    }
    if lc == "system state" || lc == "debate state" || lc == "состояние" || lc == "состояние системы" {
        let s = state().lock().unwrap();
        return system_state_text(&s);
    }
    if lc == "system reset" {
        *state().lock().unwrap() = ModelState::default();
        return "OK system reset: dispute + typed + runtime + local values cleared".into();
    }
    if lc == "model audit" {
        let s = state().lock().unwrap();
        return format!("model_hash={}", canonical_model_hash(&s));
    }
    if lc == "proof audit" {
        let s = state().lock().unwrap();
        if !s.project.active || s.project.phase != 6 || s.project.result.is_none() {
            return "ОШИБКА: proof ещё не завершён; сначала доведите typed-операцию до resume".into();
        }
        return format!("proof_hash={}", canonical_proof_hash(&s));
    }
    if lc == "model status" {
        let s = state().lock().unwrap();
        return format!(
            "model={} status_resource={} robustness={} concessions={} committed={}",
            if s.revisions.is_empty() { "base".to_string() } else { format!("rev-{}", s.revisions.len()) },
            s.status_resource,
            s.robustness,
            s.concessions.len(),
            s.committed
        );
    }
    if lc == "project state" {
        let s = state().lock().unwrap();
        return project_state_text(&s);
    }
    if lc == "runtime reset" {
        let mut s = state().lock().unwrap();
        s.runtime = RuntimeState::default();
        return "OK runtime reset".into();
    }
    if lc == "runtime init demo" {
        let mut s = state().lock().unwrap();
        s.runtime = demo_runtime_state();
        return "OK runtime demo initialized: Input -> Semantic/Counter -> Compare -> Output\ngraph=demo-router-graph revision=2 nodes=5 edges=5".into();
    }
    if lc == "runtime state" || lc == "runtime graph" {
        let s = state().lock().unwrap();
        return runtime_state_text(&s.runtime);
    }
    if lc == "runtime validate" {
        let s = state().lock().unwrap();
        if !s.runtime.active {
            return "ОШИБКА: runtime не инициализирован; используйте runtime init demo".into();
        }
        let errors = validate_graph(&s.runtime.graph);
        if errors.is_empty() {
            return format!(
                "VALID graph={} revision={} nodes={} edges={}",
                s.runtime.graph.graph_id,
                s.runtime.graph.revision,
                s.runtime.graph.nodes.len(),
                s.runtime.graph.edges.len()
            );
        }
        let mut out = vec![format!("INVALID graph={} errors={}", s.runtime.graph.graph_id, errors.len())];
        for error in errors {
            out.push(format!("- {}", error));
        }
        return out.join("\n");
    }
    if lc == "runtime queue" {
        let s = state().lock().unwrap();
        if !s.runtime.active { return "ОШИБКА: runtime не инициализирован".into(); }
        return runtime_queue_text(&s.runtime);
    }
    if lc == "runtime events" {
        let s = state().lock().unwrap();
        if !s.runtime.active { return "ОШИБКА: runtime не инициализирован".into(); }
        return runtime_events_text(&s.runtime);
    }
    if lc == "runtime emit claim" {
        return "НУЖЕН ВВОД: runtime emit claim <text>".into();
    }
    if lc.starts_with("runtime emit claim ") {
        let text = cmd["runtime emit claim ".len()..].trim();
        if text.is_empty() { return "НУЖЕН ВВОД: runtime emit claim <text>".into(); }
        let mut s = state().lock().unwrap();
        if !s.runtime.active { return "ОШИБКА: runtime не инициализирован; используйте runtime init demo".into(); }
        let errors = validate_graph(&s.runtime.graph);
        if !errors.is_empty() { return format!("ОШИБКА: graph invalid; errors={}", errors.len()); }
        let payload = serde_json::json!({"claim": text}).to_string();
        let event = append_runtime_event(&mut s.runtime, "ClaimEvent", payload, Some("n-input"), Some("out-claim"), None);
        let (routed, queued) = route_event(&mut s.runtime, &event);
        return format!(
            "EMIT {} kind=ClaimEvent claim={}\nrouted={} newly_queued={}\n{}",
            event.event_id,
            text,
            routed,
            queued,
            runtime_queue_text(&s.runtime)
        );
    }
    if lc == "runtime step" {
        let mut s = state().lock().unwrap();
        if !s.runtime.active { return "ОШИБКА: runtime не инициализирован".into(); }
        return execute_one_runtime_work(&mut s.runtime);
    }
    if lc.starts_with("calc ") {
        let expr = cmd[5..].trim();
        let p: Vec<&str> = expr.split_whitespace().collect();
        if p.len() != 3 { return "использование: calc <int> <+|-|*> <int>".into(); }
        let a: i64 = match p[0].parse() { Ok(v) => v, Err(_) => return "ОШИБКА: неверное левое целое".into() };
        let b: i64 = match p[2].parse() { Ok(v) => v, Err(_) => return "ОШИБКА: неверное правое целое".into() };
        let r = match p[1] {
            "+" => a.wrapping_add(b),
            "-" => a.wrapping_sub(b),
            "*" => a.wrapping_mul(b),
            _ => return "оператор должен быть одним из: + - *".into(),
        };
        return format!("{} {} {} = {} [Rust]", a, p[1], b, r);
    }

    // --- typed operator vertical slice ---
    if lc == "project reset" {
        let mut s = state().lock().unwrap();
        s.project = ProjectState::default();
        s.bindings.clear();
        return "OK project reset; local definitions preserved; project bindings cleared".into();
    }
    if lc.starts_with("project new ") {
        let name = cmd["project new ".len()..].trim();
        if name.is_empty() { return "НУЖЕН ВВОД: project new <name>".into(); }
        let mut s = state().lock().unwrap();
        if s.project.active { return "ОШИБКА: typed-проект уже активен; сначала project reset".into(); }
        s.project = ProjectState {
            active: true,
            name: Some(name.to_string()),
            claim: None,
            operator: None,
            phase: 1,
            expected_concept_frame: None,
            expected_relation: None,
            result: None,
        };
        return format!("OK project created: {}", name);
    }
    if lc.starts_with("claim ") {
        let claim = cmd["claim ".len()..].trim();
        if claim.is_empty() { return "НУЖЕН ВВОД: claim <name>".into(); }
        let mut s = state().lock().unwrap();
        if !s.project.active || s.project.phase != 1 { return "ОШИБКА: claim сейчас не ожидается".into(); }
        s.project.claim = Some(claim.to_string());
        s.project.phase = 2;
        return format!("OK claim accepted: {}", claim);
    }
    if lc == "run classify.exclude" {
        let mut s = state().lock().unwrap();
        if !s.project.active || s.project.phase != 2 || s.project.claim.is_none() {
            return "ОШИБКА: сначала project new <name> и claim <name>".into();
        }
        s.project.operator = Some("classify.exclude".into());
        let expected_frame = "communist-party:functional".to_string();
        s.project.expected_concept_frame = Some(expected_frame.clone());
        let claim_upper = s.project.claim.as_deref().unwrap_or("").to_uppercase();
        let expected_relation = format!("follows_communist_principles({})", claim_upper);
        s.project.expected_relation = Some(expected_relation.clone());

        if find_definition(&s, "functional").is_none() {
            s.project.phase = 3;
            return format!("NEED_INPUT concept_frame: {}", expected_frame);
        }
        if find_binding(&s, "follows_communist_principles").is_none() {
            s.project.phase = 4;
            return format!("NEED_INPUT relation: {}", expected_relation);
        }
        s.project.phase = 5;
        return "READY: resume".into();
    }
    if lc.starts_with("definition create ") {
        let name = cmd["definition create ".len()..].trim();
        if name.is_empty() { return "НУЖЕН ВВОД: definition create <name>".into(); }
        let mut s = state().lock().unwrap();
        if !s.project.active || s.project.phase != 3 {
            return "ОШИБКА: definition сейчас не запрошена активной операцией".into();
        }
        let frame = definition_frame(name);
        s.definitions.retain(|d| !d.name.eq_ignore_ascii_case(name));
        s.definitions.push(DefinitionRecord { name: name.to_string(), frame: frame.clone() });
        s.project.expected_concept_frame = Some(frame.clone());
        s.project.phase = 4;
        let relation = s.project.expected_relation.clone().unwrap_or_else(|| "follows_communist_principles(?)".into());
        return format!("OK definition created: {} -> {}\nNEED_INPUT relation: {}", name, frame, relation);
    }
    if lc.starts_with("bind ") {
        let rest = cmd["bind ".len()..].trim();
        let mut parts = rest.split_whitespace();
        let relation = match parts.next() { Some(v) => v.trim(), None => return "НУЖЕН ВВОД: bind <relation> <true|false>".into() };
        let value_text = match parts.next() { Some(v) => v.trim(), None => return "НУЖЕН ВВОД: bind <relation> <true|false>".into() };
        if parts.next().is_some() { return "ОШИБКА: bind принимает relation и одно boolean-значение".into(); }
        let value = match parse_bool(value_text) { Some(v) => v, None => return "ОШИБКА: значение должно быть true/false (также да/нет)".into() };
        let mut s = state().lock().unwrap();
        if !s.project.active || s.project.phase != 4 {
            return "ОШИБКА: bind сейчас не запрошен активной операцией".into();
        }
        if !relation.eq_ignore_ascii_case("follows_communist_principles") {
            return format!("ОШИБКА: ожидается relation follows_communist_principles, получено {}", relation);
        }
        s.bindings.retain(|b| !b.relation.eq_ignore_ascii_case(relation));
        s.bindings.push(BindingRecord { relation: relation.to_string(), value });
        s.project.phase = 5;
        return format!("OK binding accepted: {}={}", relation, value);
    }
    if lc == "resume" {
        let mut s = state().lock().unwrap();
        if !s.project.active || s.project.phase != 5 {
            return "ОШИБКА: нет операции, готовой к resume".into();
        }
        if s.project.operator.as_deref() != Some("classify.exclude") {
            return "ОШИБКА: неизвестная приостановленная операция".into();
        }
        let claim = match s.project.claim.clone() { Some(v) => v, None => return "ОШИБКА: claim отсутствует".into() };
        let frame = match find_definition(&s, "functional") {
            Some(v) => v.frame.clone(),
            None => return "NEED_INPUT concept_frame: communist-party:functional".into(),
        };
        let relation_value = match find_binding(&s, "follows_communist_principles") {
            Some(v) => v.value,
            None => {
                let rel = s.project.expected_relation.clone().unwrap_or_else(|| "follows_communist_principles(?)".into());
                return format!("NEED_INPUT relation: {}", rel);
            }
        };
        let verdict = if relation_value { "IN" } else { "OUT" };
        let result = format!("{} {} {}", claim.to_uppercase(), verdict, frame);
        s.project.result = Some(result.clone());
        s.project.phase = 6;
        return result;
    }

    // --- dispute state machine ---
    if lc == "debate reset" {
        let mut s = state().lock().unwrap();
        reset_dispute(&mut s);
        return "OK debate reset".into();
    }
    if lc.starts_with("debate new ") {
        let name = cmd["debate new ".len()..].trim();
        if name.is_empty() { return "НУЖЕН ВВОД: debate new <name>".into(); }
        let mut s = state().lock().unwrap();
        if s.debate_name.is_some() { return "ОШИБКА: активное dispute-состояние уже существует; сначала debate reset".into(); }
        s.debate_name = Some(name.to_string());
        s.step = 1;
        return format!("OK debate created: {}", name);
    }
    if lc == "resolution" {
        return "НУЖЕН ВВОД: resolution <text>".into();
    }
    if lc.starts_with("resolution ") {
        let text = cmd["resolution ".len()..].trim();
        if text.is_empty() { return "НУЖЕН ВВОД: resolution <text>".into(); }
        let mut s = state().lock().unwrap();
        if let Err(e) = require_debate(&s) { return e; }
        if s.step != 1 { return "ОШИБКА: неверный порядок перехода".into(); }
        s.resolution = Some(text.to_string());
        s.step = 2;
        return format!("OK resolution accepted: {}", text);
    }
    if lc == "collision open" {
        return "НУЖЕН ВВОД: collision open <position-a> | <position-b>".into();
    }
    if lc.starts_with("collision open ") {
        let rest = cmd["collision open ".len()..].trim();
        let (a, b) = match parse_binary(rest) { Ok(v) => v, Err(e) => return e };
        let mut s = state().lock().unwrap();
        if s.step != 2 || s.resolution.is_none() { return "ОШИБКА: неверный порядок перехода".into(); }
        s.collision_a = Some(a.to_string());
        s.collision_b = Some(b.to_string());
        s.step = 3;
        return format!("OK collision open\nA: {}\nB: {}", a, b);
    }
    if lc == "function accept" {
        return "НУЖЕН ВВОД: function accept <function/context>".into();
    }
    if lc.starts_with("function accept ") {
        let text = cmd["function accept ".len()..].trim();
        if text.is_empty() { return "НУЖЕН ВВОД: function accept <function/context>".into(); }
        let mut s = state().lock().unwrap();
        if s.step != 3 || s.collision_a.is_none() || s.collision_b.is_none() { return "ОШИБКА: неверный порядок перехода".into(); }
        s.function_context = Some(text.to_string());
        s.step = 4;
        return format!("OK function/context accepted: {}", text);
    }
    if lc == "criterion accept" {
        return "НУЖЕН ВВОД: criterion accept <criterion>".into();
    }
    if lc.starts_with("criterion accept ") {
        let text = cmd["criterion accept ".len()..].trim();
        if text.is_empty() { return "НУЖЕН ВВОД: criterion accept <criterion>".into(); }
        let mut s = state().lock().unwrap();
        if s.step != 4 || s.function_context.is_none() { return "ОШИБКА: неверный порядок перехода".into(); }
        s.criterion = Some(text.to_string());
        s.step = 5;
        return format!("OK criterion accepted: {}", text);
    }
    if lc == "commit" {
        let mut s = state().lock().unwrap();
        if s.step != 5 || s.criterion.is_none() { return "ОШИБКА: неверный порядок перехода".into(); }
        s.committed = true;
        s.step = 6;
        s.robustness = s.robustness.saturating_add(1);
        return format!("COMMITTED: frame locked\nmodel_hash={}", canonical_model_hash(&s));
    }
    if lc == "model revise" {
        return "НУЖЕН ВВОД: model revise <text>".into();
    }
    if lc.starts_with("model revise ") {
        let note = cmd["model revise ".len()..].trim();
        if note.is_empty() { return "НУЖЕН ВВОД: model revise <text>".into(); }
        let mut s = state().lock().unwrap();
        if !s.committed { return "ОШИБКА: модель ещё не commit".into(); }
        let old_hash = canonical_model_hash(&s);
        let old_fn = s.function_context.clone();
        let old_cr = s.criterion.clone();
        s.revisions.push(RevisionRecord {
            note: note.to_string(),
            previous_function_context: old_fn,
            previous_criterion: old_cr,
            previous_hash: old_hash,
        });
        s.status_resource = s.status_resource.saturating_sub(10);
        s.robustness = s.robustness.saturating_sub(5);
        s.function_context = None;
        s.criterion = None;
        s.committed = false;
        s.step = 3;
        return format!("OK revision recorded; frame reopened: {}", note);
    }
    if lc == "model concede" {
        return "НУЖЕН ВВОД: model concede <target> | <reason>".into();
    }
    if lc.starts_with("model concede ") {
        let rest = cmd["model concede ".len()..].trim();
        let parsed = if rest.contains('|') {
            parse_binary(rest).map(|(a,b)| (a.to_string(), b.to_string()))
        } else {
            match rest.split_once(' ') {
                Some((a,b)) if !a.trim().is_empty() && !b.trim().is_empty() => Ok((a.trim().to_string(), b.trim().to_string())),
                _ => Err("НУЖЕН ВВОД: model concede <target> | <reason>".into()),
            }
        };
        let (target, reason) = match parsed { Ok(v) => v, Err(e) => return e };
        let mut s = state().lock().unwrap();
        if let Err(e) = require_debate(&s) { return e; }
        s.concessions.push(ConcessionRecord { target: target.clone(), reason: reason.clone() });
        s.status_resource = s.status_resource.saturating_sub(2);
        s.robustness = s.robustness.saturating_add(1);
        return format!("OK local concession recorded\ntarget={}\nreason={}", target, reason);
    }

    "НЕИЗВЕСТНАЯ КОМАНДА; введи help".into()
}

fn to_jstring(mut env: JNIEnv, text: String) -> jstring {
    match env.new_string(text) {
        Ok(s) => s.into_raw(),
        Err(_) => ptr::null_mut(),
    }
}

#[no_mangle]
pub extern "system" fn Java_io_typedcalculus_console_NativeBridge_command(
    mut env: JNIEnv,
    _class: JClass,
    input: JString,
) -> jstring {
    let text: String = match env.get_string(&input) {
        Ok(s) => s.into(),
        Err(_) => return to_jstring(env, "ОШИБКА: некорректный UTF-8 ввод".into()),
    };
    to_jstring(env, command_impl(&text))
}

#[no_mangle]
pub extern "system" fn Java_io_typedcalculus_console_NativeBridge_expectation(
    env: JNIEnv,
    _class: JClass,
) -> jstring {
    let s = state().lock().unwrap();
    to_jstring(env, expectation_for(&s))
}

#[no_mangle]
pub extern "system" fn Java_io_typedcalculus_console_NativeBridge_exportState(
    env: JNIEnv,
    _class: JClass,
) -> jstring {
    let s = state().lock().unwrap();
    let text = serde_json::to_string(&*s).unwrap_or_else(|_| "{}".into());
    to_jstring(env, text)
}

#[no_mangle]
pub extern "system" fn Java_io_typedcalculus_console_NativeBridge_importState(
    mut env: JNIEnv,
    _class: JClass,
    input: JString,
) -> jboolean {
    let text: String = match env.get_string(&input) {
        Ok(s) => s.into(),
        Err(_) => return JNI_FALSE,
    };
    let parsed: ModelState = match serde_json::from_str(&text) {
        Ok(v) => v,
        Err(_) => return JNI_FALSE,
    };
    if parsed.schema != 2 { return JNI_FALSE; }
    *state().lock().unwrap() = parsed;
    JNI_TRUE
}
