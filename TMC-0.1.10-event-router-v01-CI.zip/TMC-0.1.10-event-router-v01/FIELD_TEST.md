# FIELD TEST — TMC 0.1.10-event-router-v01

Запустить один сценарий:

```text
runtime reset
runtime init demo
runtime validate
runtime emit claim <государство управляет ресурсами>
runtime queue
runtime step
runtime step
runtime queue
runtime step
runtime step
runtime events
runtime state
```

## Ожидаемые контрольные точки

После `runtime validate`:

```text
VALID graph=demo-router-graph revision=2 nodes=5 edges=5
```

После `runtime emit claim ...`:

```text
EMIT ev-1 kind=ClaimEvent
routed=2 newly_queued=2
```

В queue должны быть два независимых задания:

```text
work-1 node=n-semantic status=Queued
work-2 node=n-counter status=Queued
```

После первого `runtime step`:
- SemanticCheck завершён;
- записан `ev-2 kind=CheckResult`;
- Compare ещё НЕ должен быть queued, потому что второй вход join отсутствует.

После второго `runtime step`:
- CounterCheck завершён;
- записан `ev-3 kind=CheckResult`;
- frame `n-compare` становится `ready=true`;
- появляется `work-3 node=n-compare status=Queued`.

Третий `runtime step`:

```text
Compare -> Conflict
```

и должен породить `ev-4 kind=CompareResult`, после чего queued становится Output.

Четвёртый `runtime step` исполняет Output без нового события.

Финально:

```text
events=4
input_frames=4
work_items=4
```

Все четыре WorkItem должны быть `Completed`.

Это закрывает проверку fan-out + typed routing + join + пошаговой очереди. Платформенный JNI/Android smoke-test повторять не требуется.
