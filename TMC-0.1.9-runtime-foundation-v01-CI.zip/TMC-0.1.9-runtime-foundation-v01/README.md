# TMC 0.1.9-runtime-foundation-v01

Первый архитектурный патч новой ветки runtime. Текущие dispute- и typed-операции сохранены как regression surface.

## Что добавлено

В Rust введены базовые структуры нового вычислительного слоя:

- `GraphState`
- `NodeSpec`
- `PortSpec`
- `EdgeSpec`
- `EventRecord`
- `InputFrame`
- `WorkItem`
- `RuntimeState`
- `PortDirection`
- `PortCardinality`
- `WorkStatus`

Runtime хранится внутри общего Rust-state и экспортируется через прежний JNI/SharedPreferences механизм. Старое состояние 0.1.8 без поля `runtime` импортируется через `serde(default)`; dispute/proof hashes не включают runtime и не меняют прежнюю семантику аудита.

## Новые команды

```text
runtime init demo
runtime validate
runtime state
runtime reset
```

`runtime init demo` создаёт typed topology:

```text
Claim Input
    |
    | ClaimEvent
    v
Foundation Check
    |
    | CheckResult
    v
Result Output
```

`runtime validate` проверяет:

- уникальность Node/Port/Edge IDs;
- наличие source/target nodes;
- наличие source/target ports;
- направление Output -> Input;
- соответствие `event_type` на Edge и обоих Ports.

## Что сознательно НЕ реализовано в 0.1.9

Этот патч не исполняет Graph. `EventRecord`, `InputFrame` и `WorkItem` пока являются foundation data model. Router, fan-out, InputFrame activation и WorkQueue execution относятся к 0.1.10-event-router.

Цель 0.1.9 — проверить, что новая topology-модель живёт параллельно старому calculus, валидируется, сохраняется и восстанавливается без rewrite существующей ветки.
