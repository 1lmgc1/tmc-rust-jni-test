# FIELD TEST — TMC 0.1.9-runtime-foundation-v01

Тестировать только новый архитектурный слой и сохранение regression surface. Повторный platform/JNI smoke-test не нужен.

## 1. Версия

```text
system version
```

Ожидается:

```text
version=0.1.9-runtime-foundation-v01 code=16 [Rust graph-runtime foundation + typed + dispute]
```

## 2. Создание typed Graph

```text
runtime reset
runtime init demo
```

Ожидается:

```text
OK runtime demo initialized: Input -> Check -> Output
graph=demo-graph revision=1 nodes=3 edges=2
```

## 3. Валидация topology

```text
runtime validate
```

Ожидается:

```text
VALID graph=demo-graph revision=1 nodes=3 edges=2
```

## 4. Просмотр foundation state

```text
runtime state
```

Должны присутствовать:

```text
runtime.active=true
graph=demo-graph revision=1 nodes=3 edges=2
branch=root correlation=analysis-0 iteration=0 next_seq=1
events=0 input_frames=0 work_items=0
```

И три Node:

```text
n-input
n-check
n-output
```

Два Edge:

```text
e-input-check n-input.out-claim -> n-check.in-claim type=ClaimEvent
e-check-output n-check.out-result -> n-output.in-result type=CheckResult
```

## 5. Persistence

После `runtime init demo` полностью закрыть приложение / дать системе выгрузить Activity, затем открыть снова и выполнить:

```text
runtime state
```

Graph должен восстановиться без повторного `runtime init demo`.

## 6. Короткая regression-проверка старых режимов

Не нужно заново прогонять весь прошлый тест. Достаточно убедиться, что команды распознаются:

```text
project state
model status
help
```

Если runtime foundation работает и старые команды не сломаны — патч принят.
