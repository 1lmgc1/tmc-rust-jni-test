use jni::objects::{JClass, JString};
use jni::sys::{jboolean, jstring, JNI_FALSE, JNI_TRUE};
use jni::JNIEnv;
use serde::{Deserialize, Serialize};
use std::ptr;
use std::sync::{Mutex, OnceLock};

const VERSION: &str = "0.1.6-content-v01";
const VERSION_CODE: u32 = 13;

#[derive(Debug, Clone, Serialize, Deserialize)]
struct RevisionRecord {
    note: String,
    previous_function_context: Option<String>,
    previous_criterion: Option<String>,
    previous_hash: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct ConcessionRecord {
    target: String,
    reason: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct ModelState {
    schema: u32,
    debate_name: Option<String>,
    resolution: Option<String>,
    collision_a: Option<String>,
    collision_b: Option<String>,
    function_context: Option<String>,
    criterion: Option<String>,
    committed: bool,
    step: u8,
    status_resource: u8,
    robustness: u8,
    revisions: Vec<RevisionRecord>,
    concessions: Vec<ConcessionRecord>,
}

impl Default for ModelState {
    fn default() -> Self {
        Self {
            schema: 2,
            debate_name: None,
            resolution: None,
            collision_a: None,
            collision_b: None,
            function_context: None,
            criterion: None,
            committed: false,
            step: 0,
            status_resource: 100,
            robustness: 100,
            revisions: Vec::new(),
            concessions: Vec::new(),
        }
    }
}

static STATE: OnceLock<Mutex<ModelState>> = OnceLock::new();
fn state() -> &'static Mutex<ModelState> { STATE.get_or_init(|| Mutex::new(ModelState::default())) }

fn fnv1a64(bytes: &[u8]) -> u64 {
    let mut h = 0xcbf29ce484222325u64;
    for &b in bytes {
        h ^= b as u64;
        h = h.wrapping_mul(0x100000001b3);
    }
    h
}

fn canonical_hash(s: &ModelState) -> String {
    let data = serde_json::to_vec(s).unwrap_or_default();
    format!("{:016x}", fnv1a64(&data))
}

fn require_debate(s: &ModelState) -> Result<(), String> {
    if s.debate_name.is_none() { Err("ERROR: debate not created".into()) } else { Ok(()) }
}

fn expectation_for(s: &ModelState) -> String {
    match s.step {
        0 => "debate new <name>".into(),
        1 => "resolution <text>".into(),
        2 => "collision open <position-a> | <position-b>".into(),
        3 => "function accept <function/context>".into(),
        4 => "criterion accept <criterion>".into(),
        5 => "commit".into(),
        _ => "model audit | model status | model revise <text> | model concede <target> | <reason>".into(),
    }
}

fn help_text() -> String {
    [
        "system version | system state",
        "calc 7 + 5",
        "debate reset | debate new <name>",
        "resolution <text>",
        "collision open <position-a> | <position-b>",
        "function accept <function/context>",
        "criterion accept <criterion> | commit",
        "model audit | model status",
        "model revise <text>",
        "model concede <target> | <reason>",
    ].join("\n")
}

fn system_state_text(s: &ModelState) -> String {
    let mut out = Vec::new();
    out.push(format!("step={} committed={}", s.step, s.committed));
    out.push(format!("debate={}", s.debate_name.as_deref().unwrap_or("<none>")));
    out.push(format!("resolution={}", s.resolution.as_deref().unwrap_or("<none>")));
    out.push(format!("collision.a={}", s.collision_a.as_deref().unwrap_or("<none>")));
    out.push(format!("collision.b={}", s.collision_b.as_deref().unwrap_or("<none>")));
    out.push(format!("function_context={}", s.function_context.as_deref().unwrap_or("<none>")));
    out.push(format!("criterion={}", s.criterion.as_deref().unwrap_or("<none>")));
    out.push(format!(
        "status_resource={} robustness={} revisions={} concessions={}",
        s.status_resource, s.robustness, s.revisions.len(), s.concessions.len()
    ));
    for (i, r) in s.revisions.iter().enumerate() {
        out.push(format!("revision[{}].note={}", i + 1, r.note));
        out.push(format!("revision[{}].previous_hash={}", i + 1, r.previous_hash));
    }
    for (i, c) in s.concessions.iter().enumerate() {
        out.push(format!("concession[{}].target={}", i + 1, c.target));
        out.push(format!("concession[{}].reason={}", i + 1, c.reason));
    }
    out.join("\n")
}

fn parse_binary(rest: &str) -> Result<(&str, &str), String> {
    let (a, b) = rest.split_once('|').ok_or_else(|| "NEED_INPUT use: <position-a> | <position-b>".to_string())?;
    let a = a.trim();
    let b = b.trim();
    if a.is_empty() || b.is_empty() { return Err("NEED_INPUT both positions are required".into()); }
    Ok((a, b))
}

fn command_impl(input: &str) -> String {
    let cmd = input.trim();
    let lc = cmd.to_lowercase();

    if lc == "help" { return help_text(); }
    if lc == "system version" || lc == "beta version" {
        return format!("version={} code={} [Rust content core]", VERSION, VERSION_CODE);
    }
    if lc == "system state" || lc == "debate state" {
        let s = state().lock().unwrap();
        return system_state_text(&s);
    }
    if lc == "model audit" || lc == "proof audit" {
        let s = state().lock().unwrap();
        return format!("model_hash={}", canonical_hash(&s));
    }
    if lc == "model status" {
        let s = state().lock().unwrap();
        return format!(
            "model={} status_resource={} robustness={} concessions={} committed={}",
            if s.revisions.is_empty() { "base".to_string() } else { format!("rev-{}", s.revisions.len()) },
            s.status_resource,
            s.robustness,
            s.concessions.len(),
            s.committed
        );
    }
    if lc.starts_with("calc ") {
        let expr = cmd[5..].trim();
        let p: Vec<&str> = expr.split_whitespace().collect();
        if p.len() != 3 { return "usage: calc <int> <+|-|*> <int>".into(); }
        let a: i64 = match p[0].parse() { Ok(v) => v, Err(_) => return "ERROR: invalid left integer".into() };
        let b: i64 = match p[2].parse() { Ok(v) => v, Err(_) => return "ERROR: invalid right integer".into() };
        let r = match p[1] {
            "+" => a.wrapping_add(b),
            "-" => a.wrapping_sub(b),
            "*" => a.wrapping_mul(b),
            _ => return "operator must be + - *".into(),
        };
        return format!("{} {} {} = {} [Rust]", a, p[1], b, r);
    }

    if lc == "debate reset" {
        *state().lock().unwrap() = ModelState::default();
        return "OK debate reset".into();
    }
    if lc.starts_with("debate new ") {
        let name = cmd["debate new ".len()..].trim();
        if name.is_empty() { return "NEED_INPUT debate name".into(); }
        let mut s = state().lock().unwrap();
        if s.debate_name.is_some() { return "ERROR: active state exists; debate reset first".into(); }
        s.debate_name = Some(name.to_string());
        s.step = 1;
        return format!("OK debate created: {}", name);
    }
    if lc == "resolution" {
        return "NEED_INPUT resolution <text>".into();
    }
    if lc.starts_with("resolution ") {
        let text = cmd["resolution ".len()..].trim();
        if text.is_empty() { return "NEED_INPUT resolution <text>".into(); }
        let mut s = state().lock().unwrap();
        if let Err(e) = require_debate(&s) { return e; }
        if s.step != 1 { return "ERROR: invalid transition/order".into(); }
        s.resolution = Some(text.to_string());
        s.step = 2;
        return format!("OK resolution accepted: {}", text);
    }
    if lc == "collision open" {
        return "NEED_INPUT collision open <position-a> | <position-b>".into();
    }
    if lc.starts_with("collision open ") {
        let rest = cmd["collision open ".len()..].trim();
        let (a, b) = match parse_binary(rest) { Ok(v) => v, Err(e) => return e };
        let mut s = state().lock().unwrap();
        if s.step != 2 || s.resolution.is_none() { return "ERROR: invalid transition/order".into(); }
        s.collision_a = Some(a.to_string());
        s.collision_b = Some(b.to_string());
        s.step = 3;
        return format!("OK collision open\nA: {}\nB: {}", a, b);
    }
    if lc == "function accept" {
        return "NEED_INPUT function accept <function/context>".into();
    }
    if lc.starts_with("function accept ") {
        let text = cmd["function accept ".len()..].trim();
        if text.is_empty() { return "NEED_INPUT function accept <function/context>".into(); }
        let mut s = state().lock().unwrap();
        if s.step != 3 || s.collision_a.is_none() || s.collision_b.is_none() { return "ERROR: invalid transition/order".into(); }
        s.function_context = Some(text.to_string());
        s.step = 4;
        return format!("OK function/context accepted: {}", text);
    }
    if lc == "criterion accept" {
        return "NEED_INPUT criterion accept <criterion>".into();
    }
    if lc.starts_with("criterion accept ") {
        let text = cmd["criterion accept ".len()..].trim();
        if text.is_empty() { return "NEED_INPUT criterion accept <criterion>".into(); }
        let mut s = state().lock().unwrap();
        if s.step != 4 || s.function_context.is_none() { return "ERROR: invalid transition/order".into(); }
        s.criterion = Some(text.to_string());
        s.step = 5;
        return format!("OK criterion accepted: {}", text);
    }
    if lc == "commit" {
        let mut s = state().lock().unwrap();
        if s.step != 5 || s.criterion.is_none() { return "ERROR: invalid transition/order".into(); }
        s.committed = true;
        s.step = 6;
        s.robustness = s.robustness.saturating_add(1);
        return format!("COMMITTED: frame locked\nmodel_hash={}", canonical_hash(&s));
    }
    if lc == "model revise" {
        return "NEED_INPUT model revise <text>".into();
    }
    if lc.starts_with("model revise ") {
        let note = cmd["model revise ".len()..].trim();
        if note.is_empty() { return "NEED_INPUT model revise <text>".into(); }
        let mut s = state().lock().unwrap();
        if !s.committed { return "ERROR: model is not committed".into(); }
        let old_hash = canonical_hash(&s);
        let old_fn = s.function_context.clone();
        let old_cr = s.criterion.clone();
        s.revisions.push(RevisionRecord {
            note: note.to_string(),
            previous_function_context: old_fn,
            previous_criterion: old_cr,
            previous_hash: old_hash,
        });
        s.status_resource = s.status_resource.saturating_sub(10);
        s.robustness = s.robustness.saturating_sub(5);
        s.function_context = None;
        s.criterion = None;
        s.committed = false;
        s.step = 3;
        return format!("OK revision recorded; frame reopened: {}", note);
    }
    if lc == "model concede" {
        return "NEED_INPUT model concede <target> | <reason>".into();
    }
    if lc.starts_with("model concede ") {
        let rest = cmd["model concede ".len()..].trim();
        let parsed = if rest.contains('|') {
            parse_binary(rest).map(|(a,b)| (a.to_string(), b.to_string()))
        } else {
            match rest.split_once(' ') {
                Some((a,b)) if !a.trim().is_empty() && !b.trim().is_empty() => Ok((a.trim().to_string(), b.trim().to_string())),
                _ => Err("NEED_INPUT model concede <target> | <reason>".into()),
            }
        };
        let (target, reason) = match parsed { Ok(v) => v, Err(e) => return e };
        let mut s = state().lock().unwrap();
        if let Err(e) = require_debate(&s) { return e; }
        s.concessions.push(ConcessionRecord { target: target.clone(), reason: reason.clone() });
        s.status_resource = s.status_resource.saturating_sub(2);
        s.robustness = s.robustness.saturating_add(1);
        return format!("OK local concession recorded\ntarget={}\nreason={}", target, reason);
    }

    "UNKNOWN; enter help".into()
}

fn to_jstring(mut env: JNIEnv, text: String) -> jstring {
    match env.new_string(text) {
        Ok(s) => s.into_raw(),
        Err(_) => ptr::null_mut(),
    }
}

#[no_mangle]
pub extern "system" fn Java_io_typedcalculus_console_NativeBridge_command(
    mut env: JNIEnv,
    _class: JClass,
    input: JString,
) -> jstring {
    let text: String = match env.get_string(&input) {
        Ok(s) => s.into(),
        Err(_) => return to_jstring(env, "ERROR: invalid UTF-8 input".into()),
    };
    to_jstring(env, command_impl(&text))
}

#[no_mangle]
pub extern "system" fn Java_io_typedcalculus_console_NativeBridge_expectation(
    env: JNIEnv,
    _class: JClass,
) -> jstring {
    let s = state().lock().unwrap();
    to_jstring(env, expectation_for(&s))
}

#[no_mangle]
pub extern "system" fn Java_io_typedcalculus_console_NativeBridge_exportState(
    env: JNIEnv,
    _class: JClass,
) -> jstring {
    let s = state().lock().unwrap();
    let text = serde_json::to_string(&*s).unwrap_or_else(|_| "{}".into());
    to_jstring(env, text)
}

#[no_mangle]
pub extern "system" fn Java_io_typedcalculus_console_NativeBridge_importState(
    mut env: JNIEnv,
    _class: JClass,
    input: JString,
) -> jboolean {
    let text: String = match env.get_string(&input) {
        Ok(s) => s.into(),
        Err(_) => return JNI_FALSE,
    };
    let parsed: ModelState = match serde_json::from_str(&text) {
        Ok(v) => v,
        Err(_) => return JNI_FALSE,
    };
    if parsed.schema != 2 { return JNI_FALSE; }
    *state().lock().unwrap() = parsed;
    JNI_TRUE
}
