# Field test — 0.1.6-content-v01

Expected installation: update over 0.1.5-core-v01 (same package and DEV certificate).

Run this exact content test:

```text
system version
debate reset
debate new state-resource-test
resolution Государство управляет ресурсами
collision open Государство распределяет ресурс | Государство только координирует доступ
function accept анализ функции управления ресурсом в политическом контексте
criterion accept выигрывает модель, лучше различающая управление, распределение и координацию
commit
system state
model audit
model revise уточнить функцию: отделить управление от распределения
function accept анализ различия управления и распределения ресурса
criterion accept модель должна различать полномочие, фактическое действие и ресурсную роль
commit
model audit
model concede позиция-B | координация доступа не тождественна распределению ресурса
system state
```

Pass conditions:

1. Every content string appears in `system state`.
2. First and second `model audit` hashes differ after revision and recommit.
3. Revision history preserves the previous audit hash and note.
4. Concession target/reason appear in `system state`.
5. Kill the app from recents and reopen it: `state restored [content-v2]` appears and `system state` still contains content.
