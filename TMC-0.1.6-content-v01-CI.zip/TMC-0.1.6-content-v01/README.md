# Typed Modular Calculus 0.1.6-content-v01

First content-bearing dispute build after the 0.1.5 state-machine test.

Architecture: Android Java host -> JNI -> Rust arm64 content core.
No Kotlin runtime.

## Content commands

- `debate new <name>`
- `resolution <text>`
- `collision open <position-a> | <position-b>`
- `function accept <function/context>`
- `criterion accept <criterion>`
- `commit`
- `model audit`
- `model status`
- `model revise <text>`
- `model concede <target> | <reason>`
- `system state`

The Rust state is serialized as JSON and persisted by the Java host in SharedPreferences.
The audit hash is stable FNV-1a over canonical Rust state serialization, so content changes affect the hash.

`model revise <text>` preserves a revision record containing the previous function/context,
criterion, and audit hash, then reopens the frame at the function/context stage.
