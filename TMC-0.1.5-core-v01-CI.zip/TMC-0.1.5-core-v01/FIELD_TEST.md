# Field test 0.1.5-core-v01

ONE-TIME INSTALL NOTE: uninstall the previous `0.0.4-rust-jni-test` first because GitHub's previous debug APK used a different ephemeral debug certificate. From 0.1.5 onward this project includes a fixed public DEV signer, so later test APKs can update in place.

Run:

```text
system version
calc 7 + 5
debate reset
debate new demo
resolution
collision open
function accept
criterion accept
commit
model audit
debate state
model status
```

Expected essentials:
- `version=0.1.5-core-v01 code=12 [Rust core]`
- `7 + 5 = 12 [Rust]`
- expectation advances through the dispute steps
- commit reaches step 6
- model audit prints a stable `model_hash=...` for an unchanged state

Then:

```text
model revise
model status
function accept
criterion accept
commit
model concede
debate state
```

Revision should lower status/robustness and increment revisions; concession should increment concessions, slightly lower status and slightly increase robustness.

Persistence test: force-stop the app, reopen, then run `debate state`. State must be restored.
