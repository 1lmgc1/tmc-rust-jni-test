# Typed Modular Calculus 0.1.5-core-v01

First retained working baseline after Android/Java/JNI/Rust field validation.

Architecture: Android 14 Java host -> JNI -> Rust arm64-v8a.
No Kotlin runtime or Compose dependency.

Implemented now:
- Rust arithmetic (+, -, *)
- dispute-v0 state machine in Rust
- status resource / robustness / revision / concession counters
- deterministic model audit hash
- state export/import through JNI and SharedPreferences persistence
- adaptive one-screen phone console with explicit "Ожидаю"

Not implemented yet:
- typed operator calculus / definition DB vertical scenario
- SQLite
- external APIs / dictionary adapters
- rule/content patches
- PackageInstaller updater

The bundled PKCS#12 key is a PUBLIC DEVELOPMENT KEY only. It exists so future CI APKs can update this dev branch in place. Never use it for production.
