use core::ffi::c_void;
use core::sync::atomic::{AtomicU64, Ordering};

static STATE: AtomicU64 = AtomicU64::new(0);

const STEP_MASK: u64 = 0xff;
const F_DEBATE: u64 = 1 << 8;
const F_RESOLUTION: u64 = 1 << 9;
const F_COLLISION: u64 = 1 << 10;
const F_FUNCTION: u64 = 1 << 11;
const F_CRITERION: u64 = 1 << 12;
const F_COMMITTED: u64 = 1 << 13;
const F_OPEN: u64 = 1 << 14;

const STATUS_SHIFT: u32 = 16;
const ROBUST_SHIFT: u32 = 24;
const REV_SHIFT: u32 = 32;
const CONC_SHIFT: u32 = 40;

const ERR_NO_DEBATE: i64 = -1001;
const ERR_ORDER: i64 = -1002;
const ERR_ALREADY: i64 = -1003;
const ERR_NOT_COMMITTED: i64 = -1004;
const ERR_BAD_STATE: i64 = -1005;

fn step(s: u64) -> u8 { (s & STEP_MASK) as u8 }
fn with_step(s: u64, v: u8) -> u64 { (s & !STEP_MASK) | v as u64 }
fn field(s: u64, shift: u32) -> u8 { ((s >> shift) & 0xff) as u8 }
fn with_field(s: u64, shift: u32, v: u8) -> u64 {
    (s & !(0xffu64 << shift)) | ((v as u64) << shift)
}
fn sat_add(v: u8, d: i16) -> u8 {
    let n = v as i16 + d;
    n.clamp(0, 255) as u8
}
fn save(s: u64) -> i64 { STATE.store(s, Ordering::SeqCst); s as i64 }

fn audit_hash(mut x: u64) -> u64 {
    x ^= 0x544d_435f_4449_5350; // "TMC_DISP" domain separator
    x ^= x >> 30;
    x = x.wrapping_mul(0xbf58_476d_1ce4_e5b9);
    x ^= x >> 27;
    x = x.wrapping_mul(0x94d0_49bb_1331_11eb);
    x ^ (x >> 31)
}

#[no_mangle]
pub extern "system" fn Java_io_typedcalculus_console_NativeBridge_execute(
    _env: *mut c_void,
    _class: *mut c_void,
    op: i32,
    a: i64,
    b: i64,
) -> i64 {
    match op {
        1 => a.wrapping_add(b),
        2 => a.wrapping_sub(b),
        3 => a.wrapping_mul(b),

        100 => save(0),
        101 => {
            let old = STATE.load(Ordering::SeqCst);
            if old != 0 { return ERR_ALREADY; }
            let mut s = F_DEBATE | F_OPEN;
            s = with_step(s, 1);
            s = with_field(s, STATUS_SHIFT, 100);
            s = with_field(s, ROBUST_SHIFT, 100);
            save(s)
        }
        102 => {
            let mut s = STATE.load(Ordering::SeqCst);
            if s & F_DEBATE == 0 { return ERR_NO_DEBATE; }
            if step(s) != 1 { return ERR_ORDER; }
            s |= F_RESOLUTION;
            s = with_step(s, 2);
            save(s)
        }
        103 => {
            let mut s = STATE.load(Ordering::SeqCst);
            if s & F_RESOLUTION == 0 || step(s) != 2 { return ERR_ORDER; }
            s |= F_COLLISION;
            s = with_step(s, 3);
            save(s)
        }
        104 => {
            let mut s = STATE.load(Ordering::SeqCst);
            if s & F_COLLISION == 0 || step(s) != 3 { return ERR_ORDER; }
            s |= F_FUNCTION;
            s = with_step(s, 4);
            save(s)
        }
        105 => {
            let mut s = STATE.load(Ordering::SeqCst);
            if s & F_FUNCTION == 0 || step(s) != 4 { return ERR_ORDER; }
            s |= F_CRITERION;
            s = with_step(s, 5);
            save(s)
        }
        106 => {
            let mut s = STATE.load(Ordering::SeqCst);
            if s & F_CRITERION == 0 || step(s) != 5 { return ERR_ORDER; }
            s |= F_COMMITTED;
            s = with_step(s, 6);
            let r = sat_add(field(s, ROBUST_SHIFT), 1);
            s = with_field(s, ROBUST_SHIFT, r);
            save(s)
        }
        107 => audit_hash(STATE.load(Ordering::SeqCst)) as i64,
        108 | 111 | 120 => STATE.load(Ordering::SeqCst) as i64,
        109 => {
            let mut s = STATE.load(Ordering::SeqCst);
            if s & F_COMMITTED == 0 { return ERR_NOT_COMMITTED; }
            let rev = field(s, REV_SHIFT).saturating_add(1);
            let status = sat_add(field(s, STATUS_SHIFT), -10);
            let robust = sat_add(field(s, ROBUST_SHIFT), -5);
            s = with_field(s, REV_SHIFT, rev);
            s = with_field(s, STATUS_SHIFT, status);
            s = with_field(s, ROBUST_SHIFT, robust);
            s &= !(F_FUNCTION | F_CRITERION | F_COMMITTED);
            s = with_step(s, 3);
            save(s)
        }
        110 => {
            let mut s = STATE.load(Ordering::SeqCst);
            if s & F_DEBATE == 0 { return ERR_NO_DEBATE; }
            let c = field(s, CONC_SHIFT).saturating_add(1);
            let status = sat_add(field(s, STATUS_SHIFT), -2);
            let robust = sat_add(field(s, ROBUST_SHIFT), 1);
            s = with_field(s, CONC_SHIFT, c);
            s = with_field(s, STATUS_SHIFT, status);
            s = with_field(s, ROBUST_SHIFT, robust);
            save(s)
        }
        121 => {
            if a < 0 { return ERR_BAD_STATE; }
            let s = a as u64;
            if s != 0 && s & F_DEBATE == 0 { return ERR_BAD_STATE; }
            save(s)
        }
        _ => i64::MIN,
    }
}
