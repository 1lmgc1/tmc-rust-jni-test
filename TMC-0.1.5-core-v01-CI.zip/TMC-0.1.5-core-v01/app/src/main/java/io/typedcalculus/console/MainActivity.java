package io.typedcalculus.console;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.Locale;

public final class MainActivity extends Activity {
    private static final String VERSION = "0.1.5-core-v01";
    private static final int VERSION_CODE = 12;
    private TextView output;
    private EditText input;
    private ScrollView scroll;
    private SharedPreferences prefs;
    private boolean nativeReady;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
        prefs = getSharedPreferences("tmc", MODE_PRIVATE);
        println("TMC " + VERSION);
        println("Java host / Rust core / Android 14 arm64");
        try {
            NativeBridge.load();
            nativeReady = true;
            long saved = prefs.getLong("rust_state", 0L);
            if (saved != 0L) {
                long r = NativeBridge.execute(121, saved, 0);
                if (r >= 0) println("state restored: 0x" + Long.toHexString(r));
                else println("state restore rejected: " + errorText(r));
            }
            printExpectation();
        } catch (Throwable t) {
            println("NATIVE ERROR: " + t.getClass().getSimpleName() + ": " + t.getMessage());
        }
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(8), dp(8), dp(8), dp(8));
        root.setBackgroundColor(Color.rgb(46,46,46));

        scroll = new ScrollView(this);
        output = new TextView(this);
        output.setTextColor(Color.LTGRAY);
        output.setTextSize(17f);
        output.setGravity(Gravity.START);
        output.setTextIsSelectable(true);
        scroll.addView(output, new ScrollView.LayoutParams(-1,-2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1f));

        input = new EditText(this);
        input.setHint("> command");
        input.setSingleLine(true);
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(Color.LTGRAY);
        input.setImeOptions(EditorInfo.IME_ACTION_SEND);
        root.addView(input, new LinearLayout.LayoutParams(-1,-2));

        Button send = new Button(this);
        send.setText("SEND");
        root.addView(send, new LinearLayout.LayoutParams(-1,-2));
        send.setOnClickListener(v -> dispatch());
        input.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                dispatch(); return true;
            }
            return false;
        });
        setContentView(root);
    }

    private void dispatch() {
        String cmd = input.getText().toString().trim();
        input.setText("");
        if (cmd.isEmpty()) return;
        println("> " + cmd);
        if (!nativeReady) { println("native core unavailable"); return; }
        try { handle(cmd); }
        catch (Throwable t) { println("ERROR: " + t.getClass().getSimpleName() + ": " + t.getMessage()); }
        printExpectation();
    }

    private void handle(String cmd) {
        String lc = cmd.toLowerCase(Locale.ROOT);
        if (lc.equals("help")) { printHelp(); return; }
        if (lc.equals("system version") || lc.equals("beta version")) {
            println("version=" + VERSION + " code=" + VERSION_CODE + " [Rust core]"); return;
        }
        if (lc.startsWith("calc ")) { handleCalc(cmd.substring(5).trim()); return; }
        if (lc.equals("debate reset")) { mutate(100, "OK debate reset"); return; }
        if (lc.startsWith("debate new ")) {
            String name = cmd.substring("debate new ".length()).trim();
            if (name.isEmpty()) { println("NEED_INPUT debate name"); return; }
            mutate(101, "OK debate created: " + name); return;
        }
        if (lc.equals("resolution")) { mutate(102, "OK resolution accepted"); return; }
        if (lc.equals("collision open")) { mutate(103, "OK collision open"); return; }
        if (lc.equals("function accept")) { mutate(104, "OK function/context accepted"); return; }
        if (lc.equals("criterion accept")) { mutate(105, "OK criterion accepted"); return; }
        if (lc.equals("commit")) { mutate(106, "COMMITTED: frame locked"); return; }
        if (lc.equals("model audit") || lc.equals("proof audit")) {
            long h = NativeBridge.execute(107,0,0);
            println("model_hash=" + Long.toUnsignedString(h,16)); return;
        }
        if (lc.equals("debate state") || lc.equals("system state")) { printState(); return; }
        if (lc.equals("model status")) { printStatus(); return; }
        if (lc.equals("model revise")) { mutate(109, "OK revision recorded; frame reopened"); return; }
        if (lc.equals("model concede")) { mutate(110, "OK local concession recorded"); return; }
        println("UNKNOWN; enter help");
    }

    private void handleCalc(String expr) {
        String[] p = expr.split("\\s+");
        if (p.length != 3) { println("usage: calc <int> <+|-|*> <int>"); return; }
        long a = Long.parseLong(p[0]); long b = Long.parseLong(p[2]);
        int op = p[1].equals("+") ? 1 : p[1].equals("-") ? 2 : p[1].equals("*") ? 3 : 0;
        if (op == 0) { println("operator must be + - *"); return; }
        long r = NativeBridge.execute(op,a,b);
        println(a + " " + p[1] + " " + b + " = " + r + " [Rust]");
    }

    private void mutate(int op, String ok) {
        long r = NativeBridge.execute(op,0,0);
        if (r < 0) { println(errorText(r)); return; }
        saveState(); println(ok);
    }

    private void saveState() {
        long s = NativeBridge.execute(120,0,0);
        prefs.edit().putLong("rust_state", s).apply();
    }

    private void printState() {
        long s = NativeBridge.execute(108,0,0);
        println("STATE=0x" + Long.toHexString(s));
        println("step=" + step(s) + " status=" + field(s,16) + " robustness=" + field(s,24)
                + " revisions=" + field(s,32) + " concessions=" + field(s,40));
        println("flags debate=" + bit(s,8) + " resolution=" + bit(s,9) + " collision=" + bit(s,10)
                + " function=" + bit(s,11) + " criterion=" + bit(s,12) + " committed=" + bit(s,13));
    }

    private void printStatus() {
        long s = NativeBridge.execute(111,0,0);
        int rev = field(s,32);
        println("model=" + (rev == 0 ? "base" : "rev-" + rev)
                + " status_resource=" + field(s,16)
                + " robustness=" + field(s,24)
                + " concessions=" + field(s,40));
    }

    private void printExpectation() {
        if (!nativeReady) return;
        long s = NativeBridge.execute(108,0,0);
        int st = step(s);
        String next;
        switch (st) {
            case 0: next="debate new <name>"; break;
            case 1: next="resolution"; break;
            case 2: next="collision open"; break;
            case 3: next="function accept"; break;
            case 4: next="criterion accept"; break;
            case 5: next="commit"; break;
            default: next="model audit | model revise | model concede";
        }
        println("Ожидаю: " + next);
    }

    private void printHelp() {
        println("system version | system state");
        println("calc 7 + 5");
        println("debate reset | debate new <name>");
        println("resolution | collision open | function accept | criterion accept | commit");
        println("model audit | model status | model revise | model concede");
    }

    private String errorText(long code) {
        if (code == -1001) return "ERROR: debate not created";
        if (code == -1002) return "ERROR: invalid transition/order";
        if (code == -1003) return "ERROR: active state exists; debate reset first";
        if (code == -1004) return "ERROR: model is not committed";
        if (code == -1005) return "ERROR: invalid persisted state";
        return "ERROR native code=" + code;
    }

    private static int step(long s) { return (int)(s & 0xffL); }
    private static int field(long s, int shift) { return (int)((s >>> shift) & 0xffL); }
    private static boolean bit(long s, int bit) { return (s & (1L << bit)) != 0; }
    private void println(String s) {
        output.append(s); output.append("\n");
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }
    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }
}
