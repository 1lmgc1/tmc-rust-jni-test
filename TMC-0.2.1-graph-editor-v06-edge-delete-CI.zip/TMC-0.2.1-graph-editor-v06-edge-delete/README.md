# TMC 0.2.1-graph-editor-v06-edge-delete

Patch A1 поверх `v05-buildfix-v01`: пользовательское управление существующим Edge теперь закрывается в Graph UI без консоли. Runtime/EventLog semantics не перерабатывались.

## Что изменено

- В `EDIT` Edge имеет hit-test по фактическому ортогональному route.
- Тап по Edge выбирает его; выбранная связь рисуется утолщённой жёлтой линией.
- `УДАЛИТЬ` работает контекстно: сначала удаляет выбранный Edge, иначе выбранный пользовательский Node.
- Удаление Edge выполняется только через существующую Rust-команду `graph edge remove <edge-id>`. Java не мутирует topology самостоятельно.
- После успешной Rust mutation `MainActivity` сохраняет state и заново получает `uiSnapshot()`.
- Выбор Edge — только transient Java projection state; после удаления он исчезает, а topology остаётся Rust-owned.

## Инварианты A1

- `GraphState` и graph revision принадлежат Rust.
- `GraphEdgeRemoved` создаётся существующей Rust-операцией; история undo/redo получает предыдущий полный `GraphState`.
- Действует тот же `topology_edit_allowed()` lock, что для остальных structural edits.
- Типизация Edge, Router, Queue, Scheduler, ResourceLedger, EventLog и runtime execution semantics в этом patch не менялись.
- Никакого Java-side удаления из snapshot/list как источника истины нет.

## UX

```text
EDIT: ВКЛ
→ тап по линии Edge
→ Edge подсвечен жёлтым
→ УДАЛИТЬ
```

После удаления можно использовать `ОТМЕНИТЬ` / `ПОВТОРИТЬ`.

## Rust commands, на которые опирается UI

```text
graph edge remove <edge-id>
graph undo
graph redo
runtime reset
```

## Scope

В A1 сознательно не реализованы collapsed/expanded Node, subgraph, EventLog redesign, ALL rewrite, branch/replay/EvolutionProfile и CI overhaul.

## Известные вопросы вне A1

- `resolveStoredOverlaps()` остаётся Java render/layout projection и требует отдельного определения ownership.
- Durable EventLog verification/reconstructability и `ALL` требуют отдельных runtime patches по roadmap.

## Ревизия фактической базы v05

Проверено по текущему `rust/src/lib.rs`, Java/JNI, Gradle и переданному workflow; это очередь следующих patch, а не изменения A1.

- **A1 gap подтверждён:** Rust уже умел `graph edge remove`, но Graph UI не умел выбрать Edge и вызвать удаление.
- **EventLog B1 подтверждён:** `storage verify` делает SQLite `integrity_check` и считает durable rows, но hash-chain проверяет через `verify_runtime_event_chain(&s.runtime)`, а не читает `event_log` напрямую.
- **Reset-chain ambiguity подтверждена:** `runtime reset` заменяет runtime на `RuntimeState::default()`, а новая runtime chain начинает predecessor с `GENESIS`, хотя `seq` при следующем `runtime init demo` продолжает durable SQLite offset.
- **Restore rewrite подтверждён:** `initialize_storage()` и JNI `importState()` вызывают `normalize_runtime_event_chain()`, которая пересчитывает `previous_hash/event_hash`.
- **Hash:** текущая цепочка использует FNV-1a 64; это deterministic fingerprint, не полноценный tamper-evident audit hash.
- **Reconstructability пока недостаточна:** `graph layout set` меняет GraphState/revision без semantic Event; `GraphUndo/GraphRedo` не содержат полного diff/state reference. Checkpoint поэтому сейчас сильнее EventLog как источник graph projection.
- **ALL finding подтверждён:** `InputBinding` хранит только `port_id,event_id`, а routing дедуплицирует по `port_id`; несколько upstream producers одного `ALL`-порта не различаются. Старый проверенный join доказывает multi-input join, но не полную semantics `ALL = все ожидаемые producers`.
- **Layout ownership finding подтверждён:** `GraphView.resolveStoredOverlaps()` может визуально сместить Rust-stored coordinates без обратной записи.
- **Automated suite отсутствует:** в bundle нет `#[test]`; CI строит Rust/Android и проверяет наличие исходного `.so`/APK, но не раскрывает APK и не проверяет embedded ABI/signature/runtime invariants.

## Последовательный roadmap после field-test A1

```text
A2 collapsed/expanded Node
A3 basic subgraph contract + implementation
A4 0.2.1 closure/validation
B1 durable EventLog verification
B2 audit hash/identity
B3 reconstructable graph history
B4 ALL/InputFrame correctness
C1 Rust regression suite
C2 CI proof
D analysis-lab contracts → первый содержательный case
```

A2 не начинать до результата телефонного field-test A1.
