# FIELD TEST — TMC 0.2.1-graph-editor-v06-edge-delete

## A1 — Edge delete / undo / redo / restart

1. Открыть `ГРАФ`, нажать `INIT`, включить `EDIT`.
2. Тапнуть по любой линии Edge.
   - Ожидание: Edge становится жёлтым; строка действия показывает его `edge-id` и endpoints.
3. Нажать `УДАЛИТЬ`.
   - Ожидание: Edge исчезает, `graph revision` увеличивается.
4. Нажать `ОТМЕНИТЬ`.
   - Ожидание: Edge возвращается.
5. Нажать `ПОВТОРИТЬ`.
   - Ожидание: Edge снова исчезает.
6. Полностью закрыть и снова открыть приложение.
   - Ожидание: Edge остаётся удалённым.

## Topology lock

1. `INIT`, затем `RUN` или начать execution так, чтобы появились non-Graph events/work state.
2. В `EDIT` выбрать Edge и нажать `УДАЛИТЬ`.
   - Ожидание: Rust отвечает `topology lock`; Edge остаётся в snapshot.

## Обязательный runtime regression

В консоли выполнить пакет:

```text
runtime reset
runtime init demo
runtime validate
runtime emit claim <A1 regression>
runtime run
runtime ledger
storage verify
```

Ожидание: demo topology валидна; execution не сломан; ledger и storage verification отвечают как в предыдущей рабочей версии.

> `storage verify` здесь является regression check существующей реализации, а не доказательством будущей B1 semantics durable EventLog verification.
