package io.typedcalculus.console;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class MainActivity extends Activity {
    private static final String VERSION = "0.2.1-graph-editor-v06-edge-delete";

    private TextView output;
    private EditText input;
    private ScrollView scroll;
    private SharedPreferences prefs;
    private boolean nativeReady;
    private boolean sqliteReady;
    private final ArrayDeque<String> commandQueue = new ArrayDeque<>();

    private LinearLayout graphPane;
    private LinearLayout consolePane;
    private GraphView graphView;
    private TextView graphTelemetry;
    private TextView graphAction;
    private Button graphTab;
    private Button consoleTab;
    private Button editorButton;
    private LinearLayout paletteContainer;
    private Button paletteToggle;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
        prefs = getSharedPreferences("tmc", MODE_PRIVATE);
        printGreeting();
        try {
            NativeBridge.load();
            nativeReady = true;

            String dbPath = new java.io.File(getFilesDir(), "tmc-runtime.sqlite3").getAbsolutePath();
            String storage = NativeBridge.initStorage(dbPath);
            if (storage != null && storage.startsWith("RESTORED")) {
                sqliteReady = true;
                println("SQLite: состояние восстановлено; " + storage);
            } else if (storage != null && storage.startsWith("EMPTY")) {
                sqliteReady = true;
                println("SQLite: создан новый durable store; " + storage);
                String saved = prefs.getString("rust_state_json_v2", null);
                if (saved != null && !saved.isEmpty()) {
                    boolean ok = NativeBridge.importState(saved);
                    println(ok ? "Миграция SharedPreferences → SQLite: OK" : "Миграция SharedPreferences → SQLite: отклонена");
                } else {
                    String checkpoint = NativeBridge.persistStorage();
                    println("SQLite: " + checkpoint);
                }
            } else {
                println("SQLite недоступен: " + storage);
                String saved = prefs.getString("rust_state_json_v2", null);
                if (saved != null && !saved.isEmpty()) {
                    boolean ok = NativeBridge.importState(saved);
                    println(ok ? "Fallback SharedPreferences: состояние восстановлено" : "Fallback SharedPreferences: состояние не принято");
                }
            }
            printExpectation();
            showGraph();
            refreshGraph();
        } catch (Throwable t) {
            println("ОШИБКА NATIVE: " + t.getClass().getSimpleName() + ": " + t.getMessage());
            graphAction.setText("NATIVE ERROR: " + t.getClass().getSimpleName());
        }
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(31, 33, 36));

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        tabs.setPadding(dp(6), dp(4), dp(6), dp(2));

        graphTab = new Button(this);
        graphTab.setText("ГРАФ");
        tabs.addView(graphTab, new LinearLayout.LayoutParams(0, -2, 1f));

        consoleTab = new Button(this);
        consoleTab.setText("КОНСОЛЬ");
        tabs.addView(consoleTab, new LinearLayout.LayoutParams(0, -2, 1f));
        root.addView(tabs, new LinearLayout.LayoutParams(-1, -2));

        graphPane = buildGraphPane();
        consolePane = buildConsolePane();
        root.addView(graphPane, new LinearLayout.LayoutParams(-1, 0, 1f));
        root.addView(consolePane, new LinearLayout.LayoutParams(-1, 0, 1f));

        graphTab.setOnClickListener(v -> showGraph());
        consoleTab.setOnClickListener(v -> showConsole());

        setContentView(root);
        showGraph();
    }

    private LinearLayout buildGraphPane() {
        LinearLayout pane = new LinearLayout(this);
        pane.setOrientation(LinearLayout.VERTICAL);
        pane.setPadding(dp(7), dp(4), dp(7), dp(7));

        graphTelemetry = new TextView(this);
        graphTelemetry.setTextColor(Color.WHITE);
        graphTelemetry.setTextSize(14f);
        graphTelemetry.setGravity(Gravity.START);
        graphTelemetry.setPadding(dp(6), dp(5), dp(6), dp(5));
        graphTelemetry.setText("runtime: загрузка…");
        pane.addView(graphTelemetry, new LinearLayout.LayoutParams(-1, -2));

        graphAction = new TextView(this);
        graphAction.setTextColor(Color.LTGRAY);
        graphAction.setTextSize(12f);
        graphAction.setPadding(dp(6), 0, dp(6), dp(5));
        graphAction.setMaxLines(4);
        graphAction.setText("EDIT: двигай Node; OUT → совместимый IN создаёт typed Edge; тап Edge → выбор → УДАЛИТЬ.");
        pane.addView(graphAction, new LinearLayout.LayoutParams(-1, -2));

        graphView = new GraphView(this);
        graphView.setListener(new GraphView.Listener() {
            @Override public void onNodeMoved(String nodeId, float xDp, float yDp) {
                String cmd = String.format(Locale.US, "graph layout set %s %.1f %.1f", nodeId, xDp, yDp);
                runGraphCommand(cmd, false);
            }

            @Override public void onConnect(String fromNode, String fromPort, String toNode, String toPort) {
                runGraphCommand("graph edge add " + fromNode + "." + fromPort + " " + toNode + "." + toPort, false);
            }

            @Override public void onNodeSelected(String nodeId, String label, String type) {
                graphAction.setText("Выбран Node: " + label + "  [" + nodeId + "]  type=" + type);
            }

            @Override public void onEdgeSelected(String edgeId, String fromNode, String fromPort, String toNode, String toPort, String eventType) {
                graphAction.setText("Выбран Edge: " + edgeId + "  " + fromNode + "." + fromPort + " → " + toNode + "." + toPort + "  [" + eventType + "]. Нажми УДАЛИТЬ.");
            }

            @Override public void onEditorMessage(String message) {
                graphAction.setText(message);
            }
        });
        pane.addView(graphView, new LinearLayout.LayoutParams(-1, 0, 1f));

        paletteToggle = makeButton("ПАЛИТРА ▼");
        pane.addView(paletteToggle, new LinearLayout.LayoutParams(-1, -2));

        paletteContainer = new LinearLayout(this);
        paletteContainer.setOrientation(LinearLayout.VERTICAL);

        TextView opsLabel = new TextView(this);
        opsLabel.setText("ОПЕРАЦИИ");
        opsLabel.setTextColor(Color.LTGRAY);
        opsLabel.setTextSize(10f);
        opsLabel.setPadding(dp(4), dp(2), dp(4), 0);
        paletteContainer.addView(opsLabel, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout ops = new LinearLayout(this);
        ops.setOrientation(LinearLayout.HORIZONTAL);
        Button init = makeButton("INIT");
        Button step = makeButton("STEP");
        Button run = makeButton("RUN");
        Button reset = makeButton("СБРОС");
        ops.addView(init, new LinearLayout.LayoutParams(0, -2, 1f));
        ops.addView(step, new LinearLayout.LayoutParams(0, -2, 1f));
        ops.addView(run, new LinearLayout.LayoutParams(0, -2, 1f));
        ops.addView(reset, new LinearLayout.LayoutParams(0, -2, 1f));
        paletteContainer.addView(ops, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout diag = new LinearLayout(this);
        diag.setOrientation(LinearLayout.HORIZONTAL);
        Button refresh = makeButton("ОБНОВИТЬ");
        Button fit = makeButton("ВПИСАТЬ");
        Button queue = makeButton("ОЧЕРЕДЬ");
        Button events = makeButton("СОБЫТИЯ");
        Button ledger = makeButton("РЕСУРС");
        diag.addView(refresh, new LinearLayout.LayoutParams(0, -2, 1f));
        diag.addView(fit, new LinearLayout.LayoutParams(0, -2, 1f));
        diag.addView(queue, new LinearLayout.LayoutParams(0, -2, 1f));
        diag.addView(events, new LinearLayout.LayoutParams(0, -2, 1f));
        diag.addView(ledger, new LinearLayout.LayoutParams(0, -2, 1f));
        paletteContainer.addView(diag, new LinearLayout.LayoutParams(-1, -2));

        TextView buildLabel = new TextView(this);
        buildLabel.setText("ПОСТРОЕНИЕ");
        buildLabel.setTextColor(Color.LTGRAY);
        buildLabel.setTextSize(10f);
        buildLabel.setPadding(dp(4), dp(3), dp(4), 0);
        paletteContainer.addView(buildLabel, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout build = new LinearLayout(this);
        build.setOrientation(LinearLayout.HORIZONTAL);
        editorButton = makeButton("РЕДАКТОР");
        Button addNode = makeButton("+ УЗЕЛ");
        Button deleteNode = makeButton("УДАЛИТЬ");
        Button autoLayout = makeButton("AUTO");
        build.addView(editorButton, new LinearLayout.LayoutParams(0, -2, 1f));
        build.addView(addNode, new LinearLayout.LayoutParams(0, -2, 1f));
        build.addView(deleteNode, new LinearLayout.LayoutParams(0, -2, 1f));
        build.addView(autoLayout, new LinearLayout.LayoutParams(0, -2, 1f));
        paletteContainer.addView(build, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout history = new LinearLayout(this);
        history.setOrientation(LinearLayout.HORIZONTAL);
        Button undo = makeButton("ОТМЕНИТЬ");
        Button redo = makeButton("ПОВТОРИТЬ");
        history.addView(undo, new LinearLayout.LayoutParams(0, -2, 1f));
        history.addView(redo, new LinearLayout.LayoutParams(0, -2, 1f));
        paletteContainer.addView(history, new LinearLayout.LayoutParams(-1, -2));

        pane.addView(paletteContainer, new LinearLayout.LayoutParams(-1, -2));

        paletteToggle.setOnClickListener(v -> {
            boolean visible = paletteContainer.getVisibility() == View.VISIBLE;
            paletteContainer.setVisibility(visible ? View.GONE : View.VISIBLE);
            paletteToggle.setText(visible ? "ПАЛИТРА ▲" : "ПАЛИТРА ▼");
        });

        init.setOnClickListener(v -> runGraphCommand("runtime init demo", false));
        step.setOnClickListener(v -> runGraphCommand("runtime step", false));
        run.setOnClickListener(v -> runGraphCommand("runtime run", false));
        reset.setOnClickListener(v -> runGraphCommand("runtime reset", false));
        refresh.setOnClickListener(v -> refreshGraph());
        fit.setOnClickListener(v -> graphView.fitToScreen());
        queue.setOnClickListener(v -> runGraphCommand("runtime queue", true));
        events.setOnClickListener(v -> runGraphCommand("runtime events", true));
        ledger.setOnClickListener(v -> runGraphCommand("runtime ledger", true));
        editorButton.setOnClickListener(v -> {
            boolean enabled = !graphView.isEditMode();
            graphView.setEditMode(enabled);
            editorButton.setText(enabled ? "EDIT: ВКЛ" : "РЕДАКТОР");
            graphAction.setText(enabled
                    ? "EDIT: drag сохраняет layout; OUT → IN создаёт Edge; тап Edge → выбор → УДАЛИТЬ. Узлы нельзя накладывать."
                    : "VIEW: щипок — масштаб, палец — панорама. Связи прокладываются ортогонально.");
            graphTelemetry.setText(graphView.compactSummary());
        });
        addNode.setOnClickListener(v -> showNodePalette());
        deleteNode.setOnClickListener(v -> {
            String edgeId = graphView.getSelectedEdgeId();
            if (edgeId != null && !edgeId.isEmpty()) {
                runGraphCommand("graph edge remove " + edgeId, false);
                graphView.clearSelection();
                return;
            }
            String nodeId = graphView.getSelectedNodeId();
            if (nodeId == null || nodeId.isEmpty()) {
                graphAction.setText("В EDIT выбери Edge или пользовательский Node n-user-*.");
                return;
            }
            runGraphCommand("graph node remove " + nodeId, false);
            graphView.clearSelection();
        });
        autoLayout.setOnClickListener(v -> {
            runGraphCommand("graph layout clear", false);
            graphView.fitToScreen();
        });
        undo.setOnClickListener(v -> runGraphCommand("graph undo", false));
        redo.setOnClickListener(v -> runGraphCommand("graph redo", false));

        return pane;
    }

    private void showNodePalette() {
        final String[] labels = {
                "Семантическая проверка",
                "Контрпроверка",
                "Сравнение / Join",
                "Ревизия",
                "Фиксация"
        };
        final String[] types = {"SemanticCheck", "CounterCheck", "Compare", "Revision", "Commit"};
        new AlertDialog.Builder(this)
                .setTitle("Добавить узел")
                .setItems(labels, (dialog, which) -> runGraphCommand("graph node add " + types[which], false))
                .setNegativeButton("ОТМЕНА", null)
                .show();
    }

    private LinearLayout buildConsolePane() {
        LinearLayout pane = new LinearLayout(this);
        pane.setOrientation(LinearLayout.VERTICAL);
        pane.setPadding(dp(8), dp(4), dp(8), dp(8));

        scroll = new ScrollView(this);
        output = new TextView(this);
        output.setTextColor(Color.LTGRAY);
        output.setTextSize(16f);
        output.setGravity(Gravity.START);
        output.setTextIsSelectable(true);
        scroll.addView(output, new ScrollView.LayoutParams(-1,-2));
        pane.addView(scroll, new LinearLayout.LayoutParams(-1,0,1f));

        input = new EditText(this);
        input.setHint("команды — по одной на строку");
        input.setSingleLine(false);
        input.setMinLines(3);
        input.setMaxLines(8);
        input.setGravity(Gravity.TOP | Gravity.START);
        input.setHorizontallyScrolling(false);
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(Color.LTGRAY);
        input.setImeOptions(EditorInfo.IME_FLAG_NO_ENTER_ACTION);
        pane.addView(input, new LinearLayout.LayoutParams(-1,-2));

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);

        Button execute = makeButton("ВЫПОЛНИТЬ");
        buttons.addView(execute, new LinearLayout.LayoutParams(0,-2,1f));

        Button clear = makeButton("ОЧИСТИТЬ");
        buttons.addView(clear, new LinearLayout.LayoutParams(0,-2,1f));

        pane.addView(buttons, new LinearLayout.LayoutParams(-1,-2));

        execute.setOnClickListener(v -> dispatchBatch());
        clear.setOnClickListener(v -> {
            input.setText("");
            commandQueue.clear();
        });

        return pane;
    }

    private Button makeButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(11f);
        b.setMinHeight(0);
        b.setMinWidth(0);
        b.setPadding(dp(2), dp(4), dp(2), dp(4));
        return b;
    }

    private void showGraph() {
        graphPane.setVisibility(View.VISIBLE);
        consolePane.setVisibility(View.GONE);
        if (nativeReady) refreshGraph();
    }

    private void showConsole() {
        graphPane.setVisibility(View.GONE);
        consolePane.setVisibility(View.VISIBLE);
    }

    private void refreshGraph() {
        if (!nativeReady) return;
        try {
            String json = NativeBridge.uiSnapshot();
            graphView.setSnapshot(json);
            graphTelemetry.setText(graphView.compactSummary());
        } catch (Throwable t) {
            graphAction.setText("Ошибка GraphView: " + t.getClass().getSimpleName() + ": " + t.getMessage());
        }
    }

    private void runGraphCommand(String cmd, boolean openConsole) {
        if (!nativeReady) return;
        try {
            String response = NativeBridge.command(cmd);
            println("> " + cmd);
            if (response != null && !response.isEmpty()) println(response);
            saveState();
            graphAction.setText(compactResponse(cmd, response));
            refreshGraph();
            if (openConsole) showConsole();
        } catch (Throwable t) {
            graphAction.setText("ОШИБКА: " + t.getClass().getSimpleName() + ": " + t.getMessage());
        }
    }

    private String compactResponse(String cmd, String response) {
        if (response == null || response.isEmpty()) return cmd;
        String line = response.split("\\n", 2)[0];
        return cmd + " → " + line;
    }

    private void printGreeting() {
        println(" /\\_/\\ ");
        println("( o.o )   TMC " + VERSION);
        println(" > ^ <    Graph Editor / Java host / Rust SQLite event-runtime / Android 14 arm64");
        println("");
        println(" /\\_/\\   /\\_/\\ ");
        println("( =^.^= ) ( =^.^= )");
        println("(\")_(\") (\")_(\")");
        println("");
        println("ГРАФ — основной интерфейс runtime; нижняя ПАЛИТРА сворачивается.");
        println("ПОСТРОЕНИЕ — узлы, typed-связи и layout; ОПЕРАЦИИ — INIT/STEP/RUN/СБРОС и диагностика.");
        println("ОТМЕНИТЬ/ПОВТОРИТЬ: история последних 6 изменений графа хранится отдельно и переживает runtime reset.");
        println("Связи — ортогональный трубопровод с круглыми локтями, без Bezier/spline; маршрутизация избегает узлов, подписей и других линий.");
        println("Палитра функций подписана по-русски; внутренние типы Rust не меняются.");
        println("");
    }

    private void dispatchBatch() {
        String raw = input.getText().toString();
        if (raw == null || raw.trim().isEmpty()) return;

        List<String> commands = parseCommands(raw);
        if (commands.isEmpty()) {
            input.setText("");
            return;
        }

        input.setText("");
        commandQueue.clear();
        commandQueue.addAll(commands);

        if (!nativeReady) {
            println("native core недоступно");
            return;
        }

        if (commands.size() > 1) println("=== ПАКЕТ: " + commands.size() + " команд ===");

        int total = commands.size();
        int index = 0;
        while (!commandQueue.isEmpty()) {
            String cmd = commandQueue.removeFirst();
            index++;
            if (total > 1) println("[" + index + "/" + total + "] > " + cmd);
            else println("> " + cmd);

            try {
                String response = NativeBridge.command(cmd);
                if (response != null && !response.isEmpty()) println(response);
                saveState();

                if (isHardFailure(response)) {
                    preserveRemainingQueue();
                    println("=== ПАКЕТ ОСТАНОВЛЕН: ошибка на " + index + "/" + total +
                            "; оставшиеся команды возвращены в поле ввода ===");
                    printExpectation();
                    refreshGraph();
                    return;
                }
            } catch (Throwable t) {
                println("ОШИБКА: " + t.getClass().getSimpleName() + ": " + t.getMessage());
                preserveRemainingQueue();
                println("=== ПАКЕТ ОСТАНОВЛЕН: исключение; оставшиеся команды возвращены в поле ввода ===");
                printExpectation();
                refreshGraph();
                return;
            }
        }

        if (total > 1) println("=== ПАКЕТ ЗАВЕРШЁН: " + total + "/" + total + " ===");
        printExpectation();
        refreshGraph();
    }

    private List<String> parseCommands(String raw) {
        String normalized = raw.replace("\r\n", "\n").replace('\r', '\n');
        String[] lines = normalized.split("\n");
        ArrayList<String> result = new ArrayList<>();
        for (String line : lines) {
            String cmd = line.trim();
            if (cmd.isEmpty()) continue;
            if (cmd.startsWith("#")) continue;
            result.add(cmd);
        }
        return result;
    }

    private boolean isHardFailure(String response) {
        if (response == null) return false;
        String r = response.trim();
        return r.startsWith("ОШИБКА:") ||
               r.startsWith("ERROR:") ||
               r.startsWith("НЕИЗВЕСТНАЯ КОМАНДА") ||
               r.startsWith("TYPE MISMATCH:") ||
               r.startsWith("CARDINALITY:") ||
               r.startsWith("UNKNOWN;");
    }

    private void preserveRemainingQueue() {
        if (commandQueue.isEmpty()) return;
        StringBuilder sb = new StringBuilder();
        while (!commandQueue.isEmpty()) {
            if (sb.length() > 0) sb.append('\n');
            sb.append(commandQueue.removeFirst());
        }
        input.setText(sb.toString());
        input.setSelection(input.getText().length());
    }

    private void saveState() {
        if (sqliteReady) return;
        String data = NativeBridge.exportState();
        if (data != null) prefs.edit().putString("rust_state_json_v2", data).apply();
    }

    private void printExpectation() {
        if (!nativeReady) return;
        String e = NativeBridge.expectation();
        println("Ожидаю: " + e);
    }

    private void println(String s) {
        if (output == null) return;
        output.append(s); output.append("\n");
        if (scroll != null) scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }
}
