# TMC 0.2.1-graph-editor-v03

UI/ergonomics patch for the first editable Graph interface. Rust runtime, SQLite EventLog and execution semantics are intentionally unchanged except for version metadata.

## Changes

- Bottom collapsible palette replaces the three permanently visible button rows.
- Palette sections: `ПОСТРОЕНИЕ` and `ОПЕРАЦИИ`.
- `ПОСТРОЕНИЕ`: EDIT, direct add buttons for all current executable Node types, delete selected Node, delete selected Edge, clear selection, AUTO layout, FIT.
- `ОПЕРАЦИИ`: INIT, STEP, RUN, refresh, queue, events, resource.
- Tap Node or Edge opens the bottom context/palette bar; drag in EDIT remains Node movement.
- Edge is selectable by tapping near the curve; selected Edge is highlighted and can be removed from the palette.
- Ports are visibly larger and have a ~30 dp nearest-port touch target.
- Node auto-layout is narrower and portrait-oriented: 148 dp nodes, smaller gaps, no hard 400 dp content-width floor.
- Re-layout reacts to viewport size changes.
- Edge labels now have compact dark backgrounds and alternating offsets; node text is pixel-fitted rather than only character-truncated.
- Moderate 7 dp corner radius for controls; margins/padding normalized.
- Top action/help block removed; context information is in the bottom bar to return vertical space to the graph.

## Architectural boundary

Graph topology remains Rust-owned. Android still edits only by sending existing commands such as `graph node add`, `graph edge add/remove`, and `graph layout set`. This patch does not change scheduler/resource/SQLite semantics.
