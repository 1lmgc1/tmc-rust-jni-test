package io.typedcalculus.console;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class MainActivity extends Activity {
    private static final String VERSION = "0.2.1-graph-editor-v03";

    private TextView output;
    private EditText input;
    private ScrollView scroll;
    private SharedPreferences prefs;
    private boolean nativeReady;
    private boolean sqliteReady;
    private final ArrayDeque<String> commandQueue = new ArrayDeque<>();

    private LinearLayout graphPane;
    private LinearLayout consolePane;
    private GraphView graphView;
    private TextView graphTelemetry;
    private TextView graphAction;
    private Button graphTab;
    private Button consoleTab;
    private Button paletteToggle;
    private LinearLayout paletteBody;
    private boolean paletteExpanded;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
        prefs = getSharedPreferences("tmc", MODE_PRIVATE);
        printGreeting();
        try {
            NativeBridge.load();
            nativeReady = true;

            String dbPath = new java.io.File(getFilesDir(), "tmc-runtime.sqlite3").getAbsolutePath();
            String storage = NativeBridge.initStorage(dbPath);
            if (storage != null && storage.startsWith("RESTORED")) {
                sqliteReady = true;
                println("SQLite: состояние восстановлено; " + storage);
            } else if (storage != null && storage.startsWith("EMPTY")) {
                sqliteReady = true;
                println("SQLite: создан новый durable store; " + storage);
                String saved = prefs.getString("rust_state_json_v2", null);
                if (saved != null && !saved.isEmpty()) {
                    boolean ok = NativeBridge.importState(saved);
                    println(ok ? "Миграция SharedPreferences → SQLite: OK" : "Миграция SharedPreferences → SQLite: отклонена");
                } else {
                    String checkpoint = NativeBridge.persistStorage();
                    println("SQLite: " + checkpoint);
                }
            } else {
                println("SQLite недоступен: " + storage);
                String saved = prefs.getString("rust_state_json_v2", null);
                if (saved != null && !saved.isEmpty()) {
                    boolean ok = NativeBridge.importState(saved);
                    println(ok ? "Fallback SharedPreferences: состояние восстановлено" : "Fallback SharedPreferences: состояние не принято");
                }
            }
            printExpectation();
            showGraph();
            refreshGraph();
        } catch (Throwable t) {
            println("ОШИБКА NATIVE: " + t.getClass().getSimpleName() + ": " + t.getMessage());
            setGraphAction("NATIVE ERROR: " + t.getClass().getSimpleName());
        }
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(31, 33, 36));

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        tabs.setPadding(dp(5), dp(4), dp(5), dp(3));

        graphTab = makeButton("ГРАФ");
        consoleTab = makeButton("КОНСОЛЬ");
        tabs.addView(graphTab, weightedButtonParams());
        tabs.addView(consoleTab, weightedButtonParams());
        root.addView(tabs, new LinearLayout.LayoutParams(-1, -2));

        graphPane = buildGraphPane();
        consolePane = buildConsolePane();
        root.addView(graphPane, new LinearLayout.LayoutParams(-1, 0, 1f));
        root.addView(consolePane, new LinearLayout.LayoutParams(-1, 0, 1f));

        graphTab.setOnClickListener(v -> showGraph());
        consoleTab.setOnClickListener(v -> showConsole());

        setContentView(root);
        showGraph();
    }

    private LinearLayout buildGraphPane() {
        LinearLayout pane = new LinearLayout(this);
        pane.setOrientation(LinearLayout.VERTICAL);
        pane.setPadding(dp(4), dp(2), dp(4), dp(4));

        graphTelemetry = new TextView(this);
        graphTelemetry.setTextColor(Color.WHITE);
        graphTelemetry.setTextSize(12.5f);
        graphTelemetry.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        graphTelemetry.setPadding(dp(7), dp(4), dp(7), dp(4));
        graphTelemetry.setMaxLines(2);
        graphTelemetry.setText("runtime: загрузка…");
        pane.addView(graphTelemetry, new LinearLayout.LayoutParams(-1, -2));

        graphView = new GraphView(this);
        graphView.setListener(new GraphView.Listener() {
            @Override public void onNodeMoved(String nodeId, float xDp, float yDp) {
                String cmd = String.format(Locale.US, "graph layout set %s %.1f %.1f", nodeId, xDp, yDp);
                runGraphCommand(cmd, false);
            }

            @Override public void onConnect(String fromNode, String fromPort, String toNode, String toPort) {
                runGraphCommand("graph edge add " + fromNode + "." + fromPort + " " + toNode + "." + toPort, false);
            }

            @Override public void onNodeSelected(String nodeId, String label, String type) {
                setGraphAction("Узел: " + label + "  [" + nodeId + "]  · " + type);
                setPaletteExpanded(true);
            }

            @Override public void onEdgeSelected(String edgeId, String eventType) {
                setGraphAction("Связь: " + edgeId + "  · " + eventType + "  · можно удалить в ПОСТРОЕНИИ");
                setPaletteExpanded(true);
            }

            @Override public void onEditorMessage(String message) {
                setGraphAction(message);
            }
        });
        pane.addView(graphView, new LinearLayout.LayoutParams(-1, 0, 1f));

        LinearLayout paletteHeader = new LinearLayout(this);
        paletteHeader.setOrientation(LinearLayout.HORIZONTAL);
        paletteHeader.setGravity(Gravity.CENTER_VERTICAL);
        paletteHeader.setPadding(0, dp(3), 0, dp(2));

        paletteToggle = makeButton("ПАЛИТРА ▴");
        LinearLayout.LayoutParams toggleLp = new LinearLayout.LayoutParams(dp(112), -2);
        toggleLp.setMargins(dp(2), 0, dp(5), 0);
        paletteHeader.addView(paletteToggle, toggleLp);

        graphAction = new TextView(this);
        graphAction.setTextColor(Color.LTGRAY);
        graphAction.setTextSize(11.5f);
        graphAction.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        graphAction.setPadding(dp(4), dp(2), dp(4), dp(2));
        graphAction.setMaxLines(2);
        graphAction.setText("Тап узла/связи — выбор. В EDIT: тяни узел; OUT → IN создаёт typed Edge.");
        paletteHeader.addView(graphAction, new LinearLayout.LayoutParams(0, -2, 1f));
        pane.addView(paletteHeader, new LinearLayout.LayoutParams(-1, -2));

        paletteBody = new LinearLayout(this);
        paletteBody.setOrientation(LinearLayout.VERTICAL);
        paletteBody.setPadding(0, 0, 0, dp(2));
        pane.addView(paletteBody, new LinearLayout.LayoutParams(-1, -2));

        addPaletteSectionTitle(paletteBody, "ПОСТРОЕНИЕ");
        LinearLayout buildRow = new LinearLayout(this);
        buildRow.setOrientation(LinearLayout.HORIZONTAL);
        addPaletteButton(buildRow, "EDIT", v -> toggleEditor());
        addPaletteButton(buildRow, "+ SEM", v -> addNode("SemanticCheck"));
        addPaletteButton(buildRow, "+ COUNTER", v -> addNode("CounterCheck"));
        addPaletteButton(buildRow, "+ JOIN", v -> addNode("Compare"));
        addPaletteButton(buildRow, "+ REV", v -> addNode("Revision"));
        addPaletteButton(buildRow, "+ COMMIT", v -> addNode("Commit"));
        addPaletteButton(buildRow, "УДАЛ. УЗЕЛ", v -> deleteSelectedNode());
        addPaletteButton(buildRow, "УДАЛ. СВЯЗЬ", v -> deleteSelectedEdge());
        addPaletteButton(buildRow, "СБРОС ВЫБОРА", v -> {
            graphView.clearSelection();
            setGraphAction("Выбор снят");
        });
        addPaletteButton(buildRow, "AUTO", v -> {
            runGraphCommand("graph layout clear", false);
            graphView.fitToScreen();
        });
        addPaletteButton(buildRow, "ВПИСАТЬ", v -> graphView.fitToScreen());
        paletteBody.addView(horizontalStrip(buildRow), new LinearLayout.LayoutParams(-1, -2));

        addPaletteSectionTitle(paletteBody, "ОПЕРАЦИИ");
        LinearLayout opRow = new LinearLayout(this);
        opRow.setOrientation(LinearLayout.HORIZONTAL);
        addPaletteButton(opRow, "INIT", v -> runGraphCommand("runtime init demo", false));
        addPaletteButton(opRow, "STEP", v -> runGraphCommand("runtime step", false));
        addPaletteButton(opRow, "RUN", v -> runGraphCommand("runtime run", false));
        addPaletteButton(opRow, "ОБНОВИТЬ", v -> refreshGraph());
        addPaletteButton(opRow, "ОЧЕРЕДЬ", v -> runGraphCommand("runtime queue", true));
        addPaletteButton(opRow, "СОБЫТИЯ", v -> runGraphCommand("runtime events", true));
        addPaletteButton(opRow, "РЕСУРС", v -> runGraphCommand("runtime ledger", true));
        paletteBody.addView(horizontalStrip(opRow), new LinearLayout.LayoutParams(-1, -2));

        paletteToggle.setOnClickListener(v -> setPaletteExpanded(!paletteExpanded));
        setPaletteExpanded(false);
        return pane;
    }

    private void toggleEditor() {
        boolean enabled = !graphView.isEditMode();
        graphView.setEditMode(enabled);
        setGraphAction(enabled
                ? "EDIT: тап выбирает; drag из тела/шапки двигает узел; крупный OUT → совместимый IN создаёт Edge."
                : "VIEW: щипок — масштаб, палец — панорама. Тап узла/связи раскрывает нижний бар.");
        graphTelemetry.setText(graphView.compactSummary());
    }

    private void addNode(String type) {
        runGraphCommand("graph node add " + type, false);
    }

    private void deleteSelectedNode() {
        String id = graphView.getSelectedNodeId();
        if (id == null || id.isEmpty()) {
            setGraphAction("Выбери пользовательский узел n-user-*.");
            return;
        }
        runGraphCommand("graph node remove " + id, false);
        graphView.clearSelection();
    }

    private void deleteSelectedEdge() {
        String id = graphView.getSelectedEdgeId();
        if (id == null || id.isEmpty()) {
            setGraphAction("Выбери связь тапом по линии, затем УДАЛ. СВЯЗЬ.");
            return;
        }
        runGraphCommand("graph edge remove " + id, false);
        graphView.clearSelection();
    }

    private void setGraphAction(String text) {
        if (graphAction != null) graphAction.setText(text == null ? "" : text);
    }

    private void setPaletteExpanded(boolean expanded) {
        paletteExpanded = expanded;
        if (paletteBody != null) paletteBody.setVisibility(expanded ? View.VISIBLE : View.GONE);
        if (paletteToggle != null) paletteToggle.setText(expanded ? "ПАЛИТРА ▾" : "ПАЛИТРА ▴");
    }

    private void addPaletteSectionTitle(LinearLayout parent, String text) {
        TextView title = new TextView(this);
        title.setText(text);
        title.setTextColor(Color.rgb(178, 185, 193));
        title.setTextSize(10.5f);
        title.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        title.setPadding(dp(7), dp(3), dp(7), dp(1));
        parent.addView(title, new LinearLayout.LayoutParams(-1, -2));
    }

    private void addPaletteButton(LinearLayout row, String text, View.OnClickListener click) {
        Button b = makeButton(text);
        b.setOnClickListener(click);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(38));
        lp.setMargins(dp(2), dp(1), dp(2), dp(2));
        row.addView(b, lp);
    }

    private HorizontalScrollView horizontalStrip(LinearLayout row) {
        HorizontalScrollView scroll = new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        scroll.setFillViewport(false);
        scroll.setPadding(dp(1), 0, dp(1), 0);
        scroll.addView(row, new HorizontalScrollView.LayoutParams(-2, -2));
        return scroll;
    }

    private LinearLayout buildConsolePane() {
        LinearLayout pane = new LinearLayout(this);
        pane.setOrientation(LinearLayout.VERTICAL);
        pane.setPadding(dp(8), dp(4), dp(8), dp(8));

        scroll = new ScrollView(this);
        output = new TextView(this);
        output.setTextColor(Color.LTGRAY);
        output.setTextSize(16f);
        output.setGravity(Gravity.START);
        output.setTextIsSelectable(true);
        scroll.addView(output, new ScrollView.LayoutParams(-1,-2));
        pane.addView(scroll, new LinearLayout.LayoutParams(-1,0,1f));

        input = new EditText(this);
        input.setHint("команды — по одной на строку");
        input.setSingleLine(false);
        input.setMinLines(3);
        input.setMaxLines(8);
        input.setGravity(Gravity.TOP | Gravity.START);
        input.setHorizontallyScrolling(false);
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(Color.LTGRAY);
        input.setImeOptions(EditorInfo.IME_FLAG_NO_ENTER_ACTION);
        pane.addView(input, new LinearLayout.LayoutParams(-1,-2));

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);

        Button execute = makeButton("ВЫПОЛНИТЬ");
        buttons.addView(execute, weightedButtonParams());

        Button clear = makeButton("ОЧИСТИТЬ");
        buttons.addView(clear, weightedButtonParams());

        pane.addView(buttons, new LinearLayout.LayoutParams(-1,-2));

        execute.setOnClickListener(v -> dispatchBatch());
        clear.setOnClickListener(v -> {
            input.setText("");
            commandQueue.clear();
        });

        return pane;
    }

    private Button makeButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.rgb(235, 238, 241));
        b.setTextSize(10.8f);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(0);
        b.setMinWidth(0);
        b.setPadding(dp(9), dp(4), dp(9), dp(4));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(56, 60, 65));
        bg.setCornerRadius(dp(7));
        bg.setStroke(dp(1), Color.rgb(82, 89, 96));
        b.setBackground(bg);
        return b;
    }

    private LinearLayout.LayoutParams weightedButtonParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(40), 1f);
        lp.setMargins(dp(2), dp(1), dp(2), dp(1));
        return lp;
    }

    private void showGraph() {
        graphPane.setVisibility(View.VISIBLE);
        consolePane.setVisibility(View.GONE);
        if (nativeReady) refreshGraph();
    }

    private void showConsole() {
        graphPane.setVisibility(View.GONE);
        consolePane.setVisibility(View.VISIBLE);
    }

    private void refreshGraph() {
        if (!nativeReady) return;
        try {
            String json = NativeBridge.uiSnapshot();
            graphView.setSnapshot(json);
            graphTelemetry.setText(graphView.compactSummary());
        } catch (Throwable t) {
            setGraphAction("Ошибка GraphView: " + t.getClass().getSimpleName() + ": " + t.getMessage());
        }
    }

    private void runGraphCommand(String cmd, boolean openConsole) {
        if (!nativeReady) return;
        try {
            String response = NativeBridge.command(cmd);
            println("> " + cmd);
            if (response != null && !response.isEmpty()) println(response);
            saveState();
            setGraphAction(compactResponse(cmd, response));
            refreshGraph();
            if (openConsole) showConsole();
        } catch (Throwable t) {
            setGraphAction("ОШИБКА: " + t.getClass().getSimpleName() + ": " + t.getMessage());
        }
    }

    private String compactResponse(String cmd, String response) {
        if (response == null || response.isEmpty()) return cmd;
        String line = response.split("\\n", 2)[0];
        return cmd + " → " + line;
    }

    private void printGreeting() {
        println(" /\\_/\\ ");
        println("( o.o )   TMC " + VERSION);
        println(" > ^ <    Adaptive Graph Editor / Java host / Rust SQLite event-runtime / Android 14 arm64");
        println("");
        println(" /\\_/\\   /\\_/\\ ");
        println("( =^.^= ) ( =^.^= )");
        println("(\")_(\") (\")_(\")");
        println("");
        println("ГРАФ — основной интерфейс runtime; нижняя ПАЛИТРА сворачивается.");
        println("ПОСТРОЕНИЕ — узлы, связи, layout; ОПЕРАЦИИ — INIT/STEP/RUN и диагностика.");
        println("Тап выбирает узел/связь; в EDIT drag узла перемещает его, OUT → IN создаёт typed Edge.");
        println("");
    }

    private void dispatchBatch() {
        String raw = input.getText().toString();
        if (raw == null || raw.trim().isEmpty()) return;

        List<String> commands = parseCommands(raw);
        if (commands.isEmpty()) {
            input.setText("");
            return;
        }

        input.setText("");
        commandQueue.clear();
        commandQueue.addAll(commands);

        if (!nativeReady) {
            println("native core недоступно");
            return;
        }

        if (commands.size() > 1) println("=== ПАКЕТ: " + commands.size() + " команд ===");

        int total = commands.size();
        int index = 0;
        while (!commandQueue.isEmpty()) {
            String cmd = commandQueue.removeFirst();
            index++;
            if (total > 1) println("[" + index + "/" + total + "] > " + cmd);
            else println("> " + cmd);

            try {
                String response = NativeBridge.command(cmd);
                if (response != null && !response.isEmpty()) println(response);
                saveState();

                if (isHardFailure(response)) {
                    preserveRemainingQueue();
                    println("=== ПАКЕТ ОСТАНОВЛЕН: ошибка на " + index + "/" + total +
                            "; оставшиеся команды возвращены в поле ввода ===");
                    printExpectation();
                    refreshGraph();
                    return;
                }
            } catch (Throwable t) {
                println("ОШИБКА: " + t.getClass().getSimpleName() + ": " + t.getMessage());
                preserveRemainingQueue();
                println("=== ПАКЕТ ОСТАНОВЛЕН: исключение; оставшиеся команды возвращены в поле ввода ===");
                printExpectation();
                refreshGraph();
                return;
            }
        }

        if (total > 1) println("=== ПАКЕТ ЗАВЕРШЁН: " + total + "/" + total + " ===");
        printExpectation();
        refreshGraph();
    }

    private List<String> parseCommands(String raw) {
        String normalized = raw.replace("\r\n", "\n").replace('\r', '\n');
        String[] lines = normalized.split("\n");
        ArrayList<String> result = new ArrayList<>();
        for (String line : lines) {
            String cmd = line.trim();
            if (cmd.isEmpty()) continue;
            if (cmd.startsWith("#")) continue;
            result.add(cmd);
        }
        return result;
    }

    private boolean isHardFailure(String response) {
        if (response == null) return false;
        String r = response.trim();
        return r.startsWith("ОШИБКА:") ||
               r.startsWith("ERROR:") ||
               r.startsWith("НЕИЗВЕСТНАЯ КОМАНДА") ||
               r.startsWith("TYPE MISMATCH:") ||
               r.startsWith("CARDINALITY:") ||
               r.startsWith("UNKNOWN;");
    }

    private void preserveRemainingQueue() {
        if (commandQueue.isEmpty()) return;
        StringBuilder sb = new StringBuilder();
        while (!commandQueue.isEmpty()) {
            if (sb.length() > 0) sb.append('\n');
            sb.append(commandQueue.removeFirst());
        }
        input.setText(sb.toString());
        input.setSelection(input.getText().length());
    }

    private void saveState() {
        if (sqliteReady) return;
        String data = NativeBridge.exportState();
        if (data != null) prefs.edit().putString("rust_state_json_v2", data).apply();
    }

    private void printExpectation() {
        if (!nativeReady) return;
        String e = NativeBridge.expectation();
        println("Ожидаю: " + e);
    }

    private void println(String s) {
        if (output == null) return;
        output.append(s); output.append("\n");
        if (scroll != null) scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }
}
