package io.typedcalculus.console;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * TMC graph viewer/editor projection.
 * Rust owns GraphState; this View edits only through listener callbacks.
 *
 * v03 UI rules:
 * - every node is a compact BAR by default;
 * - tapping a bar selects it in VIEW and EDIT and toggles its expanded inspector;
 * - ports are top/bottom so the main flow reads as a tree;
 * - edges are orthogonal buses/tracks, not curves;
 * - drag moves a node only in EDIT; ordinary taps never disappear into panning.
 */
public final class GraphView extends View {
    public interface Listener {
        void onNodeMoved(String nodeId, float xDp, float yDp);
        void onConnect(String fromNode, String fromPort, String toNode, String toPort);
        void onNodeSelected(String nodeId, String label, String type);
        void onEditorMessage(String message);
    }

    private static final class PortData {
        String id;
        String name;
        String direction;
        String eventType;
        String cardinality;
        float cx;
        float cy;
    }

    private static final class NodeData {
        String id;
        String label;
        String type;
        int cost;
        int priority;
        int queued;
        int running;
        int suspended;
        int completed;
        String latestKind;
        RectF rect = new RectF();
        int depth;
        boolean hasStoredPosition;
        float storedX;
        float storedY;
        final List<PortData> ports = new ArrayList<>();
    }

    private static final class EdgeData {
        String id;
        String from;
        String fromPort;
        String to;
        String toPort;
        String eventType;
    }

    private static final class PortHit {
        NodeData node;
        PortData port;
    }

    private final Paint edgePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint edgeTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint edgeLabelBgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint nodePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint nodeStrokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint titlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint metaPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint badgePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint badgeTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint emptyPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint portPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint portStrokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint portTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint selectionPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint foldPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private final List<NodeData> nodes = new ArrayList<>();
    private final List<EdgeData> edges = new ArrayList<>();
    private final Map<String, NodeData> nodeById = new HashMap<>();

    private boolean active;
    private String graphId = "";
    private int graphRevision;
    private String stop = "<none>";
    private int iteration;
    private int totalBudget;
    private int spent;
    private int remaining;

    private float scale = 1f;
    private float translateX = 0f;
    private float translateY = 0f;
    private float lastX;
    private float lastY;
    private float downX;
    private float downY;
    private boolean panning;
    private boolean moved;
    private boolean initialFitDone;
    private final ScaleGestureDetector scaleDetector;

    private float contentWidth;
    private float contentHeight;
    private boolean editMode;
    private NodeData draggedNode;
    private NodeData pressedNode;
    private PortHit downPort;
    private PortHit selectedOutput;
    private String selectedNodeId;
    private String expandedNodeId;
    private Listener listener;

    public GraphView(Context context) { this(context, null); }

    public GraphView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setBackgroundColor(Color.rgb(27, 29, 31));

        edgePaint.setColor(Color.rgb(122, 133, 144));
        edgePaint.setStyle(Paint.Style.STROKE);
        edgePaint.setStrokeWidth(dp(1.6f));
        edgePaint.setStrokeJoin(Paint.Join.MITER);
        edgePaint.setStrokeCap(Paint.Cap.SQUARE);

        edgeTextPaint.setColor(Color.rgb(190, 199, 207));
        edgeTextPaint.setTextSize(dp(8.3f));
        edgeLabelBgPaint.setStyle(Paint.Style.FILL);
        edgeLabelBgPaint.setColor(Color.rgb(27, 29, 31));

        nodePaint.setColor(Color.rgb(48, 52, 57));
        nodePaint.setStyle(Paint.Style.FILL);

        nodeStrokePaint.setColor(Color.rgb(104, 116, 128));
        nodeStrokePaint.setStyle(Paint.Style.STROKE);
        nodeStrokePaint.setStrokeWidth(dp(1.3f));

        titlePaint.setColor(Color.WHITE);
        titlePaint.setTextSize(dp(12.2f));
        titlePaint.setFakeBoldText(true);

        metaPaint.setColor(Color.rgb(192, 199, 206));
        metaPaint.setTextSize(dp(8.7f));

        badgePaint.setStyle(Paint.Style.FILL);
        badgeTextPaint.setColor(Color.WHITE);
        badgeTextPaint.setTextSize(dp(8.3f));
        badgeTextPaint.setTextAlign(Paint.Align.CENTER);
        badgeTextPaint.setFakeBoldText(true);

        emptyPaint.setColor(Color.rgb(180, 186, 192));
        emptyPaint.setTextSize(dp(15));
        emptyPaint.setTextAlign(Paint.Align.CENTER);

        portPaint.setStyle(Paint.Style.FILL);
        portPaint.setColor(Color.rgb(94, 105, 116));
        portStrokePaint.setStyle(Paint.Style.STROKE);
        portStrokePaint.setStrokeWidth(dp(1.2f));
        portStrokePaint.setColor(Color.rgb(210, 218, 225));
        portTextPaint.setColor(Color.rgb(190, 198, 205));
        portTextPaint.setTextSize(dp(7.6f));
        portTextPaint.setTextAlign(Paint.Align.CENTER);

        selectionPaint.setStyle(Paint.Style.STROKE);
        selectionPaint.setStrokeWidth(dp(2.2f));
        selectionPaint.setColor(Color.rgb(245, 196, 66));

        foldPaint.setColor(Color.rgb(214, 220, 226));
        foldPaint.setTextSize(dp(11f));
        foldPaint.setFakeBoldText(true);

        scaleDetector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector detector) {
                float old = scale;
                scale = clamp(scale * detector.getScaleFactor(), 0.42f, 2.6f);
                float fx = detector.getFocusX();
                float fy = detector.getFocusY();
                if (old != 0f) {
                    float ratio = scale / old;
                    translateX = fx - (fx - translateX) * ratio;
                    translateY = fy - (fy - translateY) * ratio;
                }
                invalidate();
                return true;
            }
        });
    }

    public void setListener(Listener listener) { this.listener = listener; }

    public void setEditMode(boolean enabled) {
        editMode = enabled;
        if (!enabled) selectedOutput = null;
        invalidate();
    }

    public boolean isEditMode() { return editMode; }

    public String getSelectedNodeId() { return selectedNodeId; }

    public void clearSelection() {
        selectedNodeId = null;
        expandedNodeId = null;
        selectedOutput = null;
        computeLayout();
        invalidate();
    }

    public void setSnapshot(String json) {
        String oldSelected = selectedNodeId;
        String oldExpanded = expandedNodeId;
        boolean preserveView = active && initialFitDone;
        nodes.clear();
        edges.clear();
        nodeById.clear();
        active = false;
        selectedOutput = null;
        initialFitDone = preserveView;
        try {
            JSONObject root = new JSONObject(json == null ? "{}" : json);
            active = root.optBoolean("active", false);
            if (!active) {
                selectedNodeId = null;
                expandedNodeId = null;
                selectedOutput = null;
                invalidate();
                return;
            }
            JSONObject graph = root.getJSONObject("graph");
            graphId = graph.optString("id", "graph");
            graphRevision = graph.optInt("revision", 0);
            JSONArray nodeArray = graph.optJSONArray("nodes");
            if (nodeArray != null) {
                for (int i = 0; i < nodeArray.length(); i++) {
                    JSONObject j = nodeArray.getJSONObject(i);
                    NodeData n = new NodeData();
                    n.id = j.optString("id");
                    n.label = j.optString("label", n.id);
                    n.type = j.optString("type", "Node");
                    n.cost = j.optInt("estimated_cost", 0);
                    n.priority = j.optInt("priority", 0);
                    n.queued = j.optInt("queued", 0);
                    n.running = j.optInt("running", 0);
                    n.suspended = j.optInt("suspended", 0);
                    n.completed = j.optInt("completed", 0);
                    n.latestKind = j.optString("latest_event_kind", "");
                    if (!j.isNull("x") && !j.isNull("y")) {
                        n.hasStoredPosition = true;
                        n.storedX = (float) j.optDouble("x", 0.0);
                        n.storedY = (float) j.optDouble("y", 0.0);
                    }
                    JSONArray ports = j.optJSONArray("ports");
                    if (ports != null) {
                        for (int k = 0; k < ports.length(); k++) {
                            JSONObject pj = ports.getJSONObject(k);
                            PortData p = new PortData();
                            p.id = pj.optString("id");
                            p.name = pj.optString("name", p.id);
                            p.direction = pj.optString("direction", "Input");
                            p.eventType = pj.optString("event_type", "");
                            p.cardinality = pj.optString("cardinality", "One");
                            n.ports.add(p);
                        }
                    }
                    nodes.add(n);
                    nodeById.put(n.id, n);
                }
            }
            JSONArray edgeArray = graph.optJSONArray("edges");
            if (edgeArray != null) {
                for (int i = 0; i < edgeArray.length(); i++) {
                    JSONObject j = edgeArray.getJSONObject(i);
                    EdgeData e = new EdgeData();
                    e.id = j.optString("id");
                    e.from = j.optString("from_node");
                    e.fromPort = j.optString("from_port");
                    e.to = j.optString("to_node");
                    e.toPort = j.optString("to_port");
                    e.eventType = j.optString("event_type", "");
                    edges.add(e);
                }
            }
            JSONObject runtime = root.optJSONObject("runtime");
            if (runtime != null) {
                iteration = runtime.optInt("iteration", 0);
                stop = runtime.isNull("stop") ? "<none>" : runtime.optString("stop", "<none>");
            }
            JSONObject resource = root.optJSONObject("resource");
            if (resource != null) {
                totalBudget = resource.optInt("total", 0);
                spent = resource.optInt("spent", 0);
                remaining = resource.optInt("remaining", 0);
            }
            if (oldSelected != null && nodeById.containsKey(oldSelected)) selectedNodeId = oldSelected;
            else selectedNodeId = null;
            if (oldExpanded != null && nodeById.containsKey(oldExpanded)) expandedNodeId = oldExpanded;
            else expandedNodeId = null;
            computeLayout();
        } catch (Throwable ignored) {
            active = false;
            selectedNodeId = null;
            expandedNodeId = null;
            selectedOutput = null;
        }
        invalidate();
    }

    private boolean isExpanded(NodeData n) {
        return n != null && n.id != null && n.id.equals(expandedNodeId);
    }

    private float nodeWidth() { return dp(190); }
    private float nodeHeight(NodeData n) { return isExpanded(n) ? dp(118) : dp(44); }

    private int typeOrder(NodeData n) {
        if (n == null || n.type == null) return 100;
        if ("Input".equals(n.type)) return 0;
        if ("SemanticCheck".equals(n.type)) return 10;
        if ("CounterCheck".equals(n.type)) return 20;
        if ("Compare".equals(n.type)) return 30;
        if ("Revision".equals(n.type)) return 40;
        if ("Commit".equals(n.type)) return 50;
        return 100;
    }

    private void computeLayout() {
        if (nodes.isEmpty()) return;

        Map<String, List<String>> outgoing = new HashMap<>();
        Map<String, Integer> incomingCount = new HashMap<>();
        for (NodeData n : nodes) {
            outgoing.put(n.id, new ArrayList<String>());
            incomingCount.put(n.id, 0);
            n.depth = -1;
        }
        for (EdgeData e : edges) {
            List<String> out = outgoing.get(e.from);
            if (out != null) out.add(e.to);
            if (incomingCount.containsKey(e.to)) incomingCount.put(e.to, incomingCount.get(e.to) + 1);
        }

        ArrayDeque<String> queue = new ArrayDeque<>();
        boolean hasInputRoot = false;
        for (NodeData n : nodes) if ("Input".equals(n.type)) hasInputRoot = true;
        for (NodeData n : nodes) {
            boolean root = hasInputRoot ? "Input".equals(n.type) : incomingCount.get(n.id) == 0;
            if (root) {
                n.depth = 0;
                queue.addLast(n.id);
            }
        }
        if (queue.isEmpty()) {
            nodes.get(0).depth = 0;
            queue.add(nodes.get(0).id);
        }

        Set<String> expanded = new HashSet<>();
        while (!queue.isEmpty()) {
            String id = queue.removeFirst();
            NodeData current = nodeById.get(id);
            if (current == null) continue;
            // Expand each source only once. Back-edges therefore do not pull old nodes down.
            if (!expanded.add(id)) continue;
            List<String> out = outgoing.get(id);
            if (out == null) continue;
            for (String to : out) {
                NodeData child = nodeById.get(to);
                if (child == null || child == current) continue;
                int candidate = current.depth + 1;
                if (child.depth < 0) {
                    child.depth = candidate;
                    queue.addLast(to);
                } else if (candidate < child.depth) {
                    child.depth = candidate;
                }
            }
        }

        int maxDepth = 0;
        for (NodeData n : nodes) if (n.depth >= 0) maxDepth = Math.max(maxDepth, n.depth);
        for (NodeData n : nodes) if (n.depth < 0) n.depth = maxDepth + 1;
        for (NodeData n : nodes) maxDepth = Math.max(maxDepth, n.depth);

        Map<Integer, List<NodeData>> levels = new HashMap<>();
        for (NodeData n : nodes) {
            List<NodeData> level = levels.get(n.depth);
            if (level == null) {
                level = new ArrayList<>();
                levels.put(n.depth, level);
            }
            level.add(n);
        }
        for (List<NodeData> level : levels.values()) {
            Collections.sort(level, new Comparator<NodeData>() {
                @Override public int compare(NodeData a, NodeData b) {
                    int byType = Integer.compare(typeOrder(a), typeOrder(b));
                    if (byType != 0) return byType;
                    return a.id.compareTo(b.id);
                }
            });
        }

        float nodeW = nodeWidth();
        float hGap = dp(46);
        float vGap = dp(70);
        int maxPerLevel = 1;
        for (List<NodeData> list : levels.values()) maxPerLevel = Math.max(maxPerLevel, list.size());
        contentWidth = Math.max(dp(420), maxPerLevel * nodeW + (maxPerLevel - 1) * hGap + dp(110));

        float y = dp(34);
        for (int d = 0; d <= maxDepth; d++) {
            List<NodeData> list = levels.get(d);
            if (list == null || list.isEmpty()) continue;
            float rowMaxH = dp(44);
            for (NodeData n : list) rowMaxH = Math.max(rowMaxH, nodeHeight(n));
            float rowW = list.size() * nodeW + (list.size() - 1) * hGap;
            float startX = (contentWidth - rowW) / 2f;
            for (int i = 0; i < list.size(); i++) {
                NodeData n = list.get(i);
                float h = nodeHeight(n);
                float x = startX + i * (nodeW + hGap);
                float ny = y;
                if (n.hasStoredPosition) {
                    x = dp(n.storedX);
                    ny = dp(n.storedY);
                }
                n.rect.set(x, ny, x + nodeW, ny + h);
            }
            y += rowMaxH + vGap;
        }
        contentHeight = Math.max(dp(520), y + dp(60));
        recomputeContentBounds();
        layoutPorts();
    }

    private void recomputeContentBounds() {
        float maxR = dp(420);
        float maxB = dp(520);
        for (NodeData n : nodes) {
            maxR = Math.max(maxR, n.rect.right + dp(120));
            maxB = Math.max(maxB, n.rect.bottom + dp(90));
        }
        contentWidth = maxR;
        contentHeight = maxB;
    }

    private void layoutPorts() {
        for (NodeData n : nodes) {
            List<PortData> ins = new ArrayList<>();
            List<PortData> outs = new ArrayList<>();
            for (PortData p : n.ports) {
                if ("Output".equals(p.direction)) outs.add(p); else ins.add(p);
            }
            layoutPortEdge(n, ins, false);
            layoutPortEdge(n, outs, true);
        }
    }

    private void layoutPortEdge(NodeData n, List<PortData> ports, boolean output) {
        if (ports.isEmpty()) return;
        float left = n.rect.left + dp(22);
        float right = n.rect.right - dp(22);
        float step = ports.size() == 1 ? 0f : (right - left) / (ports.size() - 1f);
        for (int i = 0; i < ports.size(); i++) {
            PortData p = ports.get(i);
            p.cx = ports.size() == 1 ? n.rect.centerX() : left + i * step;
            p.cy = output ? n.rect.bottom : n.rect.top;
        }
    }

    @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        fitToScreen();
    }

    public void fitToScreen() {
        if (getWidth() <= 0 || contentWidth <= 0) return;
        float sx = (getWidth() - dp(16)) / contentWidth;
        float sy = (getHeight() - dp(16)) / Math.max(contentHeight, dp(1));
        scale = clamp(Math.min(sx, sy), 0.48f, 1.08f);
        translateX = (getWidth() - contentWidth * scale) / 2f;
        translateY = dp(8);
        initialFitDone = true;
        invalidate();
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (!active || nodes.isEmpty()) {
            canvas.drawText("Runtime не инициализирован — нажми INIT", getWidth() / 2f, getHeight() / 2f, emptyPaint);
            return;
        }
        if (!initialFitDone) fitToScreen();

        canvas.save();
        canvas.translate(translateX, translateY);
        canvas.scale(scale, scale);
        drawEdges(canvas);
        drawNodes(canvas);
        canvas.restore();
    }

    private PortData findPort(NodeData node, String id) {
        if (node == null) return null;
        for (PortData p : node.ports) if (p.id.equals(id)) return p;
        return null;
    }

    private String sourceKey(EdgeData e) { return e.from + "\u0000" + e.fromPort; }

    /** Draw orthogonal connections. Forward fan-out is bundled into a bus; back-edges use side tracks. */
    private void drawEdges(Canvas canvas) {
        Map<String, List<EdgeData>> groups = new LinkedHashMap<>();
        for (EdgeData e : edges) {
            List<EdgeData> g = groups.get(sourceKey(e));
            if (g == null) {
                g = new ArrayList<>();
                groups.put(sourceKey(e), g);
            }
            g.add(e);
        }

        float rightMost = dp(420);
        for (NodeData n : nodes) rightMost = Math.max(rightMost, n.rect.right);
        int backTrack = 0;
        int forwardTrack = 0;

        for (List<EdgeData> group : groups.values()) {
            if (group.isEmpty()) continue;
            EdgeData first = group.get(0);
            NodeData source = nodeById.get(first.from);
            PortData sourcePort = findPort(source, first.fromPort);
            if (source == null || sourcePort == null) continue;

            List<EdgeData> forward = new ArrayList<>();
            List<EdgeData> back = new ArrayList<>();
            for (EdgeData e : group) {
                NodeData target = nodeById.get(e.to);
                PortData targetPort = findPort(target, e.toPort);
                if (target == null || targetPort == null) continue;
                if (targetPort.cy > sourcePort.cy + dp(12)) forward.add(e); else back.add(e);
            }

            if (!forward.isEmpty()) {
                if (forward.size() > 1) {
                    float minX = sourcePort.cx;
                    float maxX = sourcePort.cx;
                    float nearestTargetY = Float.MAX_VALUE;
                    for (EdgeData e : forward) {
                        PortData tp = findPort(nodeById.get(e.to), e.toPort);
                        minX = Math.min(minX, tp.cx);
                        maxX = Math.max(maxX, tp.cx);
                        nearestTargetY = Math.min(nearestTargetY, tp.cy);
                    }
                    float available = Math.max(dp(26), nearestTargetY - sourcePort.cy);
                    float busY = sourcePort.cy + Math.min(available * 0.44f, dp(34) + dp(6) * (forwardTrack % 3));
                    Path trunk = new Path();
                    trunk.moveTo(sourcePort.cx, sourcePort.cy);
                    trunk.lineTo(sourcePort.cx, busY);
                    trunk.lineTo(minX, busY);
                    trunk.moveTo(sourcePort.cx, busY);
                    trunk.lineTo(maxX, busY);
                    canvas.drawPath(trunk, edgePaint);
                    for (EdgeData e : forward) {
                        PortData tp = findPort(nodeById.get(e.to), e.toPort);
                        Path branch = new Path();
                        branch.moveTo(tp.cx, busY);
                        branch.lineTo(tp.cx, tp.cy);
                        canvas.drawPath(branch, edgePaint);
                    }
                    drawEdgeLabel(canvas, first.eventType, sourcePort.cx + dp(6), busY - dp(5));
                    forwardTrack++;
                } else {
                    EdgeData e = forward.get(0);
                    PortData tp = findPort(nodeById.get(e.to), e.toPort);
                    float gap = tp.cy - sourcePort.cy;
                    float midY = sourcePort.cy + gap * 0.5f;
                    // Unique shallow offset keeps parallel neighbouring edges visually separate.
                    midY += dp((forwardTrack % 3) - 1) * 5f;
                    Path path = new Path();
                    path.moveTo(sourcePort.cx, sourcePort.cy);
                    path.lineTo(sourcePort.cx, midY);
                    path.lineTo(tp.cx, midY);
                    path.lineTo(tp.cx, tp.cy);
                    canvas.drawPath(path, edgePaint);
                    drawEdgeLabel(canvas, e.eventType, (sourcePort.cx + tp.cx) * 0.5f, midY - dp(5));
                    forwardTrack++;
                }
            }

            for (EdgeData e : back) {
                NodeData target = nodeById.get(e.to);
                PortData tp = findPort(target, e.toPort);
                float trackX = rightMost + dp(38) + dp(18) * backTrack;
                float outY = sourcePort.cy + dp(16) + dp(4) * (backTrack % 3);
                float inY = tp.cy - dp(18) - dp(4) * (backTrack % 3);
                Path path = new Path();
                path.moveTo(sourcePort.cx, sourcePort.cy);
                path.lineTo(sourcePort.cx, outY);
                path.lineTo(trackX, outY);
                path.lineTo(trackX, inY);
                path.lineTo(tp.cx, inY);
                path.lineTo(tp.cx, tp.cy);
                canvas.drawPath(path, edgePaint);
                drawEdgeLabel(canvas, e.eventType, trackX - dp(4), (outY + inY) * 0.5f);
                backTrack++;
            }
        }
    }

    private void drawEdgeLabel(Canvas canvas, String text, float x, float y) {
        if (text == null || text.isEmpty()) return;
        String s = shorten(text, 18);
        float w = edgeTextPaint.measureText(s);
        Paint.FontMetrics fm = edgeTextPaint.getFontMetrics();
        RectF bg = new RectF(x - dp(3), y + fm.ascent - dp(2), x + w + dp(3), y + fm.descent + dp(2));
        canvas.drawRect(bg, edgeLabelBgPaint);
        canvas.drawText(s, x, y, edgeTextPaint);
    }

    private void drawNodes(Canvas canvas) {
        for (NodeData n : nodes) {
            boolean expanded = isExpanded(n);
            nodePaint.setColor(nodeFill(n));
            nodeStrokePaint.setColor(nodeStroke(n));
            canvas.drawRoundRect(n.rect, dp(9), dp(9), nodePaint);
            canvas.drawRoundRect(n.rect, dp(9), dp(9), nodeStrokePaint);
            if (n.id.equals(selectedNodeId)) canvas.drawRoundRect(n.rect, dp(9), dp(9), selectionPaint);

            float left = n.rect.left + dp(11);
            canvas.drawText(expanded ? "v" : ">", left, n.rect.top + dp(18), foldPaint);
            canvas.drawText(shorten(n.label, 22), left + dp(15), n.rect.top + dp(18), titlePaint);

            float bx = n.rect.right - dp(12);
            float by = n.rect.top + dp(13);
            if (n.queued > 0) { drawBadge(canvas, bx, by, "Q" + n.queued, Color.rgb(68, 114, 196)); bx -= dp(22); }
            if (n.running > 0) { drawBadge(canvas, bx, by, "R" + n.running, Color.rgb(56, 142, 60)); bx -= dp(22); }
            if (n.suspended > 0) drawBadge(canvas, bx, by, "S" + n.suspended, Color.rgb(198, 119, 34));

            if (expanded) {
                canvas.drawText(n.type + "   cost " + n.cost + "   priority " + n.priority,
                        left + dp(15), n.rect.top + dp(37), metaPaint);
                String latest = (n.latestKind == null || n.latestKind.isEmpty()) ? "last: —" : "last: " + n.latestKind;
                canvas.drawText(shorten(latest, 31), left + dp(15), n.rect.top + dp(54), metaPaint);
                canvas.drawText("done " + n.completed + "   queue " + n.queued + "   run " + n.running + "   suspended " + n.suspended,
                        left + dp(15), n.rect.top + dp(71), metaPaint);
            } else {
                canvas.drawText(n.type, left + dp(15), n.rect.top + dp(35), metaPaint);
            }
            drawPorts(canvas, n, expanded);
        }
    }

    private void drawPorts(Canvas canvas, NodeData n, boolean expanded) {
        for (PortData p : n.ports) {
            boolean output = "Output".equals(p.direction);
            boolean isSelected = selectedOutput != null && selectedOutput.node.id.equals(n.id) && selectedOutput.port.id.equals(p.id);
            boolean compatible = editMode && selectedOutput != null && !output && selectedOutput.port.eventType.equals(p.eventType);
            if (isSelected) portPaint.setColor(Color.rgb(245, 196, 66));
            else if (compatible) portPaint.setColor(Color.rgb(86, 181, 112));
            else portPaint.setColor(output ? Color.rgb(95, 145, 210) : Color.rgb(120, 126, 133));
            canvas.drawCircle(p.cx, p.cy, dp(5.2f), portPaint);
            canvas.drawCircle(p.cx, p.cy, dp(5.2f), portStrokePaint);
            if (expanded) {
                float ty = output ? p.cy - dp(8) : p.cy + dp(13);
                canvas.drawText(shorten(p.name, 13), p.cx, ty, portTextPaint);
            }
        }
    }

    private int nodeFill(NodeData n) {
        if (n.suspended > 0) return Color.rgb(79, 55, 39);
        if (n.running > 0) return Color.rgb(38, 75, 48);
        if (n.queued > 0) return Color.rgb(39, 58, 82);
        if ("Commit".equals(n.type) && "Committed".equals(stop)) return Color.rgb(38, 72, 48);
        return Color.rgb(48, 52, 57);
    }

    private int nodeStroke(NodeData n) {
        if (n.suspended > 0) return Color.rgb(232, 152, 72);
        if (n.running > 0) return Color.rgb(103, 190, 113);
        if (n.queued > 0) return Color.rgb(100, 149, 237);
        return Color.rgb(104, 116, 128);
    }

    private void drawBadge(Canvas canvas, float cx, float cy, String text, int color) {
        badgePaint.setColor(color);
        float r = dp(9.5f);
        canvas.drawCircle(cx, cy, r, badgePaint);
        Paint.FontMetrics fm = badgeTextPaint.getFontMetrics();
        float y = cy - (fm.ascent + fm.descent) / 2f;
        canvas.drawText(text, cx, y, badgeTextPaint);
    }

    private NodeData hitNode(float screenX, float screenY) {
        float gx = (screenX - translateX) / scale;
        float gy = (screenY - translateY) / scale;
        for (int i = nodes.size() - 1; i >= 0; i--) if (nodes.get(i).rect.contains(gx, gy)) return nodes.get(i);
        return null;
    }

    private PortHit hitPort(float screenX, float screenY) {
        float radius = dp(20);
        for (NodeData n : nodes) {
            for (PortData p : n.ports) {
                float sx = translateX + p.cx * scale;
                float sy = translateY + p.cy * scale;
                float dx = sx - screenX;
                float dy = sy - screenY;
                if (dx * dx + dy * dy <= radius * radius) {
                    PortHit h = new PortHit();
                    h.node = n;
                    h.port = p;
                    return h;
                }
            }
        }
        return null;
    }

    private void handlePortTap(PortHit hit) {
        if (!editMode || hit == null) return;
        if ("Output".equals(hit.port.direction)) {
            if (selectedOutput != null && selectedOutput.node.id.equals(hit.node.id) && selectedOutput.port.id.equals(hit.port.id)) {
                selectedOutput = null;
                tell("Связь: выбор OUT отменён");
            } else {
                selectedOutput = hit;
                selectedNodeId = hit.node.id;
                expandedNodeId = hit.node.id;
                computeLayout();
                tell("OUT выбран: " + hit.node.label + "." + hit.port.name + " : " + hit.port.eventType + " → выбери совместимый IN");
            }
            invalidate();
            return;
        }
        if (selectedOutput == null) {
            selectedNodeId = hit.node.id;
            expandedNodeId = hit.node.id;
            computeLayout();
            tell("IN " + hit.node.label + "." + hit.port.name + ": сначала выбери OUT-порт");
            invalidate();
            return;
        }
        if (!selectedOutput.port.eventType.equals(hit.port.eventType)) {
            tell("TYPE MISMATCH: " + selectedOutput.port.eventType + " != " + hit.port.eventType);
            return;
        }
        if (listener != null) {
            listener.onConnect(selectedOutput.node.id, selectedOutput.port.id, hit.node.id, hit.port.id);
        }
        selectedOutput = null;
        invalidate();
    }

    private void selectAndToggle(NodeData n) {
        if (n == null) return;
        selectedNodeId = n.id;
        if (n.id.equals(expandedNodeId)) expandedNodeId = null;
        else expandedNodeId = n.id;
        computeLayout();
        if (listener != null) listener.onNodeSelected(n.id, n.label, n.type);
        invalidate();
    }

    private void tell(String message) {
        if (listener != null) listener.onEditorMessage(message);
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        scaleDetector.onTouchEvent(event);
        if (event.getPointerCount() > 1) {
            panning = false;
            draggedNode = null;
            pressedNode = null;
            downPort = null;
            return true;
        }
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = lastX = event.getX();
                downY = lastY = event.getY();
                moved = false;
                panning = false;
                downPort = editMode ? hitPort(event.getX(), event.getY()) : null;
                if (downPort != null) return true;

                pressedNode = hitNode(event.getX(), event.getY());
                if (pressedNode != null) {
                    if (editMode) draggedNode = pressedNode;
                    return true;
                }
                panning = true;
                return true;

            case MotionEvent.ACTION_MOVE:
                if (scaleDetector.isInProgress()) return true;
                float x = event.getX();
                float y = event.getY();
                if (Math.abs(x - downX) + Math.abs(y - downY) > dp(7)) moved = true;

                if (draggedNode != null && editMode) {
                    if (moved) {
                        float dx = (x - lastX) / scale;
                        float dy = (y - lastY) / scale;
                        draggedNode.rect.offset(dx, dy);
                        draggedNode.rect.offsetTo(Math.max(0, draggedNode.rect.left), Math.max(0, draggedNode.rect.top));
                        layoutPorts();
                        recomputeContentBounds();
                    }
                } else if (pressedNode != null && !editMode && moved) {
                    // In VIEW a gesture that starts on a bar becomes panning only after the tap threshold.
                    pressedNode = null;
                    panning = true;
                    translateX += x - lastX;
                    translateY += y - lastY;
                } else if (panning) {
                    translateX += x - lastX;
                    translateY += y - lastY;
                }
                lastX = x;
                lastY = y;
                invalidate();
                return true;

            case MotionEvent.ACTION_UP:
                if (downPort != null && !moved) {
                    handlePortTap(downPort);
                    downPort = null;
                    return true;
                }
                if (draggedNode != null) {
                    NodeData n = draggedNode;
                    draggedNode = null;
                    pressedNode = null;
                    if (moved) {
                        selectedNodeId = n.id;
                        if (listener != null) listener.onNodeMoved(n.id, n.rect.left / density(), n.rect.top / density());
                    } else {
                        selectAndToggle(n);
                    }
                    invalidate();
                    return true;
                }
                if (pressedNode != null && !moved) {
                    NodeData n = pressedNode;
                    pressedNode = null;
                    selectAndToggle(n);
                    return true;
                }
                if (!moved && hitNode(event.getX(), event.getY()) == null) {
                    selectedNodeId = null;
                    expandedNodeId = null;
                    selectedOutput = null;
                    computeLayout();
                    tell("Выбор снят");
                    invalidate();
                }
                panning = false;
                pressedNode = null;
                return true;

            case MotionEvent.ACTION_CANCEL:
                panning = false;
                draggedNode = null;
                pressedNode = null;
                downPort = null;
                return true;
            default:
                return true;
        }
    }

    public String compactSummary() {
        if (!active) return "runtime: не инициализирован";
        return graphId + " r" + graphRevision + "   iter " + iteration + "   resource " + spent + "/" + totalBudget +
                "   осталось " + remaining + "   stop " + stop + (editMode ? "   EDIT" : "");
    }

    private float density() { return getResources().getDisplayMetrics().density; }
    private float dp(float value) { return value * density(); }
    private static float clamp(float v, float min, float max) { return Math.max(min, Math.min(max, v)); }
    private static String shorten(String s, int max) {
        if (s == null) return "";
        if (s.length() <= max) return s;
        return s.substring(0, Math.max(1, max - 1)) + "…";
    }
}
