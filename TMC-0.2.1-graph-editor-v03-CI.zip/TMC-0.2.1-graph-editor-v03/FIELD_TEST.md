# FIELD TEST — TMC 0.2.1-graph-editor-v03

## 1. UI / palette

Open `ГРАФ` after upgrade. Expected:

- only a compact `ПАЛИТРА` header remains at the bottom when collapsed;
- tapping it expands two horizontal sections: `ПОСТРОЕНИЕ` and `ОПЕРАЦИИ`;
- buttons have moderate rounded corners and gaps;
- graph gets substantially more vertical space than v02.

## 2. Tap vs drag

Initialize if necessary:

```text
runtime reset
runtime init demo
```

- tap a Node: it becomes selected and the lower bar opens;
- enable `EDIT` in `ПОСТРОЕНИЕ`;
- drag the Node from its body/header: it must move;
- tap without moving: only selection/context should happen.

## 3. Ports

In EDIT:

1. tap Claim Input `claim` OUT near the visible port;
2. tap a compatible `claim` IN.

The visible port is larger and the nearest-port touch target is about 30 dp. Type mismatch remains blocked by Rust/UI.

## 4. Node + Edge editing

Before execution, use direct palette buttons to add any current Node type.

- select a user Node and use `УДАЛ. УЗЕЛ`;
- tap near an Edge curve: it should highlight;
- use `УДАЛ. СВЯЗЬ`; `runtime validate` should reflect the removed Edge.

## 5. Portrait layout / text

Press `AUTO`, then `ВПИСАТЬ`.

Expected:

- two parallel check Nodes use most of portrait width instead of forcing a 400 dp canvas;
- node titles/meta/port labels do not overlap each other;
- Edge event labels have a dark background and reduced collisions.

## 6. Regression

```text
runtime validate
storage verify
```

Both must remain valid. Runtime/resource/SQLite behavior is unchanged in this patch.
