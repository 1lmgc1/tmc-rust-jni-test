# FIELD TEST — TMC 0.2.1-graph-editor-v03

Это прежде всего UI-тест. Полный resource-runtime заново прогонять не требуется.

## A. Restore

Установить поверх v02 и открыть приложение. SQLite должен восстановиться как раньше.

Если хочется чистый graph state:

```text
runtime reset
runtime init demo
runtime validate
```

Ожидается `nodes=6 edges=8`.

## B. Selection regression

На вкладке ГРАФ, **не включая EDIT**:

1. тапнуть `Semantic Check`;
2. bar должен получить жёлтую рамку и развернуться;
3. должны появиться type / cost / priority / last / runtime counters / port names;
4. тапнуть bar ещё раз — он сворачивается, выделение остаётся;
5. тапнуть другой bar — раскрывается уже он.

Это основной regression-тест бага v02.

## C. Tree / bars

Базовый graph должен читаться сверху вниз компактными строками:

```text
Claim Input
     │
 Semantic   Counter
      \       /
        Compare
       /      \
  Revision   Commit
     └──── cycle ────→ Checks
```

Нажать `ДРЕВО`: сохранённые ручные позиции очищаются, ветви возвращаются к уровневой раскладке.

## D. Orthogonal edges

Проверить визуально:

- линии состоят только из горизонтальных/вертикальных отрезков;
- Input fan-out имеет общий ствол/шину и отдельные ответвления;
- Revision → Checks проходит через боковые tracks, а не поверх центральных Node;
- линии не являются Bézier-кривыми;
- подписи event type читаются поверх собственного фона.

## E. EDIT не сломан

Включить `РЕДАКТОР`:

1. тап bar → выделение/раскрытие;
2. drag bar → перемещение;
3. закрыть/открыть приложение → позиция сохраняется;
4. `+ УЗЕЛ` → `SemanticCheck`;
5. новый неподключённый Node должен появиться ниже основной topology, а не в корневой строке;
6. OUT Claim Input → IN нового SemanticCheck остаётся рабочим typed connection.

После соединения:

```text
runtime validate
runtime emit claim <bars test>
runtime queue
```

Ожидается `routed=3 newly_queued=3`.
