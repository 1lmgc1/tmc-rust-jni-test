use jni::objects::{JClass, JString};
use jni::sys::{jboolean, jstring, JNI_FALSE, JNI_TRUE};
use jni::JNIEnv;
use serde::{Deserialize, Serialize};
use rusqlite::{params, Connection, OptionalExtension};
use std::collections::HashSet;
use std::ptr;
use std::sync::{Mutex, OnceLock};
use std::time::{SystemTime, UNIX_EPOCH};

const VERSION: &str = "0.2.1-graph-editor-v04";
const VERSION_CODE: u32 = 25;

#[derive(Debug, Clone, Serialize, Deserialize)]
struct RevisionRecord {
    note: String,
    previous_function_context: Option<String>,
    previous_criterion: Option<String>,
    previous_hash: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct ConcessionRecord {
    target: String,
    reason: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct DefinitionRecord {
    name: String,
    frame: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct BindingRecord {
    relation: String,
    value: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
struct ProjectState {
    active: bool,
    name: Option<String>,
    claim: Option<String>,
    operator: Option<String>,
    phase: u8,
    expected_concept_frame: Option<String>,
    expected_relation: Option<String>,
    result: Option<String>,
}


#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
enum PortDirection {
    Input,
    Output,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
enum PortCardinality {
    One,
    Optional,
    All,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct PortSpec {
    id: String,
    name: String,
    direction: PortDirection,
    event_type: String,
    cardinality: PortCardinality,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct NodeSpec {
    id: String,
    node_type: String,
    label: String,
    implementation_version: u32,
    ports: Vec<PortSpec>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct EdgeSpec {
    id: String,
    from_node: String,
    from_port: String,
    to_node: String,
    to_port: String,
    event_type: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct NodeLayout {
    node_id: String,
    x: f32,
    y: f32,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
struct GraphState {
    graph_id: String,
    revision: u32,
    nodes: Vec<NodeSpec>,
    edges: Vec<EdgeSpec>,
    #[serde(default)]
    layout: Vec<NodeLayout>,
}

fn default_event_schema() -> u32 { 1 }

#[derive(Debug, Clone, Serialize, Deserialize)]
struct EventRecord {
    #[serde(default = "default_event_schema")]
    schema_version: u32,
    #[serde(default)]
    graph_id: String,
    seq: u64,
    event_id: String,
    kind: String,
    payload_json: String,
    source_node: Option<String>,
    source_port: Option<String>,
    branch_id: String,
    correlation_id: String,
    iteration: u32,
    parent_event_id: Option<String>,
    #[serde(default)]
    previous_hash: String,
    #[serde(default)]
    event_hash: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
enum WorkStatus {
    Queued,
    Running,
    Suspended,
    Completed,
    Rejected,
    DeadEnd,
    Cancelled,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct WorkItem {
    id: String,
    node_id: String,
    input_event_ids: Vec<String>,
    iteration: u32,
    priority: i32,
    #[serde(default)]
    budget: u32,
    #[serde(default)]
    estimated_cost: u32,
    #[serde(default)]
    actual_cost: Option<u32>,
    status: WorkStatus,
    attempts: u32,
    #[serde(default)]
    suspend_reason: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct InputBinding {
    port_id: String,
    event_id: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct InputFrame {
    id: String,
    node_id: String,
    branch_id: String,
    correlation_id: String,
    iteration: u32,
    bindings: Vec<InputBinding>,
    ready: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct ResourceLedgerEntry {
    id: String,
    work_id: String,
    node_id: String,
    branch_id: String,
    iteration: u32,
    operation: String,
    cost: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct ResourcePolicy {
    total_budget: u32,
    branch_cap: u32,
    iteration_budget_cap: u32,
    max_iterations: u32,
}

impl Default for ResourcePolicy {
    fn default() -> Self {
        Self {
            total_budget: 30,
            branch_cap: 30,
            iteration_budget_cap: 12,
            max_iterations: 8,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
struct ResourceState {
    policy: ResourcePolicy,
    ledger: Vec<ResourceLedgerEntry>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct RuntimeState {
    active: bool,
    graph: GraphState,
    events: Vec<EventRecord>,
    input_frames: Vec<InputFrame>,
    work_items: Vec<WorkItem>,
    branch_id: String,
    correlation_id: String,
    iteration: u32,
    next_seq: u64,
    #[serde(default)]
    resource: ResourceState,
    #[serde(default)]
    stop_reason: Option<String>,
}

impl Default for RuntimeState {
    fn default() -> Self {
        Self {
            active: false,
            graph: GraphState::default(),
            events: Vec::new(),
            input_frames: Vec::new(),
            work_items: Vec::new(),
            branch_id: "root".into(),
            correlation_id: "analysis-0".into(),
            iteration: 0,
            next_seq: 1,
            resource: ResourceState::default(),
            stop_reason: None,
        }
    }
}


#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
struct ModelState {
    schema: u32,
    debate_name: Option<String>,
    resolution: Option<String>,
    collision_a: Option<String>,
    collision_b: Option<String>,
    function_context: Option<String>,
    criterion: Option<String>,
    committed: bool,
    step: u8,
    status_resource: u8,
    robustness: u8,
    revisions: Vec<RevisionRecord>,
    concessions: Vec<ConcessionRecord>,
    project: ProjectState,
    definitions: Vec<DefinitionRecord>,
    bindings: Vec<BindingRecord>,
    runtime: RuntimeState,
}

impl Default for ModelState {
    fn default() -> Self {
        Self {
            schema: 2,
            debate_name: None,
            resolution: None,
            collision_a: None,
            collision_b: None,
            function_context: None,
            criterion: None,
            committed: false,
            step: 0,
            status_resource: 100,
            robustness: 100,
            revisions: Vec::new(),
            concessions: Vec::new(),
            project: ProjectState::default(),
            definitions: Vec::new(),
            bindings: Vec::new(),
            runtime: RuntimeState::default(),
        }
    }
}

static STATE: OnceLock<Mutex<ModelState>> = OnceLock::new();
fn state() -> &'static Mutex<ModelState> { STATE.get_or_init(|| Mutex::new(ModelState::default())) }

static STORAGE_PATH: OnceLock<Mutex<Option<String>>> = OnceLock::new();
fn storage_slot() -> &'static Mutex<Option<String>> { STORAGE_PATH.get_or_init(|| Mutex::new(None)) }

fn unix_ms() -> i64 {
    SystemTime::now().duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis().min(i64::MAX as u128) as i64)
        .unwrap_or(0)
}

fn storage_path_value() -> Option<String> {
    storage_slot().lock().ok().and_then(|g| g.clone())
}

fn storage_active() -> bool { storage_path_value().is_some() }

fn open_storage() -> Result<Connection, String> {
    let path = storage_path_value().ok_or_else(|| "SQLite storage не инициализирован".to_string())?;
    Connection::open(path).map_err(|e| format!("SQLite open: {}", e))
}

fn init_storage_schema(conn: &Connection) -> Result<(), String> {
    conn.execute_batch(r#"
        PRAGMA journal_mode=WAL;
        PRAGMA synchronous=NORMAL;
        PRAGMA foreign_keys=ON;
        CREATE TABLE IF NOT EXISTS event_log (
            seq INTEGER PRIMARY KEY,
            event_id TEXT NOT NULL UNIQUE,
            schema_version INTEGER NOT NULL,
            graph_id TEXT NOT NULL,
            kind TEXT NOT NULL,
            payload_json TEXT NOT NULL,
            source_node TEXT,
            source_port TEXT,
            branch_id TEXT NOT NULL,
            correlation_id TEXT NOT NULL,
            iteration INTEGER NOT NULL,
            parent_event_id TEXT,
            previous_hash TEXT NOT NULL,
            event_hash TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_event_kind ON event_log(kind);
        CREATE INDEX IF NOT EXISTS idx_event_branch ON event_log(branch_id, iteration, seq);
        CREATE INDEX IF NOT EXISTS idx_event_correlation ON event_log(correlation_id, seq);

        CREATE TABLE IF NOT EXISTS state_checkpoint (
            id INTEGER PRIMARY KEY CHECK(id = 1),
            schema_version INTEGER NOT NULL,
            state_json TEXT NOT NULL,
            last_event_seq INTEGER NOT NULL,
            updated_at_ms INTEGER NOT NULL
        );

        CREATE TABLE IF NOT EXISTS work_projection (
            id TEXT PRIMARY KEY,
            data_json TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS frame_projection (
            id TEXT PRIMARY KEY,
            data_json TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS resource_projection (
            id TEXT PRIMARY KEY,
            data_json TEXT NOT NULL
        );
    "#).map_err(|e| format!("SQLite schema: {}", e))
}

fn storage_max_seq() -> u64 {
    let conn = match open_storage() { Ok(c) => c, Err(_) => return 0 };
    let value: i64 = conn.query_row("SELECT COALESCE(MAX(seq),0) FROM event_log", [], |r| r.get(0)).unwrap_or(0);
    value.max(0) as u64
}

fn normalize_runtime_event_chain(runtime: &mut RuntimeState) {
    let mut prev = "GENESIS".to_string();
    let graph_id = runtime.graph.graph_id.clone();
    let mut max_seq = 0u64;
    for event in &mut runtime.events {
        event.schema_version = if event.schema_version == 0 { 1 } else { event.schema_version };
        if event.graph_id.is_empty() { event.graph_id = graph_id.clone(); }
        event.previous_hash = prev.clone();
        let material = format!(
            "{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}",
            event.schema_version,
            event.graph_id,
            event.seq,
            event.event_id,
            event.kind,
            event.payload_json,
            event.source_node.as_deref().unwrap_or(""),
            event.source_port.as_deref().unwrap_or(""),
            event.parent_event_id.as_deref().unwrap_or(""),
            event.branch_id,
            event.correlation_id,
            event.iteration
        );
        event.event_hash = format!("{:016x}", fnv1a64(format!("{}|{}", prev, material).as_bytes()));
        prev = event.event_hash.clone();
        max_seq = max_seq.max(event.seq);
    }
    runtime.next_seq = runtime.next_seq.max(max_seq.saturating_add(1));
}

fn verify_runtime_event_chain(runtime: &RuntimeState) -> Result<(), String> {
    let mut prev = "GENESIS".to_string();
    for event in &runtime.events {
        if event.previous_hash != prev {
            return Err(format!("chain break at {}: previous_hash mismatch", event.event_id));
        }
        let material = format!(
            "{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}",
            event.schema_version,
            event.graph_id,
            event.seq,
            event.event_id,
            event.kind,
            event.payload_json,
            event.source_node.as_deref().unwrap_or(""),
            event.source_port.as_deref().unwrap_or(""),
            event.parent_event_id.as_deref().unwrap_or(""),
            event.branch_id,
            event.correlation_id,
            event.iteration
        );
        let expected = format!("{:016x}", fnv1a64(format!("{}|{}", prev, material).as_bytes()));
        if event.event_hash != expected {
            return Err(format!("chain break at {}: hash mismatch", event.event_id));
        }
        prev = event.event_hash.clone();
    }
    Ok(())
}

fn persist_model_state(snapshot: &ModelState) -> Result<String, String> {
    let mut conn = open_storage()?;
    init_storage_schema(&conn)?;
    let tx = conn.transaction().map_err(|e| format!("SQLite transaction: {}", e))?;

    for event in &snapshot.runtime.events {
        tx.execute(
            "INSERT OR IGNORE INTO event_log (seq,event_id,schema_version,graph_id,kind,payload_json,source_node,source_port,branch_id,correlation_id,iteration,parent_event_id,previous_hash,event_hash) VALUES (?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11,?12,?13,?14)",
            params![
                event.seq as i64,
                &event.event_id,
                event.schema_version as i64,
                &event.graph_id,
                &event.kind,
                &event.payload_json,
                event.source_node.as_deref(),
                event.source_port.as_deref(),
                &event.branch_id,
                &event.correlation_id,
                event.iteration as i64,
                event.parent_event_id.as_deref(),
                &event.previous_hash,
                &event.event_hash,
            ],
        ).map_err(|e| format!("SQLite event insert {}: {}", event.event_id, e))?;
    }

    tx.execute("DELETE FROM work_projection", []).map_err(|e| format!("SQLite work clear: {}", e))?;
    for item in &snapshot.runtime.work_items {
        let data = serde_json::to_string(item).map_err(|e| format!("work serialize: {}", e))?;
        tx.execute("INSERT INTO work_projection(id,data_json) VALUES (?1,?2)", params![&item.id, data])
            .map_err(|e| format!("SQLite work insert {}: {}", item.id, e))?;
    }

    tx.execute("DELETE FROM frame_projection", []).map_err(|e| format!("SQLite frame clear: {}", e))?;
    for frame in &snapshot.runtime.input_frames {
        let data = serde_json::to_string(frame).map_err(|e| format!("frame serialize: {}", e))?;
        tx.execute("INSERT INTO frame_projection(id,data_json) VALUES (?1,?2)", params![&frame.id, data])
            .map_err(|e| format!("SQLite frame insert {}: {}", frame.id, e))?;
    }

    tx.execute("DELETE FROM resource_projection", []).map_err(|e| format!("SQLite resource clear: {}", e))?;
    for entry in &snapshot.runtime.resource.ledger {
        let data = serde_json::to_string(entry).map_err(|e| format!("resource serialize: {}", e))?;
        tx.execute("INSERT INTO resource_projection(id,data_json) VALUES (?1,?2)", params![&entry.id, data])
            .map_err(|e| format!("SQLite resource insert {}: {}", entry.id, e))?;
    }

    let state_json = serde_json::to_string(snapshot).map_err(|e| format!("state serialize: {}", e))?;
    let last_seq: i64 = tx.query_row("SELECT COALESCE(MAX(seq),0) FROM event_log", [], |r| r.get(0)).unwrap_or(0);
    tx.execute(
        "INSERT INTO state_checkpoint(id,schema_version,state_json,last_event_seq,updated_at_ms) VALUES (1,?1,?2,?3,?4) ON CONFLICT(id) DO UPDATE SET schema_version=excluded.schema_version,state_json=excluded.state_json,last_event_seq=excluded.last_event_seq,updated_at_ms=excluded.updated_at_ms",
        params![snapshot.schema as i64, state_json, last_seq, unix_ms()],
    ).map_err(|e| format!("SQLite checkpoint: {}", e))?;

    tx.commit().map_err(|e| format!("SQLite commit: {}", e))?;
    Ok(format!("checkpoint offset={} events_current={}", last_seq, snapshot.runtime.events.len()))
}

fn persist_storage_snapshot() -> Result<String, String> {
    if !storage_active() { return Err("SQLite storage не инициализирован".into()); }
    let snapshot = state().lock().map_err(|_| "state lock poisoned".to_string())?.clone();
    persist_model_state(&snapshot)
}

fn initialize_storage(path: &str) -> Result<String, String> {
    {
        let mut slot = storage_slot().lock().map_err(|_| "storage lock poisoned".to_string())?;
        *slot = Some(path.to_string());
    }
    let conn = open_storage()?;
    init_storage_schema(&conn)?;
    let row: Option<(String, i64)> = conn.query_row(
        "SELECT state_json,last_event_seq FROM state_checkpoint WHERE id=1",
        [],
        |r| Ok((r.get(0)?, r.get(1)?)),
    ).optional().map_err(|e| format!("SQLite checkpoint read: {}", e))?;

    let event_count: i64 = conn.query_row("SELECT COUNT(*) FROM event_log", [], |r| r.get(0)).unwrap_or(0);
    if let Some((json, offset)) = row {
        let mut parsed: ModelState = serde_json::from_str(&json).map_err(|e| format!("checkpoint parse: {}", e))?;
        if parsed.schema != 2 { return Err(format!("checkpoint schema {} не поддерживается", parsed.schema)); }
        normalize_runtime_event_chain(&mut parsed.runtime);
        *state().lock().map_err(|_| "state lock poisoned".to_string())? = parsed;
        Ok(format!("RESTORED offset={} durable_events={}", offset, event_count))
    } else {
        Ok(format!("EMPTY durable_events={}", event_count))
    }
}

fn storage_status_text() -> String {
    let path = match storage_path_value() {
        Some(p) => p,
        None => return "storage.active=false".into(),
    };
    let conn = match open_storage() {
        Ok(c) => c,
        Err(e) => return format!("storage.active=true\npath={}\nERROR {}", path, e),
    };
    let events: i64 = conn.query_row("SELECT COUNT(*) FROM event_log", [], |r| r.get(0)).unwrap_or(-1);
    let max_seq: i64 = conn.query_row("SELECT COALESCE(MAX(seq),0) FROM event_log", [], |r| r.get(0)).unwrap_or(-1);
    let work: i64 = conn.query_row("SELECT COUNT(*) FROM work_projection", [], |r| r.get(0)).unwrap_or(-1);
    let frames: i64 = conn.query_row("SELECT COUNT(*) FROM frame_projection", [], |r| r.get(0)).unwrap_or(-1);
    let ledger: i64 = conn.query_row("SELECT COUNT(*) FROM resource_projection", [], |r| r.get(0)).unwrap_or(-1);
    let checkpoint: i64 = conn.query_row("SELECT COALESCE(MAX(last_event_seq),0) FROM state_checkpoint", [], |r| r.get(0)).unwrap_or(0);
    format!(
        "storage.active=true\nbackend=SQLite WAL\npath={}\ndurable_events={} max_seq={} checkpoint_offset={}\nprojection work={} frames={} ledger={}",
        path, events, max_seq, checkpoint, work, frames, ledger
    )
}

fn storage_verify_text() -> String {
    let conn = match open_storage() {
        Ok(c) => c,
        Err(e) => return format!("STORAGE INVALID: {}", e),
    };
    let integrity: String = conn.query_row("PRAGMA integrity_check", [], |r| r.get(0)).unwrap_or_else(|e| format!("error:{}", e));
    let events: i64 = conn.query_row("SELECT COUNT(*) FROM event_log", [], |r| r.get(0)).unwrap_or(-1);
    let duplicate_ids: i64 = conn.query_row(
        "SELECT COUNT(*) FROM (SELECT event_id FROM event_log GROUP BY event_id HAVING COUNT(*)>1)",
        [], |r| r.get(0)
    ).unwrap_or(-1);
    let chain = state().lock().ok().map(|s| verify_runtime_event_chain(&s.runtime)).unwrap_or_else(|| Err("state lock poisoned".into()));
    match chain {
        Ok(()) if integrity == "ok" && duplicate_ids == 0 => format!("STORAGE VALID integrity=ok durable_events={} duplicate_event_ids=0 current_chain=ok", events),
        Ok(()) => format!("STORAGE INVALID integrity={} durable_events={} duplicate_event_ids={} current_chain=ok", integrity, events, duplicate_ids),
        Err(e) => format!("STORAGE INVALID integrity={} durable_events={} duplicate_event_ids={} current_chain={}", integrity, events, duplicate_ids, e),
    }
}

fn fnv1a64(bytes: &[u8]) -> u64 {
    let mut h = 0xcbf29ce484222325u64;
    for &b in bytes {
        h ^= b as u64;
        h = h.wrapping_mul(0x100000001b3);
    }
    h
}

#[derive(Serialize)]
struct DisputeHashState<'a> {
    schema: u32,
    debate_name: &'a Option<String>,
    resolution: &'a Option<String>,
    collision_a: &'a Option<String>,
    collision_b: &'a Option<String>,
    function_context: &'a Option<String>,
    criterion: &'a Option<String>,
    committed: bool,
    step: u8,
    status_resource: u8,
    robustness: u8,
    revisions: &'a Vec<RevisionRecord>,
    concessions: &'a Vec<ConcessionRecord>,
}

fn canonical_model_hash(s: &ModelState) -> String {
    let view = DisputeHashState {
        schema: s.schema,
        debate_name: &s.debate_name,
        resolution: &s.resolution,
        collision_a: &s.collision_a,
        collision_b: &s.collision_b,
        function_context: &s.function_context,
        criterion: &s.criterion,
        committed: s.committed,
        step: s.step,
        status_resource: s.status_resource,
        robustness: s.robustness,
        revisions: &s.revisions,
        concessions: &s.concessions,
    };
    let data = serde_json::to_vec(&view).unwrap_or_default();
    format!("{:016x}", fnv1a64(&data))
}

#[derive(Serialize)]
struct ProofHashState<'a> {
    project: &'a ProjectState,
    definitions: &'a Vec<DefinitionRecord>,
    bindings: &'a Vec<BindingRecord>,
}

fn canonical_proof_hash(s: &ModelState) -> String {
    let view = ProofHashState {
        project: &s.project,
        definitions: &s.definitions,
        bindings: &s.bindings,
    };
    let data = serde_json::to_vec(&view).unwrap_or_default();
    format!("{:016x}", fnv1a64(&data))
}

fn require_debate(s: &ModelState) -> Result<(), String> {
    if s.debate_name.is_none() { Err("ОШИБКА: debate ещё не создан".into()) } else { Ok(()) }
}

fn project_expectation(p: &ProjectState) -> Option<String> {
    if !p.active { return None; }
    Some(match p.phase {
        1 => "claim <name>".into(),
        2 => "run classify.exclude".into(),
        3 => "definition create functional".into(),
        4 => "bind follows_communist_principles <true|false>".into(),
        5 => "resume".into(),
        _ => "proof audit | project state | project reset".into(),
    })
}

fn expectation_for(s: &ModelState) -> String {
    if s.runtime.active {
        if s.runtime.stop_reason.is_some() {
            return "runtime ledger | runtime events | runtime state | runtime reset".into();
        }
        let queued = s.runtime.work_items.iter().any(|w| w.status == WorkStatus::Queued);
        if queued {
            return "runtime step | runtime run | runtime queue | runtime ledger | runtime events | runtime state | runtime reset".into();
        }
        let has_execution_events = s.runtime.events.iter().any(|e| !e.kind.starts_with("Graph"));
        if !has_execution_events {
            return "runtime emit claim <text> | graph node add <type> | runtime budget set <n> | runtime validate | runtime state | runtime reset".into();
        }
        return "runtime ledger | runtime events | runtime state | runtime reset".into();
    }
    if let Some(e) = project_expectation(&s.project) { return e; }
    match s.step {
        0 => "debate new <name> | project new <name> | runtime init demo".into(),
        1 => "resolution <text>".into(),
        2 => "collision open <position-a> | <position-b>".into(),
        3 => "function accept <function/context>".into(),
        4 => "criterion accept <criterion>".into(),
        5 => "commit".into(),
        _ => "model audit | model status | model revise <text> | model concede <target> | <reason> | project new <name>".into(),
    }
}

fn help_text() -> String {
    [
        "=== TMC HELP / СПРАВКА ===",
        "",
        "ТРИ СЛОЯ:",
        "A) dispute-модель: формализация коллизии и фиксация frame",
        "B) typed-operator: NEED_INPUT → definition/bind → resume",
        "C) resource runtime: typed Graph → Event → Queue → Scheduler → ResourceLedger",
        "",
        "--- A. DISPUTE ---",
        "1) debate new <name>",
        "2) resolution <text>",
        "3) collision open <position-a> | <position-b>",
        "4) function accept <function/context>",
        "5) criterion accept <criterion>",
        "6) commit",
        "после commit: model audit / model status / model revise <text> / model concede <target> | <reason>",
        "",
        "--- B. TYPED OPERATOR ---",
        "project new <name>             — создать проект вычисления",
        "claim <name>                   — задать объект/утверждение",
        "run classify.exclude           — запустить оператор исключающей классификации",
        "definition create functional   — создать локальный concept frame",
        "bind follows_communist_principles <true|false> — связать требуемое отношение со значением",
        "resume                         — продолжить приостановленную операцию",
        "proof audit                    — hash доказательного состояния",
        "project state                  — состояние typed-операции",
        "project reset                  — сбросить только текущий typed-проект",
        "",
        "Эталонный вертикальный сценарий:",
        "project new demo",
        "claim kpss",
        "run classify.exclude",
        "definition create functional",
        "bind follows_communist_principles false",
        "resume",
        "proof audit",
        "",
        "--- C. RESOURCE RUNTIME ---",
        "runtime init demo       — создать циклический Graph Input → Checks → Compare → Revision/Commit",
        "runtime validate        — проверить topology и event types",
        "runtime emit claim <t>  — записать ClaimEvent и маршрутизировать по Graph",
        "runtime queue           — показать InputFrames и WorkQueue",
        "runtime step            — выполнить один доступный WorkItem с учётом бюджета",
        "runtime run             — выполнять очередь автоматически до stop/empty (safety max 64 steps)",
        "runtime ledger          — показать расход аналитического ресурса",
        "runtime budget set <n>  — задать общий budget до начала исполнения",
        "runtime events          — показать EventLog текущего анализа",
        "storage status          — состояние durable SQLite store",
        "storage verify          — PRAGMA integrity_check + проверка hash-chain",
        "storage checkpoint      — принудительно записать checkpoint",
        "runtime state           — topology + operational counters",
        "runtime reset           — сбросить текущий runtime; durable EventLog в SQLite не удаляется",
        "",
        "--- GRAPH EDITOR v01 ---",
        "graph node add <type>                         — добавить executable Node",
        "graph node remove <n-user-id>                 — удалить пользовательский Node и его edges",
        "graph edge add <node.port> <node.port>        — добавить typed Edge Output → Input",
        "graph edge remove <edge-id>                   — удалить Edge",
        "graph layout set <node-id> <x> <y>            — сохранить позицию Node",
        "graph layout clear                            — сбросить ручной layout",
        "Структурные правки разрешены до начала исполнения; layout можно менять всегда.",
        "",
        "0.2.1-v04: прямые Edge без Безье; мобильная палитра стабилизирована; русские подписи функций; Rust topology/runtime сохранены.",
        "",
        "Смысл NEED_INPUT:",
        "оператор не угадывает отсутствующее значение. Он фиксирует, чего не хватает, приостанавливается и ждёт definition/bind. После этого команда resume продолжает ту же операцию.",
        "",
        "--- ПАКЕТНЫЙ ВВОД (ANDROID UI) ---",
        "Можно вставить несколько команд: одна команда на строку.",
        "Пустые строки и строки с # в начале игнорируются.",
        "При жёсткой ошибке пакет останавливается, остаток возвращается в поле ввода.",
        "NEED_INPUT не считается ошибкой: следующая строка списка может дать definition/bind/resume.",
        "",
        "--- СИСТЕМА ---",
        "system version  — версия приложения и Rust-ядра",
        "system state    — dispute + typed + runtime состояние целиком",
        "system reset    — сброс текущего dispute + typed + runtime; durable SQLite audit log сохраняется",
        "help / помощь   — эта справка",
        "calc 7 + 5      — простая Rust-проверка",
        "",
        "Подсказки:",
        "— Следуй строке 'Ожидаю: ...'",
        "— Для collision и concede разделитель — вертикальная черта |",
        "— Команды остаются латиницей: русский язык используется в интерфейсе и пояснениях.",
    ].join("\n")
}

fn project_state_text(s: &ModelState) -> String {
    let p = &s.project;
    let mut out = Vec::new();
    out.push(format!("project.active={} phase={}", p.active, p.phase));
    out.push(format!("project.name={}", p.name.as_deref().unwrap_or("<none>")));
    out.push(format!("claim={}", p.claim.as_deref().unwrap_or("<none>")));
    out.push(format!("operator={}", p.operator.as_deref().unwrap_or("<none>")));
    out.push(format!("expected_concept_frame={}", p.expected_concept_frame.as_deref().unwrap_or("<none>")));
    out.push(format!("expected_relation={}", p.expected_relation.as_deref().unwrap_or("<none>")));
    out.push(format!("result={}", p.result.as_deref().unwrap_or("<none>")));
    out.push(format!("definitions={} bindings={}", s.definitions.len(), s.bindings.len()));
    for (i, d) in s.definitions.iter().enumerate() {
        out.push(format!("definition[{}]={} -> {}", i + 1, d.name, d.frame));
    }
    for (i, b) in s.bindings.iter().enumerate() {
        out.push(format!("binding[{}]={}={}", i + 1, b.relation, b.value));
    }
    out.join("\n")
}

fn system_state_text(s: &ModelState) -> String {
    let mut out = Vec::new();
    out.push("[DISPUTE]".into());
    out.push(format!("step={} committed={}", s.step, s.committed));
    out.push(format!("debate={}", s.debate_name.as_deref().unwrap_or("<none>")));
    out.push(format!("resolution={}", s.resolution.as_deref().unwrap_or("<none>")));
    out.push(format!("collision.a={}", s.collision_a.as_deref().unwrap_or("<none>")));
    out.push(format!("collision.b={}", s.collision_b.as_deref().unwrap_or("<none>")));
    out.push(format!("function_context={}", s.function_context.as_deref().unwrap_or("<none>")));
    out.push(format!("criterion={}", s.criterion.as_deref().unwrap_or("<none>")));
    out.push(format!(
        "status_resource={} robustness={} revisions={} concessions={}",
        s.status_resource, s.robustness, s.revisions.len(), s.concessions.len()
    ));
    for (i, r) in s.revisions.iter().enumerate() {
        out.push(format!("revision[{}].note={}", i + 1, r.note));
        out.push(format!("revision[{}].previous_hash={}", i + 1, r.previous_hash));
    }
    for (i, c) in s.concessions.iter().enumerate() {
        out.push(format!("concession[{}].target={}", i + 1, c.target));
        out.push(format!("concession[{}].reason={}", i + 1, c.reason));
    }
    out.push("[TYPED]".into());
    out.push(project_state_text(s));
    out.push("[RUNTIME FOUNDATION]".into());
    out.push(runtime_state_text(&s.runtime));
    out.join("\n")
}

fn parse_binary(rest: &str) -> Result<(&str, &str), String> {
    let (a, b) = rest.split_once('|').ok_or_else(|| "НУЖЕН ВВОД: используйте форму <позиция-A> | <позиция-B>".to_string())?;
    let a = a.trim();
    let b = b.trim();
    if a.is_empty() || b.is_empty() { return Err("НУЖЕН ВВОД: обе части обязательны".into()); }
    Ok((a, b))
}

fn parse_bool(text: &str) -> Option<bool> {
    match text.trim().to_lowercase().as_str() {
        "true" | "1" | "yes" | "да" => Some(true),
        "false" | "0" | "no" | "нет" => Some(false),
        _ => None,
    }
}

fn definition_frame(name: &str) -> String {
    if name.eq_ignore_ascii_case("functional") {
        "communist-party:functional".into()
    } else {
        name.to_string()
    }
}

fn find_definition<'a>(s: &'a ModelState, name: &str) -> Option<&'a DefinitionRecord> {
    s.definitions.iter().rev().find(|d| d.name.eq_ignore_ascii_case(name))
}

fn find_binding<'a>(s: &'a ModelState, relation: &str) -> Option<&'a BindingRecord> {
    s.bindings.iter().rev().find(|b| b.relation.eq_ignore_ascii_case(relation))
}

fn port(
    id: &str,
    name: &str,
    direction: PortDirection,
    event_type: &str,
    cardinality: PortCardinality,
) -> PortSpec {
    PortSpec {
        id: id.into(),
        name: name.into(),
        direction,
        event_type: event_type.into(),
        cardinality,
    }
}


fn node_template(node_type: &str, id: &str) -> Option<NodeSpec> {
    let canonical = match node_type.trim().to_ascii_lowercase().as_str() {
        "semanticcheck" | "semantic" => "SemanticCheck",
        "countercheck" | "counter" => "CounterCheck",
        "compare" | "join" => "Compare",
        "revision" | "revise" => "Revision",
        "commit" => "Commit",
        _ => return None,
    };
    let (label, implementation_version, ports) = match canonical {
        "SemanticCheck" => (
            "Semantic Check",
            1,
            vec![
                port("in-claim", "claim", PortDirection::Input, "ClaimEvent", PortCardinality::One),
                port("out-result", "result", PortDirection::Output, "CheckResult", PortCardinality::One),
            ],
        ),
        "CounterCheck" => (
            "Counter Check",
            1,
            vec![
                port("in-claim", "claim", PortDirection::Input, "ClaimEvent", PortCardinality::One),
                port("out-result", "result", PortDirection::Output, "CheckResult", PortCardinality::One),
            ],
        ),
        "Compare" => (
            "Compare / Join",
            2,
            vec![
                port("in-semantic", "semantic", PortDirection::Input, "CheckResult", PortCardinality::One),
                port("in-counter", "counter", PortDirection::Input, "CheckResult", PortCardinality::One),
                port("out-conflict", "conflict", PortDirection::Output, "ConflictEvent", PortCardinality::One),
                port("out-stable", "stable", PortDirection::Output, "StableEvent", PortCardinality::One),
            ],
        ),
        "Revision" => (
            "Revision",
            1,
            vec![
                port("in-conflict", "conflict", PortDirection::Input, "ConflictEvent", PortCardinality::One),
                port("out-revised", "revised", PortDirection::Output, "ClaimEvent", PortCardinality::One),
            ],
        ),
        "Commit" => (
            "Commit",
            1,
            vec![port("in-stable", "stable", PortDirection::Input, "StableEvent", PortCardinality::One)],
        ),
        _ => return None,
    };
    Some(NodeSpec {
        id: id.to_string(),
        node_type: canonical.to_string(),
        label: label.to_string(),
        implementation_version,
        ports,
    })
}

fn topology_edit_allowed(runtime: &RuntimeState) -> bool {
    runtime.work_items.is_empty()
        && runtime.input_frames.is_empty()
        && runtime.events.iter().all(|e| e.kind.starts_with("Graph"))
}

fn layout_for<'a>(graph: &'a GraphState, node_id: &str) -> Option<&'a NodeLayout> {
    graph.layout.iter().find(|l| l.node_id == node_id)
}

fn set_node_layout(graph: &mut GraphState, node_id: &str, x: f32, y: f32) -> bool {
    if !graph.nodes.iter().any(|n| n.id == node_id) { return false; }
    if let Some(layout) = graph.layout.iter_mut().find(|l| l.node_id == node_id) {
        layout.x = x;
        layout.y = y;
    } else {
        graph.layout.push(NodeLayout { node_id: node_id.to_string(), x, y });
    }
    true
}

fn next_user_node_id(graph: &GraphState) -> String {
    let mut n = graph.revision.saturating_add(1).max(1);
    loop {
        let id = format!("n-user-{}", n);
        if !graph.nodes.iter().any(|node| node.id == id) { return id; }
        n = n.saturating_add(1);
    }
}

fn graph_add_node(runtime: &mut RuntimeState, node_type: &str) -> String {
    if !runtime.active { return "ОШИБКА: runtime не инициализирован".into(); }
    if !topology_edit_allowed(runtime) {
        return "ОШИБКА: topology lock после начала исполнения; runtime reset/init перед структурным редактированием".into();
    }
    let id = next_user_node_id(&runtime.graph);
    let node = match node_template(node_type, &id) {
        Some(v) => v,
        None => return "ОШИБКА: тип узла: SemanticCheck | CounterCheck | Compare | Revision | Commit".into(),
    };
    let canonical_type = node.node_type.clone();
    runtime.graph.nodes.push(node);
    let x = 40.0 + ((runtime.graph.nodes.len() as f32 * 37.0) % 260.0);
    let y = 620.0 + ((runtime.graph.nodes.len() as f32 * 29.0) % 160.0);
    runtime.graph.layout.push(NodeLayout { node_id: id.clone(), x, y });
    runtime.graph.revision = runtime.graph.revision.saturating_add(1);
    let payload = serde_json::json!({"node_id":id.clone(),"node_type":canonical_type.clone(),"graph_revision":runtime.graph.revision}).to_string();
    let ev = append_runtime_event(runtime, "GraphNodeAdded", payload, None, None, None);
    format!("OK node added: {} type={} graph_revision={} audit_event={}", id, canonical_type, runtime.graph.revision, ev.event_id)
}

fn graph_add_edge(runtime: &mut RuntimeState, from_node: &str, from_port: &str, to_node: &str, to_port: &str) -> String {
    if !runtime.active { return "ОШИБКА: runtime не инициализирован".into(); }
    if !topology_edit_allowed(runtime) {
        return "ОШИБКА: topology lock после начала исполнения; runtime reset/init перед структурным редактированием".into();
    }
    let source = match find_node(&runtime.graph, from_node) { Some(v) => v, None => return format!("ОШИБКА: node {} не найден", from_node) };
    let target = match find_node(&runtime.graph, to_node) { Some(v) => v, None => return format!("ОШИБКА: node {} не найден", to_node) };
    let sp = match find_port(source, from_port) { Some(v) => v, None => return format!("ОШИБКА: port {}.{} не найден", from_node, from_port) };
    let tp = match find_port(target, to_port) { Some(v) => v, None => return format!("ОШИБКА: port {}.{} не найден", to_node, to_port) };
    if sp.direction != PortDirection::Output { return "ОШИБКА: первый порт должен быть Output".into(); }
    if tp.direction != PortDirection::Input { return "ОШИБКА: второй порт должен быть Input".into(); }
    if sp.event_type != tp.event_type {
        return format!("TYPE MISMATCH: {} != {}", sp.event_type, tp.event_type);
    }
    if tp.cardinality == PortCardinality::One && runtime.graph.edges.iter().any(|e| e.to_node == to_node && e.to_port == to_port) {
        return format!("CARDINALITY: {}.{} уже имеет incoming Edge", to_node, to_port);
    }
    if runtime.graph.edges.iter().any(|e| e.from_node == from_node && e.from_port == from_port && e.to_node == to_node && e.to_port == to_port) {
        return "ОШИБКА: такая связь уже существует".into();
    }
    let event_type = sp.event_type.clone();
    let edge_id = format!("e-user-{}", runtime.graph.revision.saturating_add(1));
    runtime.graph.edges.push(EdgeSpec {
        id: edge_id.clone(),
        from_node: from_node.to_string(),
        from_port: from_port.to_string(),
        to_node: to_node.to_string(),
        to_port: to_port.to_string(),
        event_type: event_type.clone(),
    });
    runtime.graph.revision = runtime.graph.revision.saturating_add(1);
    let payload = serde_json::json!({
        "edge_id":edge_id.clone(),"from_node":from_node,"from_port":from_port,"to_node":to_node,"to_port":to_port,
        "event_type":event_type.clone(),"graph_revision":runtime.graph.revision
    }).to_string();
    let ev = append_runtime_event(runtime, "GraphEdgeAdded", payload, None, None, None);
    format!("OK edge added: {} {}.{} -> {}.{} type={} graph_revision={} audit_event={}", edge_id, from_node, from_port, to_node, to_port, event_type, runtime.graph.revision, ev.event_id)
}

fn graph_remove_edge(runtime: &mut RuntimeState, edge_id: &str) -> String {
    if !topology_edit_allowed(runtime) {
        return "ОШИБКА: topology lock после начала исполнения; runtime reset/init перед структурным редактированием".into();
    }
    let before = runtime.graph.edges.len();
    runtime.graph.edges.retain(|e| e.id != edge_id);
    if runtime.graph.edges.len() == before { return format!("ОШИБКА: edge {} не найден", edge_id); }
    runtime.graph.revision = runtime.graph.revision.saturating_add(1);
    let payload = serde_json::json!({"edge_id":edge_id,"graph_revision":runtime.graph.revision}).to_string();
    let ev = append_runtime_event(runtime, "GraphEdgeRemoved", payload, None, None, None);
    format!("OK edge removed: {} graph_revision={} audit_event={}", edge_id, runtime.graph.revision, ev.event_id)
}

fn graph_remove_node(runtime: &mut RuntimeState, node_id: &str) -> String {
    if !topology_edit_allowed(runtime) {
        return "ОШИБКА: topology lock после начала исполнения; runtime reset/init перед структурным редактированием".into();
    }
    if !node_id.starts_with("n-user-") {
        return "ОШИБКА: v01 удаляет только пользовательские n-user-* узлы; demo-узлы защищены".into();
    }
    let before = runtime.graph.nodes.len();
    runtime.graph.nodes.retain(|n| n.id != node_id);
    if runtime.graph.nodes.len() == before { return format!("ОШИБКА: node {} не найден", node_id); }
    let removed_edges = runtime.graph.edges.iter().filter(|e| e.from_node == node_id || e.to_node == node_id).count();
    runtime.graph.edges.retain(|e| e.from_node != node_id && e.to_node != node_id);
    runtime.graph.layout.retain(|l| l.node_id != node_id);
    runtime.graph.revision = runtime.graph.revision.saturating_add(1);
    let payload = serde_json::json!({"node_id":node_id,"removed_edges":removed_edges,"graph_revision":runtime.graph.revision}).to_string();
    let ev = append_runtime_event(runtime, "GraphNodeRemoved", payload, None, None, None);
    format!("OK node removed: {} edges_removed={} graph_revision={} audit_event={}", node_id, removed_edges, runtime.graph.revision, ev.event_id)
}

fn demo_runtime_state() -> RuntimeState {
    let input = NodeSpec {
        id: "n-input".into(),
        node_type: "Input".into(),
        label: "Claim Input".into(),
        implementation_version: 1,
        ports: vec![port("out-claim", "claim", PortDirection::Output, "ClaimEvent", PortCardinality::One)],
    };
    let semantic = NodeSpec {
        id: "n-semantic".into(),
        node_type: "SemanticCheck".into(),
        label: "Semantic Check".into(),
        implementation_version: 1,
        ports: vec![
            port("in-claim", "claim", PortDirection::Input, "ClaimEvent", PortCardinality::One),
            port("out-result", "result", PortDirection::Output, "CheckResult", PortCardinality::One),
        ],
    };
    let counter = NodeSpec {
        id: "n-counter".into(),
        node_type: "CounterCheck".into(),
        label: "Counter Check".into(),
        implementation_version: 1,
        ports: vec![
            port("in-claim", "claim", PortDirection::Input, "ClaimEvent", PortCardinality::One),
            port("out-result", "result", PortDirection::Output, "CheckResult", PortCardinality::One),
        ],
    };
    let compare = NodeSpec {
        id: "n-compare".into(),
        node_type: "Compare".into(),
        label: "Compare / Join".into(),
        implementation_version: 2,
        ports: vec![
            port("in-semantic", "semantic", PortDirection::Input, "CheckResult", PortCardinality::One),
            port("in-counter", "counter", PortDirection::Input, "CheckResult", PortCardinality::One),
            port("out-conflict", "conflict", PortDirection::Output, "ConflictEvent", PortCardinality::One),
            port("out-stable", "stable", PortDirection::Output, "StableEvent", PortCardinality::One),
        ],
    };
    let revision = NodeSpec {
        id: "n-revision".into(),
        node_type: "Revision".into(),
        label: "Revision".into(),
        implementation_version: 1,
        ports: vec![
            port("in-conflict", "conflict", PortDirection::Input, "ConflictEvent", PortCardinality::One),
            port("out-revised", "revised", PortDirection::Output, "ClaimEvent", PortCardinality::One),
        ],
    };
    let commit = NodeSpec {
        id: "n-commit".into(),
        node_type: "Commit".into(),
        label: "Commit".into(),
        implementation_version: 1,
        ports: vec![port("in-stable", "stable", PortDirection::Input, "StableEvent", PortCardinality::One)],
    };
    let graph = GraphState {
        graph_id: "demo-resource-graph".into(),
        revision: 3,
        nodes: vec![input, semantic, counter, compare, revision, commit],
        edges: vec![
            EdgeSpec { id: "e-input-semantic".into(), from_node: "n-input".into(), from_port: "out-claim".into(), to_node: "n-semantic".into(), to_port: "in-claim".into(), event_type: "ClaimEvent".into() },
            EdgeSpec { id: "e-input-counter".into(), from_node: "n-input".into(), from_port: "out-claim".into(), to_node: "n-counter".into(), to_port: "in-claim".into(), event_type: "ClaimEvent".into() },
            EdgeSpec { id: "e-semantic-compare".into(), from_node: "n-semantic".into(), from_port: "out-result".into(), to_node: "n-compare".into(), to_port: "in-semantic".into(), event_type: "CheckResult".into() },
            EdgeSpec { id: "e-counter-compare".into(), from_node: "n-counter".into(), from_port: "out-result".into(), to_node: "n-compare".into(), to_port: "in-counter".into(), event_type: "CheckResult".into() },
            EdgeSpec { id: "e-compare-revision".into(), from_node: "n-compare".into(), from_port: "out-conflict".into(), to_node: "n-revision".into(), to_port: "in-conflict".into(), event_type: "ConflictEvent".into() },
            EdgeSpec { id: "e-revision-semantic".into(), from_node: "n-revision".into(), from_port: "out-revised".into(), to_node: "n-semantic".into(), to_port: "in-claim".into(), event_type: "ClaimEvent".into() },
            EdgeSpec { id: "e-revision-counter".into(), from_node: "n-revision".into(), from_port: "out-revised".into(), to_node: "n-counter".into(), to_port: "in-claim".into(), event_type: "ClaimEvent".into() },
            EdgeSpec { id: "e-compare-commit".into(), from_node: "n-compare".into(), from_port: "out-stable".into(), to_node: "n-commit".into(), to_port: "in-stable".into(), event_type: "StableEvent".into() },
        ],
        layout: vec![
            NodeLayout { node_id: "n-input".into(), x: 120.0, y: 30.0 },
            NodeLayout { node_id: "n-semantic".into(), x: 25.0, y: 180.0 },
            NodeLayout { node_id: "n-counter".into(), x: 215.0, y: 180.0 },
            NodeLayout { node_id: "n-compare".into(), x: 120.0, y: 330.0 },
            NodeLayout { node_id: "n-revision".into(), x: 25.0, y: 480.0 },
            NodeLayout { node_id: "n-commit".into(), x: 215.0, y: 480.0 },
        ],
    };
    RuntimeState {
        active: true,
        graph,
        events: Vec::new(),
        input_frames: Vec::new(),
        work_items: Vec::new(),
        branch_id: "root".into(),
        correlation_id: "analysis-0".into(),
        iteration: 0,
        next_seq: 1,
        resource: ResourceState::default(),
        stop_reason: None,
    }
}

fn find_node<'a>(graph: &'a GraphState, id: &str) -> Option<&'a NodeSpec> {
    graph.nodes.iter().find(|node| node.id == id)
}

fn find_port<'a>(node: &'a NodeSpec, id: &str) -> Option<&'a PortSpec> {
    node.ports.iter().find(|port| port.id == id)
}

fn validate_graph(graph: &GraphState) -> Vec<String> {
    let mut errors = Vec::new();
    if graph.graph_id.trim().is_empty() {
        errors.push("graph_id пуст".into());
    }

    let mut node_ids: HashSet<&str> = HashSet::new();
    for node in &graph.nodes {
        if !node_ids.insert(node.id.as_str()) {
            errors.push(format!("duplicate node id: {}", node.id));
        }
        let mut port_ids: HashSet<&str> = HashSet::new();
        for port in &node.ports {
            if !port_ids.insert(port.id.as_str()) {
                errors.push(format!("duplicate port id in {}: {}", node.id, port.id));
            }
        }
    }

    let mut edge_ids: HashSet<&str> = HashSet::new();
    for edge in &graph.edges {
        if !edge_ids.insert(edge.id.as_str()) {
            errors.push(format!("duplicate edge id: {}", edge.id));
        }

        let from_node = match find_node(graph, &edge.from_node) {
            Some(node) => node,
            None => {
                errors.push(format!("edge {}: missing from_node {}", edge.id, edge.from_node));
                continue;
            }
        };
        let to_node = match find_node(graph, &edge.to_node) {
            Some(node) => node,
            None => {
                errors.push(format!("edge {}: missing to_node {}", edge.id, edge.to_node));
                continue;
            }
        };
        let from_port = match find_port(from_node, &edge.from_port) {
            Some(port) => port,
            None => {
                errors.push(format!("edge {}: missing output port {}.{}", edge.id, edge.from_node, edge.from_port));
                continue;
            }
        };
        let to_port = match find_port(to_node, &edge.to_port) {
            Some(port) => port,
            None => {
                errors.push(format!("edge {}: missing input port {}.{}", edge.id, edge.to_node, edge.to_port));
                continue;
            }
        };
        if from_port.direction != PortDirection::Output {
            errors.push(format!("edge {}: source port is not Output", edge.id));
        }
        if to_port.direction != PortDirection::Input {
            errors.push(format!("edge {}: target port is not Input", edge.id));
        }
        if from_port.event_type != edge.event_type {
            errors.push(format!(
                "edge {}: source type {} != edge type {}",
                edge.id, from_port.event_type, edge.event_type
            ));
        }
        if to_port.event_type != edge.event_type {
            errors.push(format!(
                "edge {}: target type {} != edge type {}",
                edge.id, to_port.event_type, edge.event_type
            ));
        }
    }
    errors
}


fn append_runtime_event(
    runtime: &mut RuntimeState,
    kind: &str,
    payload_json: String,
    source_node: Option<&str>,
    source_port: Option<&str>,
    parent_event_id: Option<String>,
) -> EventRecord {
    let seq = runtime.next_seq;
    runtime.next_seq = runtime.next_seq.saturating_add(1);
    let previous_hash = runtime.events.last().map(|e| e.event_hash.clone()).unwrap_or_else(|| "GENESIS".into());
    let event_id = format!("ev-{}", seq);
    let graph_id = runtime.graph.graph_id.clone();
    let material = format!(
        "1|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}",
        graph_id, seq, event_id, kind, payload_json,
        source_node.unwrap_or(""), source_port.unwrap_or(""), parent_event_id.as_deref().unwrap_or(""),
        runtime.branch_id, runtime.correlation_id, runtime.iteration
    );
    let event_hash = format!("{:016x}", fnv1a64(format!("{}|{}", previous_hash, material).as_bytes()));
    let event = EventRecord {
        schema_version: 1,
        graph_id,
        seq,
        event_id,
        kind: kind.into(),
        payload_json,
        source_node: source_node.map(|v| v.to_string()),
        source_port: source_port.map(|v| v.to_string()),
        branch_id: runtime.branch_id.clone(),
        correlation_id: runtime.correlation_id.clone(),
        iteration: runtime.iteration,
        parent_event_id,
        previous_hash,
        event_hash,
    };
    runtime.events.push(event.clone());
    event
}

fn event_by_id<'a>(runtime: &'a RuntimeState, id: &str) -> Option<&'a EventRecord> {
    runtime.events.iter().find(|event| event.event_id == id)
}

fn required_input_ports(graph: &GraphState, node_id: &str) -> Vec<String> {
    match find_node(graph, node_id) {
        Some(node) => node.ports.iter()
            .filter(|p| p.direction == PortDirection::Input && p.cardinality != PortCardinality::Optional)
            .map(|p| p.id.clone())
            .collect(),
        None => Vec::new(),
    }
}


fn node_estimated_cost(node_type: &str) -> u32 {
    match node_type {
        "SemanticCheck" => 2,
        "CounterCheck" => 3,
        "Compare" => 1,
        "Revision" => 4,
        "Commit" => 1,
        _ => 1,
    }
}

fn node_priority(node_type: &str) -> i32 {
    match node_type {
        "Commit" => 100,
        "Revision" => 50,
        "Compare" => 20,
        "SemanticCheck" => 10,
        "CounterCheck" => 10,
        _ => 0,
    }
}

fn total_spent(runtime: &RuntimeState) -> u32 {
    runtime.resource.ledger.iter().map(|e| e.cost).sum()
}

fn branch_spent(runtime: &RuntimeState, branch_id: &str) -> u32 {
    runtime.resource.ledger.iter()
        .filter(|e| e.branch_id == branch_id)
        .map(|e| e.cost)
        .sum()
}

fn iteration_spent(runtime: &RuntimeState, branch_id: &str, iteration: u32) -> u32 {
    runtime.resource.ledger.iter()
        .filter(|e| e.branch_id == branch_id && e.iteration == iteration)
        .map(|e| e.cost)
        .sum()
}

fn effective_remaining(runtime: &RuntimeState, branch_id: &str, iteration: u32) -> u32 {
    let total_remaining = runtime.resource.policy.total_budget.saturating_sub(total_spent(runtime));
    let branch_remaining = runtime.resource.policy.branch_cap.saturating_sub(branch_spent(runtime, branch_id));
    let iteration_remaining = runtime.resource.policy.iteration_budget_cap.saturating_sub(iteration_spent(runtime, branch_id, iteration));
    total_remaining.min(branch_remaining).min(iteration_remaining)
}

fn append_resource_spent(runtime: &mut RuntimeState, work: &WorkItem, node: &NodeSpec, cost: u32) -> EventRecord {
    let id = format!("res-{}", runtime.resource.ledger.len() + 1);
    runtime.resource.ledger.push(ResourceLedgerEntry {
        id: id.clone(),
        work_id: work.id.clone(),
        node_id: node.id.clone(),
        branch_id: runtime.branch_id.clone(),
        iteration: work.iteration,
        operation: node.node_type.clone(),
        cost,
    });

    let payload = serde_json::json!({
        "entry": id,
        "work_id": work.id.clone(),
        "node_id": node.id.clone(),
        "operation": node.node_type.clone(),
        "cost": cost,
        "iteration": work.iteration,
        "spent_total": total_spent(runtime),
        "remaining_total": runtime.resource.policy.total_budget.saturating_sub(total_spent(runtime))
    }).to_string();

    let seq = runtime.next_seq;
    runtime.next_seq = runtime.next_seq.saturating_add(1);
    let previous_hash = runtime.events.last().map(|e| e.event_hash.clone()).unwrap_or_else(|| "GENESIS".into());
    let event_id = format!("ev-{}", seq);
    let graph_id = runtime.graph.graph_id.clone();
    let material = format!(
        "1|{}|{}|{}|ResourceSpent|{}|{}|||{}|{}|{}",
        graph_id, seq, event_id, payload, node.id, runtime.branch_id, runtime.correlation_id, work.iteration
    );
    let event_hash = format!("{:016x}", fnv1a64(format!("{}|{}", previous_hash, material).as_bytes()));
    let event = EventRecord {
        schema_version: 1,
        graph_id,
        seq,
        event_id,
        kind: "ResourceSpent".into(),
        payload_json: payload,
        source_node: Some(node.id.clone()),
        source_port: None,
        branch_id: runtime.branch_id.clone(),
        correlation_id: runtime.correlation_id.clone(),
        iteration: work.iteration,
        parent_event_id: None,
        previous_hash,
        event_hash,
    };
    runtime.events.push(event.clone());
    event
}

fn suspend_unaffordable_work(runtime: &mut RuntimeState) -> usize {
    let mut count = 0usize;
    for i in 0..runtime.work_items.len() {
        if runtime.work_items[i].status != WorkStatus::Queued {
            continue;
        }
        let remaining = effective_remaining(runtime, &runtime.branch_id, runtime.work_items[i].iteration);
        if runtime.work_items[i].estimated_cost > remaining {
            runtime.work_items[i].status = WorkStatus::Suspended;
            runtime.work_items[i].suspend_reason = Some(format!(
                "ResourceInsufficient: need={} remaining={}",
                runtime.work_items[i].estimated_cost, remaining
            ));
            count += 1;
        }
    }
    if count > 0 {
        let first_stop = runtime.stop_reason.as_deref() != Some("ResourceExhausted");
        runtime.stop_reason = Some("ResourceExhausted".into());
        if first_stop {
            let payload = serde_json::json!({
                "reason":"ResourceExhausted",
                "suspended":count,
                "spent":total_spent(runtime),
                "remaining":runtime.resource.policy.total_budget.saturating_sub(total_spent(runtime)),
                "iteration":runtime.iteration
            }).to_string();
            let _ = append_runtime_event(runtime, "BranchSuspended", payload, None, None, None);
        }
    }
    count
}

fn select_runnable_work_idx(runtime: &RuntimeState) -> Option<usize> {
    runtime.work_items.iter().enumerate()
        .filter(|(_, w)| {
            w.status == WorkStatus::Queued &&
            w.estimated_cost <= effective_remaining(runtime, &runtime.branch_id, w.iteration)
        })
        .max_by(|(ia, a), (ib, b)| {
            a.priority.cmp(&b.priority).then_with(|| ib.cmp(ia))
        })
        .map(|(i, _)| i)
}

fn route_event(runtime: &mut RuntimeState, event: &EventRecord) -> (usize, usize) {
    let source_node = match event.source_node.as_deref() { Some(v) => v, None => return (0, 0) };
    let source_port = match event.source_port.as_deref() { Some(v) => v, None => return (0, 0) };
    let edges: Vec<EdgeSpec> = runtime.graph.edges.iter()
        .filter(|edge| edge.from_node == source_node && edge.from_port == source_port && edge.event_type == event.kind)
        .cloned()
        .collect();
    let mut routed = 0usize;
    let mut queued = 0usize;

    for edge in edges {
        routed += 1;
        let required = required_input_ports(&runtime.graph, &edge.to_node);
        let frame_idx = match runtime.input_frames.iter().position(|frame|
            frame.node_id == edge.to_node &&
            frame.branch_id == event.branch_id &&
            frame.correlation_id == event.correlation_id &&
            frame.iteration == event.iteration &&
            !frame.ready
        ) {
            Some(i) => i,
            None => {
                let id = format!("frame-{}", runtime.input_frames.len() + 1);
                runtime.input_frames.push(InputFrame {
                    id,
                    node_id: edge.to_node.clone(),
                    branch_id: event.branch_id.clone(),
                    correlation_id: event.correlation_id.clone(),
                    iteration: event.iteration,
                    bindings: Vec::new(),
                    ready: false,
                });
                runtime.input_frames.len() - 1
            }
        };

        let mut became_ready = false;
        let mut input_ids = Vec::new();
        let frame_id;
        {
            let frame = &mut runtime.input_frames[frame_idx];
            frame_id = frame.id.clone();
            if !frame.bindings.iter().any(|b| b.port_id == edge.to_port) {
                frame.bindings.push(InputBinding { port_id: edge.to_port.clone(), event_id: event.event_id.clone() });
            }
            let ready_now = required.iter().all(|port_id| frame.bindings.iter().any(|b| &b.port_id == port_id));
            if ready_now && !frame.ready {
                frame.ready = true;
                became_ready = true;
                input_ids = frame.bindings.iter().map(|b| b.event_id.clone()).collect();
            }
        }
        if became_ready {
            let node_type = find_node(&runtime.graph, &edge.to_node)
                .map(|n| n.node_type.as_str())
                .unwrap_or("");
            runtime.work_items.push(WorkItem {
                id: format!("work-{}", runtime.work_items.len() + 1),
                node_id: edge.to_node.clone(),
                input_event_ids: input_ids,
                iteration: event.iteration,
                priority: node_priority(node_type),
                budget: runtime.resource.policy.total_budget,
                estimated_cost: node_estimated_cost(node_type),
                actual_cost: None,
                status: WorkStatus::Queued,
                attempts: 0,
                suspend_reason: None,
            });
            queued += 1;
            let _ = frame_id;
        }
    }
    (routed, queued)
}

fn runtime_queue_text(runtime: &RuntimeState) -> String {
    let mut out = Vec::new();
    let spent = total_spent(runtime);
    let remaining = runtime.resource.policy.total_budget.saturating_sub(spent);
    out.push(format!(
        "queue: input_frames={} work_items={} spent={} remaining={} stop={}",
        runtime.input_frames.len(),
        runtime.work_items.len(),
        spent,
        remaining,
        runtime.stop_reason.as_deref().unwrap_or("<none>")
    ));
    for frame in &runtime.input_frames {
        let bindings = frame.bindings.iter()
            .map(|b| format!("{}={}", b.port_id, b.event_id))
            .collect::<Vec<_>>()
            .join(",");
        out.push(format!("frame {} node={} iter={} ready={} [{}]", frame.id, frame.node_id, frame.iteration, frame.ready, bindings));
    }
    for work in &runtime.work_items {
        out.push(format!(
            "work {} node={} iter={} status={:?} priority={} est_cost={} actual={} attempts={} inputs=[{}]{}",
            work.id,
            work.node_id,
            work.iteration,
            work.status,
            work.priority,
            work.estimated_cost,
            work.actual_cost.map(|v| v.to_string()).unwrap_or_else(|| "-".into()),
            work.attempts,
            work.input_event_ids.join(","),
            work.suspend_reason.as_ref().map(|r| format!(" reason={}", r)).unwrap_or_default()
        ));
    }
    out.join("\n")
}

fn runtime_events_text(runtime: &RuntimeState) -> String {
    if runtime.events.is_empty() { return "events=0".into(); }
    let mut out = vec![format!("events={}", runtime.events.len())];
    for event in &runtime.events {
        out.push(format!(
            "#{} {} kind={} branch={} iter={} source={}.{} parent={} hash={} payload={}",
            event.seq,
            event.event_id,
            event.kind,
            event.branch_id,
            event.iteration,
            event.source_node.as_deref().unwrap_or("<external>"),
            event.source_port.as_deref().unwrap_or("<none>"),
            event.parent_event_id.as_deref().unwrap_or("<none>"),
            event.event_hash,
            event.payload_json
        ));
    }
    out.join("\n")
}

fn payload_claim(event: &EventRecord) -> String {
    serde_json::from_str::<serde_json::Value>(&event.payload_json)
        .ok()
        .and_then(|v| v.get("claim").and_then(|x| x.as_str()).map(|x| x.to_string()))
        .unwrap_or_else(|| event.payload_json.clone())
}

fn execute_one_runtime_work(runtime: &mut RuntimeState) -> String {
    if runtime.stop_reason.as_deref() == Some("Committed") {
        return "STOP: branch already committed".into();
    }

    let work_idx = match select_runnable_work_idx(runtime) {
        Some(i) => i,
        None => {
            let suspended = suspend_unaffordable_work(runtime);
            if suspended > 0 {
                return format!(
                    "STOP ResourceExhausted: suspended={} spent={} remaining={}",
                    suspended,
                    total_spent(runtime),
                    runtime.resource.policy.total_budget.saturating_sub(total_spent(runtime))
                );
            }
            return "QUEUE EMPTY: нет runnable WorkItem".into();
        }
    };

    runtime.work_items[work_idx].status = WorkStatus::Running;
    runtime.work_items[work_idx].attempts = runtime.work_items[work_idx].attempts.saturating_add(1);
    let work = runtime.work_items[work_idx].clone();
    let node = match find_node(&runtime.graph, &work.node_id).cloned() {
        Some(n) => n,
        None => {
            runtime.work_items[work_idx].status = WorkStatus::Rejected;
            return format!("REJECTED {}: node {} missing", work.id, work.node_id);
        }
    };

    let cost = work.estimated_cost.max(1);
    let mut emitted: Option<EventRecord> = None;
    let detail: String;

    match node.node_type.as_str() {
        "SemanticCheck" => {
            let input = work.input_event_ids.first().and_then(|id| event_by_id(runtime, id));
            let claim = input.map(payload_claim).unwrap_or_else(|| "<missing>".into());
            let parent = input.map(|e| e.event_id.clone());
            let payload = serde_json::json!({
                "check":"semantic",
                "outcome":"Support",
                "claim":claim,
                "iteration":work.iteration
            }).to_string();
            let event = append_runtime_event(runtime, "CheckResult", payload, Some(&node.id), Some("out-result"), parent);
            detail = "SemanticCheck -> Support".into();
            emitted = Some(event);
        }
        "CounterCheck" => {
            let input = work.input_event_ids.first().and_then(|id| event_by_id(runtime, id));
            let claim = input.map(payload_claim).unwrap_or_else(|| "<missing>".into());
            let parent = input.map(|e| e.event_id.clone());
            let outcome = if work.iteration == 0 { "Conflict" } else { "Support" };
            let payload = serde_json::json!({
                "check":"counter",
                "outcome":outcome,
                "claim":claim,
                "iteration":work.iteration
            }).to_string();
            let event = append_runtime_event(runtime, "CheckResult", payload, Some(&node.id), Some("out-result"), parent);
            detail = format!("CounterCheck -> {}", outcome);
            emitted = Some(event);
        }
        "Compare" => {
            let mut semantic = "<missing>".to_string();
            let mut counter = "<missing>".to_string();
            let mut claim = "<missing>".to_string();

            for id in &work.input_event_ids {
                if let Some(event) = event_by_id(runtime, id) {
                    if let Ok(v) = serde_json::from_str::<serde_json::Value>(&event.payload_json) {
                        let check = v.get("check").and_then(|x| x.as_str()).unwrap_or("");
                        let outcome = v.get("outcome").and_then(|x| x.as_str()).unwrap_or("<unknown>");
                        if let Some(c) = v.get("claim").and_then(|x| x.as_str()) {
                            claim = c.to_string();
                        }
                        if check == "semantic" { semantic = outcome.to_string(); }
                        if check == "counter" { counter = outcome.to_string(); }
                    }
                }
            }

            let overall = if semantic == "Conflict" || counter == "Conflict" { "Conflict" } else { "Stable" };
            let payload = serde_json::json!({
                "semantic":semantic,
                "counter":counter,
                "outcome":overall,
                "claim":claim,
                "iteration":work.iteration
            }).to_string();
            let parent = work.input_event_ids.last().cloned();

            if overall == "Conflict" {
                let event = append_runtime_event(runtime, "ConflictEvent", payload, Some(&node.id), Some("out-conflict"), parent);
                detail = "Compare -> Conflict".into();
                emitted = Some(event);
            } else {
                let event = append_runtime_event(runtime, "StableEvent", payload, Some(&node.id), Some("out-stable"), parent);
                detail = "Compare -> Stable".into();
                emitted = Some(event);
            }
        }
        "Revision" => {
            let input = work.input_event_ids.first().and_then(|id| event_by_id(runtime, id));
            let claim = input.map(payload_claim).unwrap_or_else(|| "<missing>".into());
            let parent = input.map(|e| e.event_id.clone());
            let next_iteration = work.iteration.saturating_add(1);

            if next_iteration > runtime.resource.policy.max_iterations {
                runtime.stop_reason = Some("IterationLimit".into());
                let payload = serde_json::json!({
                    "reason":"IterationLimit",
                    "iteration":work.iteration,
                    "max_iterations":runtime.resource.policy.max_iterations
                }).to_string();
                let _ = append_runtime_event(runtime, "AnalysisStopped", payload, Some(&node.id), None, parent);
                detail = format!(
                    "Revision blocked: iteration limit {}",
                    runtime.resource.policy.max_iterations
                );
            } else {
                runtime.iteration = next_iteration;
                let revised_claim = format!("{} [revision:{}]", claim, next_iteration);
                let payload = serde_json::json!({
                    "claim":revised_claim,
                    "revision_of":claim,
                    "iteration":next_iteration
                }).to_string();
                let event = append_runtime_event(runtime, "ClaimEvent", payload, Some(&node.id), Some("out-revised"), parent);
                detail = format!("Revision -> iteration {}", next_iteration);
                emitted = Some(event);
            }
        }
        "Commit" => {
            let parent = work.input_event_ids.first().cloned();
            let payload = serde_json::json!({
                "branch":runtime.branch_id.clone(),
                "iteration":work.iteration,
                "reason":"Stable"
            }).to_string();
            let _ = append_runtime_event(runtime, "BranchCommitted", payload, Some(&node.id), None, parent);
            runtime.stop_reason = Some("Committed".into());
            detail = format!("Commit -> branch {} committed", runtime.branch_id);
        }
        _ => {
            if let Some(item) = runtime.work_items.iter_mut().find(|w| w.id == work.id) {
                item.status = WorkStatus::Rejected;
            }
            return format!("REJECTED {}: unsupported node_type={}", work.id, node.node_type);
        }
    }

    if let Some(item) = runtime.work_items.iter_mut().find(|w| w.id == work.id) {
        item.status = WorkStatus::Completed;
        item.actual_cost = Some(cost);
    }

    let resource_event = append_resource_spent(runtime, &work, &node, cost);

    let mut routed = 0usize;
    let mut queued = 0usize;
    let emitted_id = if let Some(event) = emitted.as_ref() {
        let id = event.event_id.clone();
        let result = route_event(runtime, event);
        routed = result.0;
        queued = result.1;
        id
    } else {
        "<none>".into()
    };

    let remaining = effective_remaining(runtime, &runtime.branch_id, runtime.iteration);
    format!(
        "STEP {} node={} COMPLETED\n{}\ncost={} resource_event={} spent_total={} remaining_effective={}\nemitted={} routed={} newly_queued={}",
        work.id,
        work.node_id,
        detail,
        cost,
        resource_event.event_id,
        total_spent(runtime),
        remaining,
        emitted_id,
        routed,
        queued
    )
}

fn runtime_state_text(runtime: &RuntimeState) -> String {
    if !runtime.active {
        return "runtime.active=false\nОжидаю: runtime init demo".into();
    }
    let mut out = Vec::new();
    let spent = total_spent(runtime);
    let remaining_total = runtime.resource.policy.total_budget.saturating_sub(spent);
    out.push(format!("runtime.active={}", runtime.active));
    out.push(format!(
        "graph={} revision={} nodes={} edges={}",
        runtime.graph.graph_id,
        runtime.graph.revision,
        runtime.graph.nodes.len(),
        runtime.graph.edges.len()
    ));
    out.push(format!(
        "branch={} correlation={} iteration={} next_seq={} stop={}",
        runtime.branch_id,
        runtime.correlation_id,
        runtime.iteration,
        runtime.next_seq,
        runtime.stop_reason.as_deref().unwrap_or("<none>")
    ));
    out.push(format!(
        "resource total={} spent={} remaining={} branch_cap={} iteration_budget_cap={} max_iterations={}",
        runtime.resource.policy.total_budget,
        spent,
        remaining_total,
        runtime.resource.policy.branch_cap,
        runtime.resource.policy.iteration_budget_cap,
        runtime.resource.policy.max_iterations
    ));
    out.push(format!(
        "events={} input_frames={} work_items={} ledger={}",
        runtime.events.len(),
        runtime.input_frames.len(),
        runtime.work_items.len(),
        runtime.resource.ledger.len()
    ));
    for node in &runtime.graph.nodes {
        out.push(format!(
            "node {} type={} impl=v{} label={} est_cost={} priority={}",
            node.id,
            node.node_type,
            node.implementation_version,
            node.label,
            node_estimated_cost(&node.node_type),
            node_priority(&node.node_type)
        ));
        for port in &node.ports {
            out.push(format!(
                "  port {} {:?} type={} cardinality={:?}",
                port.id, port.direction, port.event_type, port.cardinality
            ));
        }
    }
    for edge in &runtime.graph.edges {
        out.push(format!(
            "edge {} {}.{} -> {}.{} type={}",
            edge.id, edge.from_node, edge.from_port, edge.to_node, edge.to_port, edge.event_type
        ));
    }
    out.join("\n")
}

fn runtime_ledger_text(runtime: &RuntimeState) -> String {
    let mut out = Vec::new();
    out.push(format!(
        "resource total={} spent={} remaining={} branch_cap={} iteration_budget_cap={} max_iterations={} stop={}",
        runtime.resource.policy.total_budget,
        total_spent(runtime),
        runtime.resource.policy.total_budget.saturating_sub(total_spent(runtime)),
        runtime.resource.policy.branch_cap,
        runtime.resource.policy.iteration_budget_cap,
        runtime.resource.policy.max_iterations,
        runtime.stop_reason.as_deref().unwrap_or("<none>")
    ));
    if runtime.resource.ledger.is_empty() {
        out.push("ledger=0".into());
        return out.join("\n");
    }
    out.push(format!("ledger={}", runtime.resource.ledger.len()));
    for entry in &runtime.resource.ledger {
        out.push(format!(
            "{} work={} node={} branch={} iter={} op={} cost={}",
            entry.id,
            entry.work_id,
            entry.node_id,
            entry.branch_id,
            entry.iteration,
            entry.operation,
            entry.cost
        ));
    }
    out.join("\n")
}

fn execute_runtime_run(runtime: &mut RuntimeState, max_steps: usize) -> String {
    let mut out = Vec::new();
    let mut executed = 0usize;
    for _ in 0..max_steps {
        if runtime.stop_reason.as_deref() == Some("Committed") {
            break;
        }
        if select_runnable_work_idx(runtime).is_none() {
            let suspended = suspend_unaffordable_work(runtime);
            if suspended > 0 {
                out.push(format!(
                    "STOP ResourceExhausted: suspended={} spent={} remaining={}",
                    suspended,
                    total_spent(runtime),
                    runtime.resource.policy.total_budget.saturating_sub(total_spent(runtime))
                ));
            }
            break;
        }
        let line = execute_one_runtime_work(runtime);
        executed += 1;
        out.push(line);
        if runtime.stop_reason.is_some() {
            break;
        }
    }
    if executed == max_steps && runtime.stop_reason.is_none() && select_runnable_work_idx(runtime).is_some() {
        runtime.stop_reason = Some("RunStepLimit".into());
        out.push(format!("STOP RunStepLimit: max_steps={}", max_steps));
    }
    out.push(format!(
        "RUN SUMMARY steps={} spent={} remaining={} iteration={} stop={}",
        executed,
        total_spent(runtime),
        runtime.resource.policy.total_budget.saturating_sub(total_spent(runtime)),
        runtime.iteration,
        runtime.stop_reason.as_deref().unwrap_or("<none>")
    ));
    out.join("\n")
}

fn reset_dispute(s: &mut ModelState) {
    s.debate_name = None;
    s.resolution = None;
    s.collision_a = None;
    s.collision_b = None;
    s.function_context = None;
    s.criterion = None;
    s.committed = false;
    s.step = 0;
    s.status_resource = 100;
    s.robustness = 100;
    s.revisions.clear();
    s.concessions.clear();
}

fn command_impl(input: &str) -> String {
    let cmd = input.trim();
    let lc = cmd.to_lowercase();

    if lc == "help" || lc == "помощь" { return help_text(); }
    if lc == "system version" || lc == "beta version" || lc == "версия" || lc == "версия системы" {
        return format!("version={} code={} [Rust SQLite event-store + resource-runtime + typed + dispute]", VERSION, VERSION_CODE);
    }
    if lc == "system state" || lc == "debate state" || lc == "состояние" || lc == "состояние системы" {
        let s = state().lock().unwrap();
        return system_state_text(&s);
    }
    if lc == "system reset" {
        *state().lock().unwrap() = ModelState::default();
        return "OK system reset: current dispute + typed + runtime state cleared; durable SQLite audit log retained".into();
    }
    if lc == "model audit" {
        let s = state().lock().unwrap();
        return format!("model_hash={}", canonical_model_hash(&s));
    }
    if lc == "proof audit" {
        let s = state().lock().unwrap();
        if !s.project.active || s.project.phase != 6 || s.project.result.is_none() {
            return "ОШИБКА: proof ещё не завершён; сначала доведите typed-операцию до resume".into();
        }
        return format!("proof_hash={}", canonical_proof_hash(&s));
    }
    if lc == "model status" {
        let s = state().lock().unwrap();
        return format!(
            "model={} status_resource={} robustness={} concessions={} committed={}",
            if s.revisions.is_empty() { "base".to_string() } else { format!("rev-{}", s.revisions.len()) },
            s.status_resource,
            s.robustness,
            s.concessions.len(),
            s.committed
        );
    }
    if lc == "project state" {
        let s = state().lock().unwrap();
        return project_state_text(&s);
    }
    if lc == "storage status" {
        return storage_status_text();
    }
    if lc == "storage verify" {
        return storage_verify_text();
    }
    if lc == "storage checkpoint" {
        return match persist_storage_snapshot() {
            Ok(v) => format!("OK SQLite {}", v),
            Err(e) => format!("ОШИБКА STORAGE: {}", e),
        };
    }
    if lc == "graph layout clear" {
        let mut s = state().lock().unwrap();
        if !s.runtime.active { return "ОШИБКА: runtime не инициализирован".into(); }
        s.runtime.graph.layout.clear();
        return "OK graph layout cleared; viewer вернётся к auto-layout".into();
    }
    if lc.starts_with("graph layout set ") {
        let rest = cmd["graph layout set ".len()..].trim();
        let parts: Vec<&str> = rest.split_whitespace().collect();
        if parts.len() != 3 { return "НУЖЕН ВВОД: graph layout set <node-id> <x> <y>".into(); }
        let x: f32 = match parts[1].parse::<f32>() { Ok(v) if v.is_finite() => v, _ => return "ОШИБКА: x должен быть числом".into() };
        let y: f32 = match parts[2].parse::<f32>() { Ok(v) if v.is_finite() => v, _ => return "ОШИБКА: y должен быть числом".into() };
        let mut s = state().lock().unwrap();
        if !s.runtime.active { return "ОШИБКА: runtime не инициализирован".into(); }
        if !set_node_layout(&mut s.runtime.graph, parts[0], x.max(0.0), y.max(0.0)) {
            return format!("ОШИБКА: node {} не найден", parts[0]);
        }
        return format!("OK layout {} x={:.1} y={:.1}", parts[0], x.max(0.0), y.max(0.0));
    }
    if lc.starts_with("graph node add ") {
        let node_type = cmd["graph node add ".len()..].trim();
        let mut s = state().lock().unwrap();
        return graph_add_node(&mut s.runtime, node_type);
    }
    if lc.starts_with("graph node remove ") {
        let node_id = cmd["graph node remove ".len()..].trim();
        let mut s = state().lock().unwrap();
        if !s.runtime.active { return "ОШИБКА: runtime не инициализирован".into(); }
        return graph_remove_node(&mut s.runtime, node_id);
    }
    if lc.starts_with("graph edge remove ") {
        let edge_id = cmd["graph edge remove ".len()..].trim();
        let mut s = state().lock().unwrap();
        if !s.runtime.active { return "ОШИБКА: runtime не инициализирован".into(); }
        return graph_remove_edge(&mut s.runtime, edge_id);
    }
    if lc.starts_with("graph edge add ") {
        let rest = cmd["graph edge add ".len()..].trim();
        let parts: Vec<&str> = rest.split_whitespace().collect();
        if parts.len() != 2 { return "НУЖЕН ВВОД: graph edge add <from-node>.<from-port> <to-node>.<to-port>".into(); }
        let (from_node, from_port) = match parts[0].split_once('.') { Some(v) => v, None => return "ОШИБКА: source должен быть node.port".into() };
        let (to_node, to_port) = match parts[1].split_once('.') { Some(v) => v, None => return "ОШИБКА: target должен быть node.port".into() };
        let mut s = state().lock().unwrap();
        return graph_add_edge(&mut s.runtime, from_node, from_port, to_node, to_port);
    }

    if lc == "runtime reset" {
        let mut s = state().lock().unwrap();
        s.runtime = RuntimeState::default();
        return "OK runtime reset".into();
    }
    if lc == "runtime init demo" {
        let next = if storage_active() { storage_max_seq().saturating_add(1).max(1) } else { 1 };
        let mut s = state().lock().unwrap();
        s.runtime = demo_runtime_state();
        s.runtime.next_seq = next;
        s.runtime.correlation_id = format!("analysis-{}", next);
        return format!(
            "OK runtime demo initialized: Input -> Checks -> Compare -> Revision/Commit\ngraph=demo-resource-graph revision=3 nodes=6 edges=8\nresource total={} branch_cap={} iteration_budget_cap={} max_iterations={}",
            s.runtime.resource.policy.total_budget,
            s.runtime.resource.policy.branch_cap,
            s.runtime.resource.policy.iteration_budget_cap,
            s.runtime.resource.policy.max_iterations
        );
    }
    if lc == "runtime state" || lc == "runtime graph" {
        let s = state().lock().unwrap();
        return runtime_state_text(&s.runtime);
    }
    if lc == "runtime validate" {
        let s = state().lock().unwrap();
        if !s.runtime.active {
            return "ОШИБКА: runtime не инициализирован; используйте runtime init demo".into();
        }
        let errors = validate_graph(&s.runtime.graph);
        if errors.is_empty() {
            return format!(
                "VALID graph={} revision={} nodes={} edges={}",
                s.runtime.graph.graph_id,
                s.runtime.graph.revision,
                s.runtime.graph.nodes.len(),
                s.runtime.graph.edges.len()
            );
        }
        let mut out = vec![format!("INVALID graph={} errors={}", s.runtime.graph.graph_id, errors.len())];
        for error in errors {
            out.push(format!("- {}", error));
        }
        return out.join("\n");
    }
    if lc == "runtime queue" {
        let s = state().lock().unwrap();
        if !s.runtime.active { return "ОШИБКА: runtime не инициализирован".into(); }
        return runtime_queue_text(&s.runtime);
    }
    if lc == "runtime ledger" || lc == "runtime resource" {
        let s = state().lock().unwrap();
        if !s.runtime.active { return "ОШИБКА: runtime не инициализирован".into(); }
        return runtime_ledger_text(&s.runtime);
    }
    if lc == "runtime budget set" {
        return "НУЖЕН ВВОД: runtime budget set <n>".into();
    }
    if lc.starts_with("runtime budget set ") {
        let raw = cmd["runtime budget set ".len()..].trim();
        let value: u32 = match raw.parse() {
            Ok(v) if v > 0 => v,
            _ => return "ОШИБКА: budget должен быть положительным целым".into(),
        };
        let mut s = state().lock().unwrap();
        if !s.runtime.active { return "ОШИБКА: runtime не инициализирован".into(); }
        if !s.runtime.resource.ledger.is_empty() {
            return "ОШИБКА: budget нельзя менять после начала исполнения; runtime reset/init для нового запуска".into();
        }
        s.runtime.resource.policy.total_budget = value;
        s.runtime.resource.policy.branch_cap = value;
        s.runtime.resource.policy.iteration_budget_cap = s.runtime.resource.policy.iteration_budget_cap.min(value);
        return format!(
            "OK budget set: total={} branch_cap={} iteration_budget_cap={}",
            s.runtime.resource.policy.total_budget,
            s.runtime.resource.policy.branch_cap,
            s.runtime.resource.policy.iteration_budget_cap
        );
    }
    if lc == "runtime events" {
        let s = state().lock().unwrap();
        if !s.runtime.active { return "ОШИБКА: runtime не инициализирован".into(); }
        return runtime_events_text(&s.runtime);
    }
    if lc == "runtime emit claim" {
        return "НУЖЕН ВВОД: runtime emit claim <text>".into();
    }
    if lc.starts_with("runtime emit claim ") {
        let text = cmd["runtime emit claim ".len()..].trim();
        if text.is_empty() { return "НУЖЕН ВВОД: runtime emit claim <text>".into(); }
        let mut s = state().lock().unwrap();
        if !s.runtime.active { return "ОШИБКА: runtime не инициализирован; используйте runtime init demo".into(); }
        let errors = validate_graph(&s.runtime.graph);
        if !errors.is_empty() { return format!("ОШИБКА: graph invalid; errors={}", errors.len()); }
        let payload = serde_json::json!({"claim": text}).to_string();
        let event = append_runtime_event(&mut s.runtime, "ClaimEvent", payload, Some("n-input"), Some("out-claim"), None);
        let (routed, queued) = route_event(&mut s.runtime, &event);
        return format!(
            "EMIT {} kind=ClaimEvent claim={}\nrouted={} newly_queued={}\n{}",
            event.event_id,
            text,
            routed,
            queued,
            runtime_queue_text(&s.runtime)
        );
    }
    if lc == "runtime step" {
        let mut s = state().lock().unwrap();
        if !s.runtime.active { return "ОШИБКА: runtime не инициализирован".into(); }
        return execute_one_runtime_work(&mut s.runtime);
    }
    if lc == "runtime run" {
        let mut s = state().lock().unwrap();
        if !s.runtime.active { return "ОШИБКА: runtime не инициализирован".into(); }
        return execute_runtime_run(&mut s.runtime, 64);
    }
    if lc.starts_with("runtime run ") {
        let raw = cmd["runtime run ".len()..].trim();
        let max_steps: usize = match raw.parse::<usize>() {
            Ok(v) if v > 0 => v.min(256),
            _ => return "ОШИБКА: runtime run <steps>, steps должен быть положительным целым".into(),
        };
        let mut s = state().lock().unwrap();
        if !s.runtime.active { return "ОШИБКА: runtime не инициализирован".into(); }
        return execute_runtime_run(&mut s.runtime, max_steps);
    }
    if lc.starts_with("calc ") {
        let expr = cmd[5..].trim();
        let p: Vec<&str> = expr.split_whitespace().collect();
        if p.len() != 3 { return "использование: calc <int> <+|-|*> <int>".into(); }
        let a: i64 = match p[0].parse() { Ok(v) => v, Err(_) => return "ОШИБКА: неверное левое целое".into() };
        let b: i64 = match p[2].parse() { Ok(v) => v, Err(_) => return "ОШИБКА: неверное правое целое".into() };
        let r = match p[1] {
            "+" => a.wrapping_add(b),
            "-" => a.wrapping_sub(b),
            "*" => a.wrapping_mul(b),
            _ => return "оператор должен быть одним из: + - *".into(),
        };
        return format!("{} {} {} = {} [Rust]", a, p[1], b, r);
    }

    // --- typed operator vertical slice ---
    if lc == "project reset" {
        let mut s = state().lock().unwrap();
        s.project = ProjectState::default();
        s.bindings.clear();
        return "OK project reset; local definitions preserved; project bindings cleared".into();
    }
    if lc.starts_with("project new ") {
        let name = cmd["project new ".len()..].trim();
        if name.is_empty() { return "НУЖЕН ВВОД: project new <name>".into(); }
        let mut s = state().lock().unwrap();
        if s.project.active { return "ОШИБКА: typed-проект уже активен; сначала project reset".into(); }
        s.project = ProjectState {
            active: true,
            name: Some(name.to_string()),
            claim: None,
            operator: None,
            phase: 1,
            expected_concept_frame: None,
            expected_relation: None,
            result: None,
        };
        return format!("OK project created: {}", name);
    }
    if lc.starts_with("claim ") {
        let claim = cmd["claim ".len()..].trim();
        if claim.is_empty() { return "НУЖЕН ВВОД: claim <name>".into(); }
        let mut s = state().lock().unwrap();
        if !s.project.active || s.project.phase != 1 { return "ОШИБКА: claim сейчас не ожидается".into(); }
        s.project.claim = Some(claim.to_string());
        s.project.phase = 2;
        return format!("OK claim accepted: {}", claim);
    }
    if lc == "run classify.exclude" {
        let mut s = state().lock().unwrap();
        if !s.project.active || s.project.phase != 2 || s.project.claim.is_none() {
            return "ОШИБКА: сначала project new <name> и claim <name>".into();
        }
        s.project.operator = Some("classify.exclude".into());
        let expected_frame = "communist-party:functional".to_string();
        s.project.expected_concept_frame = Some(expected_frame.clone());
        let claim_upper = s.project.claim.as_deref().unwrap_or("").to_uppercase();
        let expected_relation = format!("follows_communist_principles({})", claim_upper);
        s.project.expected_relation = Some(expected_relation.clone());

        if find_definition(&s, "functional").is_none() {
            s.project.phase = 3;
            return format!("NEED_INPUT concept_frame: {}", expected_frame);
        }
        if find_binding(&s, "follows_communist_principles").is_none() {
            s.project.phase = 4;
            return format!("NEED_INPUT relation: {}", expected_relation);
        }
        s.project.phase = 5;
        return "READY: resume".into();
    }
    if lc.starts_with("definition create ") {
        let name = cmd["definition create ".len()..].trim();
        if name.is_empty() { return "НУЖЕН ВВОД: definition create <name>".into(); }
        let mut s = state().lock().unwrap();
        if !s.project.active || s.project.phase != 3 {
            return "ОШИБКА: definition сейчас не запрошена активной операцией".into();
        }
        let frame = definition_frame(name);
        s.definitions.retain(|d| !d.name.eq_ignore_ascii_case(name));
        s.definitions.push(DefinitionRecord { name: name.to_string(), frame: frame.clone() });
        s.project.expected_concept_frame = Some(frame.clone());
        s.project.phase = 4;
        let relation = s.project.expected_relation.clone().unwrap_or_else(|| "follows_communist_principles(?)".into());
        return format!("OK definition created: {} -> {}\nNEED_INPUT relation: {}", name, frame, relation);
    }
    if lc.starts_with("bind ") {
        let rest = cmd["bind ".len()..].trim();
        let mut parts = rest.split_whitespace();
        let relation = match parts.next() { Some(v) => v.trim(), None => return "НУЖЕН ВВОД: bind <relation> <true|false>".into() };
        let value_text = match parts.next() { Some(v) => v.trim(), None => return "НУЖЕН ВВОД: bind <relation> <true|false>".into() };
        if parts.next().is_some() { return "ОШИБКА: bind принимает relation и одно boolean-значение".into(); }
        let value = match parse_bool(value_text) { Some(v) => v, None => return "ОШИБКА: значение должно быть true/false (также да/нет)".into() };
        let mut s = state().lock().unwrap();
        if !s.project.active || s.project.phase != 4 {
            return "ОШИБКА: bind сейчас не запрошен активной операцией".into();
        }
        if !relation.eq_ignore_ascii_case("follows_communist_principles") {
            return format!("ОШИБКА: ожидается relation follows_communist_principles, получено {}", relation);
        }
        s.bindings.retain(|b| !b.relation.eq_ignore_ascii_case(relation));
        s.bindings.push(BindingRecord { relation: relation.to_string(), value });
        s.project.phase = 5;
        return format!("OK binding accepted: {}={}", relation, value);
    }
    if lc == "resume" {
        let mut s = state().lock().unwrap();
        if !s.project.active || s.project.phase != 5 {
            return "ОШИБКА: нет операции, готовой к resume".into();
        }
        if s.project.operator.as_deref() != Some("classify.exclude") {
            return "ОШИБКА: неизвестная приостановленная операция".into();
        }
        let claim = match s.project.claim.clone() { Some(v) => v, None => return "ОШИБКА: claim отсутствует".into() };
        let frame = match find_definition(&s, "functional") {
            Some(v) => v.frame.clone(),
            None => return "NEED_INPUT concept_frame: communist-party:functional".into(),
        };
        let relation_value = match find_binding(&s, "follows_communist_principles") {
            Some(v) => v.value,
            None => {
                let rel = s.project.expected_relation.clone().unwrap_or_else(|| "follows_communist_principles(?)".into());
                return format!("NEED_INPUT relation: {}", rel);
            }
        };
        let verdict = if relation_value { "IN" } else { "OUT" };
        let result = format!("{} {} {}", claim.to_uppercase(), verdict, frame);
        s.project.result = Some(result.clone());
        s.project.phase = 6;
        return result;
    }

    // --- dispute state machine ---
    if lc == "debate reset" {
        let mut s = state().lock().unwrap();
        reset_dispute(&mut s);
        return "OK debate reset".into();
    }
    if lc.starts_with("debate new ") {
        let name = cmd["debate new ".len()..].trim();
        if name.is_empty() { return "НУЖЕН ВВОД: debate new <name>".into(); }
        let mut s = state().lock().unwrap();
        if s.debate_name.is_some() { return "ОШИБКА: активное dispute-состояние уже существует; сначала debate reset".into(); }
        s.debate_name = Some(name.to_string());
        s.step = 1;
        return format!("OK debate created: {}", name);
    }
    if lc == "resolution" {
        return "НУЖЕН ВВОД: resolution <text>".into();
    }
    if lc.starts_with("resolution ") {
        let text = cmd["resolution ".len()..].trim();
        if text.is_empty() { return "НУЖЕН ВВОД: resolution <text>".into(); }
        let mut s = state().lock().unwrap();
        if let Err(e) = require_debate(&s) { return e; }
        if s.step != 1 { return "ОШИБКА: неверный порядок перехода".into(); }
        s.resolution = Some(text.to_string());
        s.step = 2;
        return format!("OK resolution accepted: {}", text);
    }
    if lc == "collision open" {
        return "НУЖЕН ВВОД: collision open <position-a> | <position-b>".into();
    }
    if lc.starts_with("collision open ") {
        let rest = cmd["collision open ".len()..].trim();
        let (a, b) = match parse_binary(rest) { Ok(v) => v, Err(e) => return e };
        let mut s = state().lock().unwrap();
        if s.step != 2 || s.resolution.is_none() { return "ОШИБКА: неверный порядок перехода".into(); }
        s.collision_a = Some(a.to_string());
        s.collision_b = Some(b.to_string());
        s.step = 3;
        return format!("OK collision open\nA: {}\nB: {}", a, b);
    }
    if lc == "function accept" {
        return "НУЖЕН ВВОД: function accept <function/context>".into();
    }
    if lc.starts_with("function accept ") {
        let text = cmd["function accept ".len()..].trim();
        if text.is_empty() { return "НУЖЕН ВВОД: function accept <function/context>".into(); }
        let mut s = state().lock().unwrap();
        if s.step != 3 || s.collision_a.is_none() || s.collision_b.is_none() { return "ОШИБКА: неверный порядок перехода".into(); }
        s.function_context = Some(text.to_string());
        s.step = 4;
        return format!("OK function/context accepted: {}", text);
    }
    if lc == "criterion accept" {
        return "НУЖЕН ВВОД: criterion accept <criterion>".into();
    }
    if lc.starts_with("criterion accept ") {
        let text = cmd["criterion accept ".len()..].trim();
        if text.is_empty() { return "НУЖЕН ВВОД: criterion accept <criterion>".into(); }
        let mut s = state().lock().unwrap();
        if s.step != 4 || s.function_context.is_none() { return "ОШИБКА: неверный порядок перехода".into(); }
        s.criterion = Some(text.to_string());
        s.step = 5;
        return format!("OK criterion accepted: {}", text);
    }
    if lc == "commit" {
        let mut s = state().lock().unwrap();
        if s.step != 5 || s.criterion.is_none() { return "ОШИБКА: неверный порядок перехода".into(); }
        s.committed = true;
        s.step = 6;
        s.robustness = s.robustness.saturating_add(1);
        return format!("COMMITTED: frame locked\nmodel_hash={}", canonical_model_hash(&s));
    }
    if lc == "model revise" {
        return "НУЖЕН ВВОД: model revise <text>".into();
    }
    if lc.starts_with("model revise ") {
        let note = cmd["model revise ".len()..].trim();
        if note.is_empty() { return "НУЖЕН ВВОД: model revise <text>".into(); }
        let mut s = state().lock().unwrap();
        if !s.committed { return "ОШИБКА: модель ещё не commit".into(); }
        let old_hash = canonical_model_hash(&s);
        let old_fn = s.function_context.clone();
        let old_cr = s.criterion.clone();
        s.revisions.push(RevisionRecord {
            note: note.to_string(),
            previous_function_context: old_fn,
            previous_criterion: old_cr,
            previous_hash: old_hash,
        });
        s.status_resource = s.status_resource.saturating_sub(10);
        s.robustness = s.robustness.saturating_sub(5);
        s.function_context = None;
        s.criterion = None;
        s.committed = false;
        s.step = 3;
        return format!("OK revision recorded; frame reopened: {}", note);
    }
    if lc == "model concede" {
        return "НУЖЕН ВВОД: model concede <target> | <reason>".into();
    }
    if lc.starts_with("model concede ") {
        let rest = cmd["model concede ".len()..].trim();
        let parsed = if rest.contains('|') {
            parse_binary(rest).map(|(a,b)| (a.to_string(), b.to_string()))
        } else {
            match rest.split_once(' ') {
                Some((a,b)) if !a.trim().is_empty() && !b.trim().is_empty() => Ok((a.trim().to_string(), b.trim().to_string())),
                _ => Err("НУЖЕН ВВОД: model concede <target> | <reason>".into()),
            }
        };
        let (target, reason) = match parsed { Ok(v) => v, Err(e) => return e };
        let mut s = state().lock().unwrap();
        if let Err(e) = require_debate(&s) { return e; }
        s.concessions.push(ConcessionRecord { target: target.clone(), reason: reason.clone() });
        s.status_resource = s.status_resource.saturating_sub(2);
        s.robustness = s.robustness.saturating_add(1);
        return format!("OK local concession recorded\ntarget={}\nreason={}", target, reason);
    }

    "НЕИЗВЕСТНАЯ КОМАНДА; введи help".into()
}


fn ui_snapshot_json() -> String {
    let s = state().lock().unwrap();
    let r = &s.runtime;
    if !r.active {
        return serde_json::json!({
            "active": false,
            "version": VERSION,
            "message": "runtime не инициализирован"
        }).to_string();
    }

    let spent = total_spent(r);
    let remaining = r.resource.policy.total_budget.saturating_sub(spent);
    let queued_total = r.work_items.iter().filter(|w| w.status == WorkStatus::Queued).count();
    let running_total = r.work_items.iter().filter(|w| w.status == WorkStatus::Running).count();
    let suspended_total = r.work_items.iter().filter(|w| w.status == WorkStatus::Suspended).count();
    let completed_total = r.work_items.iter().filter(|w| w.status == WorkStatus::Completed).count();

    let nodes: Vec<serde_json::Value> = r.graph.nodes.iter().map(|node| {
        let queued = r.work_items.iter().filter(|w| w.node_id == node.id && w.status == WorkStatus::Queued).count();
        let running = r.work_items.iter().filter(|w| w.node_id == node.id && w.status == WorkStatus::Running).count();
        let suspended = r.work_items.iter().filter(|w| w.node_id == node.id && w.status == WorkStatus::Suspended).count();
        let completed = r.work_items.iter().filter(|w| w.node_id == node.id && w.status == WorkStatus::Completed).count();
        let latest_event = r.events.iter().rev().find(|e| e.source_node.as_deref() == Some(node.id.as_str()));
        serde_json::json!({
            "id": node.id,
            "type": node.node_type,
            "label": node.label,
            "implementation_version": node.implementation_version,
            "estimated_cost": node_estimated_cost(&node.node_type),
            "priority": node_priority(&node.node_type),
            "queued": queued,
            "running": running,
            "suspended": suspended,
            "completed": completed,
            "latest_event_kind": latest_event.map(|e| e.kind.clone()),
            "latest_event_payload": latest_event.map(|e| e.payload_json.clone()),
            "x": layout_for(&r.graph, &node.id).map(|l| l.x),
            "y": layout_for(&r.graph, &node.id).map(|l| l.y),
            "ports": node.ports.iter().map(|p| serde_json::json!({
                "id": p.id,
                "name": p.name,
                "direction": format!("{:?}", p.direction),
                "event_type": p.event_type,
                "cardinality": format!("{:?}", p.cardinality)
            })).collect::<Vec<_>>()
        })
    }).collect();

    let edges: Vec<serde_json::Value> = r.graph.edges.iter().map(|edge| serde_json::json!({
        "id": edge.id,
        "from_node": edge.from_node,
        "from_port": edge.from_port,
        "to_node": edge.to_node,
        "to_port": edge.to_port,
        "event_type": edge.event_type
    })).collect();

    serde_json::json!({
        "active": true,
        "version": VERSION,
        "graph": {
            "id": r.graph.graph_id,
            "revision": r.graph.revision,
            "nodes": nodes,
            "edges": edges
        },
        "runtime": {
            "branch": r.branch_id,
            "correlation": r.correlation_id,
            "iteration": r.iteration,
            "next_seq": r.next_seq,
            "stop": r.stop_reason,
            "events": r.events.len(),
            "input_frames": r.input_frames.len(),
            "work_items": r.work_items.len(),
            "queued": queued_total,
            "running": running_total,
            "suspended": suspended_total,
            "completed": completed_total
        },
        "resource": {
            "total": r.resource.policy.total_budget,
            "spent": spent,
            "remaining": remaining,
            "branch_cap": r.resource.policy.branch_cap,
            "iteration_budget_cap": r.resource.policy.iteration_budget_cap,
            "max_iterations": r.resource.policy.max_iterations
        }
    }).to_string()
}

fn to_jstring(env: JNIEnv, text: String) -> jstring {
    match env.new_string(text) {
        Ok(s) => s.into_raw(),
        Err(_) => ptr::null_mut(),
    }
}

#[no_mangle]
pub extern "system" fn Java_io_typedcalculus_console_NativeBridge_command(
    mut env: JNIEnv,
    _class: JClass,
    input: JString,
) -> jstring {
    let text: String = match env.get_string(&input) {
        Ok(s) => s.into(),
        Err(_) => return to_jstring(env, "ОШИБКА: некорректный UTF-8 ввод".into()),
    };
    let mut response = command_impl(&text);
    if storage_active() {
        if let Err(e) = persist_storage_snapshot() {
            response.push_str(&format!("\nSTORAGE ERROR: {}", e));
        }
    }
    to_jstring(env, response)
}

#[no_mangle]
pub extern "system" fn Java_io_typedcalculus_console_NativeBridge_expectation(
    env: JNIEnv,
    _class: JClass,
) -> jstring {
    let s = state().lock().unwrap();
    to_jstring(env, expectation_for(&s))
}

#[no_mangle]
pub extern "system" fn Java_io_typedcalculus_console_NativeBridge_uiSnapshot(
    env: JNIEnv,
    _class: JClass,
) -> jstring {
    to_jstring(env, ui_snapshot_json())
}

#[no_mangle]
pub extern "system" fn Java_io_typedcalculus_console_NativeBridge_exportState(
    env: JNIEnv,
    _class: JClass,
) -> jstring {
    let s = state().lock().unwrap();
    let text = serde_json::to_string(&*s).unwrap_or_else(|_| "{}".into());
    to_jstring(env, text)
}

#[no_mangle]
pub extern "system" fn Java_io_typedcalculus_console_NativeBridge_importState(
    mut env: JNIEnv,
    _class: JClass,
    input: JString,
) -> jboolean {
    let text: String = match env.get_string(&input) {
        Ok(s) => s.into(),
        Err(_) => return JNI_FALSE,
    };
    let mut parsed: ModelState = match serde_json::from_str(&text) {
        Ok(v) => v,
        Err(_) => return JNI_FALSE,
    };
    if parsed.schema != 2 { return JNI_FALSE; }
    normalize_runtime_event_chain(&mut parsed.runtime);
    *state().lock().unwrap() = parsed;
    if storage_active() {
        if persist_storage_snapshot().is_err() { return JNI_FALSE; }
    }
    JNI_TRUE
}

#[no_mangle]
pub extern "system" fn Java_io_typedcalculus_console_NativeBridge_initStorage(
    mut env: JNIEnv,
    _class: JClass,
    path: JString,
) -> jstring {
    let path_text: String = match env.get_string(&path) {
        Ok(s) => s.into(),
        Err(_) => return to_jstring(env, "ERROR invalid storage path".into()),
    };
    let result = match initialize_storage(&path_text) {
        Ok(v) => v,
        Err(e) => format!("ERROR {}", e),
    };
    to_jstring(env, result)
}

#[no_mangle]
pub extern "system" fn Java_io_typedcalculus_console_NativeBridge_persistStorage(
    env: JNIEnv,
    _class: JClass,
) -> jstring {
    let result = match persist_storage_snapshot() {
        Ok(v) => format!("OK {}", v),
        Err(e) => format!("ERROR {}", e),
    };
    to_jstring(env, result)
}
