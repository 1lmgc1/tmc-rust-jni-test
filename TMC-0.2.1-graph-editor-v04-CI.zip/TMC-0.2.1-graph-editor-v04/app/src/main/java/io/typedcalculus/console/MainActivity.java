package io.typedcalculus.console;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class MainActivity extends Activity {
    private static final String VERSION = "0.2.1-graph-editor-v04";

    private TextView output;
    private EditText input;
    private ScrollView scroll;
    private SharedPreferences prefs;
    private boolean nativeReady;
    private boolean sqliteReady;
    private final ArrayDeque<String> commandQueue = new ArrayDeque<>();

    private LinearLayout graphPane;
    private LinearLayout consolePane;
    private GraphView graphView;
    private TextView graphTelemetry;
    private TextView graphAction;
    private Button graphTab;
    private Button consoleTab;
    private Button editorButton;
    private LinearLayout paletteContent;
    private LinearLayout buildControls;
    private LinearLayout operationControls;
    private Button paletteToggle;
    private Button buildModeButton;
    private Button operationModeButton;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
        prefs = getSharedPreferences("tmc", MODE_PRIVATE);
        printGreeting();
        try {
            NativeBridge.load();
            nativeReady = true;

            String dbPath = new java.io.File(getFilesDir(), "tmc-runtime.sqlite3").getAbsolutePath();
            String storage = NativeBridge.initStorage(dbPath);
            if (storage != null && storage.startsWith("RESTORED")) {
                sqliteReady = true;
                println("SQLite: состояние восстановлено; " + storage);
            } else if (storage != null && storage.startsWith("EMPTY")) {
                sqliteReady = true;
                println("SQLite: создан новый durable store; " + storage);
                String saved = prefs.getString("rust_state_json_v2", null);
                if (saved != null && !saved.isEmpty()) {
                    boolean ok = NativeBridge.importState(saved);
                    println(ok ? "Миграция SharedPreferences → SQLite: OK" : "Миграция SharedPreferences → SQLite: отклонена");
                } else {
                    String checkpoint = NativeBridge.persistStorage();
                    println("SQLite: " + checkpoint);
                }
            } else {
                println("SQLite недоступен: " + storage);
                String saved = prefs.getString("rust_state_json_v2", null);
                if (saved != null && !saved.isEmpty()) {
                    boolean ok = NativeBridge.importState(saved);
                    println(ok ? "Fallback SharedPreferences: состояние восстановлено" : "Fallback SharedPreferences: состояние не принято");
                }
            }
            printExpectation();
            showGraph();
            refreshGraph();
        } catch (Throwable t) {
            println("ОШИБКА NATIVE: " + t.getClass().getSimpleName() + ": " + t.getMessage());
            graphAction.setText("NATIVE ERROR: " + t.getClass().getSimpleName());
        }
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(31, 33, 36));

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        tabs.setPadding(dp(6), dp(4), dp(6), dp(2));

        graphTab = new Button(this);
        graphTab.setText("ГРАФ");
        tabs.addView(graphTab, new LinearLayout.LayoutParams(0, -2, 1f));

        consoleTab = new Button(this);
        consoleTab.setText("КОНСОЛЬ");
        tabs.addView(consoleTab, new LinearLayout.LayoutParams(0, -2, 1f));
        root.addView(tabs, new LinearLayout.LayoutParams(-1, -2));

        graphPane = buildGraphPane();
        consolePane = buildConsolePane();
        root.addView(graphPane, new LinearLayout.LayoutParams(-1, 0, 1f));
        root.addView(consolePane, new LinearLayout.LayoutParams(-1, 0, 1f));

        graphTab.setOnClickListener(v -> showGraph());
        consoleTab.setOnClickListener(v -> showConsole());

        setContentView(root);
        showGraph();
    }

    private LinearLayout buildGraphPane() {
        LinearLayout pane = new LinearLayout(this);
        pane.setOrientation(LinearLayout.VERTICAL);
        pane.setPadding(dp(5), dp(2), dp(5), dp(5));

        graphTelemetry = new TextView(this);
        graphTelemetry.setTextColor(Color.WHITE);
        graphTelemetry.setTextSize(12.5f);
        graphTelemetry.setGravity(Gravity.START);
        graphTelemetry.setPadding(dp(5), dp(3), dp(5), dp(2));
        graphTelemetry.setMaxLines(2);
        graphTelemetry.setText("runtime: загрузка…");
        pane.addView(graphTelemetry, new LinearLayout.LayoutParams(-1, -2));

        graphAction = new TextView(this);
        graphAction.setTextColor(Color.LTGRAY);
        graphAction.setTextSize(11f);
        graphAction.setPadding(dp(5), 0, dp(5), dp(3));
        graphAction.setMaxLines(2);
        graphAction.setText("ГРАФ: панорама/масштаб. Для изменения topology открой ПАЛИТРА → ПОСТРОЕНИЕ.");
        pane.addView(graphAction, new LinearLayout.LayoutParams(-1, -2));

        graphView = new GraphView(this);
        graphView.setListener(new GraphView.Listener() {
            @Override public void onNodeMoved(String nodeId, float xDp, float yDp) {
                String cmd = String.format(Locale.US, "graph layout set %s %.1f %.1f", nodeId, xDp, yDp);
                runGraphCommand(cmd, false);
            }

            @Override public void onConnect(String fromNode, String fromPort, String toNode, String toPort) {
                runGraphCommand("graph edge add " + fromNode + "." + fromPort + " " + toNode + "." + toPort, false);
            }

            @Override public void onNodeSelected(String nodeId, String label, String type) {
                graphAction.setText("Выбран: " + GraphView.localizedType(type) + " · " + label + " [" + nodeId + "]");
            }

            @Override public void onEditorMessage(String message) {
                graphAction.setText(message);
            }
        });
        pane.addView(graphView, new LinearLayout.LayoutParams(-1, 0, 1f));

        paletteToggle = makeButton("ПАЛИТРА ▲");
        pane.addView(paletteToggle, new LinearLayout.LayoutParams(-1, -2));

        paletteContent = new LinearLayout(this);
        paletteContent.setOrientation(LinearLayout.VERTICAL);
        paletteContent.setPadding(0, dp(1), 0, 0);

        LinearLayout modeRow = new LinearLayout(this);
        modeRow.setOrientation(LinearLayout.HORIZONTAL);
        buildModeButton = makeButton("ПОСТРОЕНИЕ");
        operationModeButton = makeButton("ОПЕРАЦИИ");
        modeRow.addView(buildModeButton, new LinearLayout.LayoutParams(0, -2, 1f));
        modeRow.addView(operationModeButton, new LinearLayout.LayoutParams(0, -2, 1f));
        paletteContent.addView(modeRow, new LinearLayout.LayoutParams(-1, -2));

        buildControls = new LinearLayout(this);
        buildControls.setOrientation(LinearLayout.VERTICAL);

        LinearLayout buildRow1 = new LinearLayout(this);
        buildRow1.setOrientation(LinearLayout.HORIZONTAL);
        editorButton = makeButton("РЕДАКТОР");
        Button addNode = makeButton("+ УЗЕЛ");
        Button deleteNode = makeButton("УДАЛИТЬ");
        Button fit = makeButton("ВПИСАТЬ");
        buildRow1.addView(editorButton, new LinearLayout.LayoutParams(0, -2, 1f));
        buildRow1.addView(addNode, new LinearLayout.LayoutParams(0, -2, 1f));
        buildRow1.addView(deleteNode, new LinearLayout.LayoutParams(0, -2, 1f));
        buildRow1.addView(fit, new LinearLayout.LayoutParams(0, -2, 1f));
        buildControls.addView(buildRow1, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout buildRow2 = new LinearLayout(this);
        buildRow2.setOrientation(LinearLayout.HORIZONTAL);
        Button autoLayout = makeButton("AUTO LAYOUT");
        Button validate = makeButton("ПРОВЕРИТЬ ГРАФ");
        buildRow2.addView(autoLayout, new LinearLayout.LayoutParams(0, -2, 1f));
        buildRow2.addView(validate, new LinearLayout.LayoutParams(0, -2, 1f));
        buildControls.addView(buildRow2, new LinearLayout.LayoutParams(-1, -2));
        paletteContent.addView(buildControls, new LinearLayout.LayoutParams(-1, -2));

        operationControls = new LinearLayout(this);
        operationControls.setOrientation(LinearLayout.VERTICAL);

        LinearLayout opRow1 = new LinearLayout(this);
        opRow1.setOrientation(LinearLayout.HORIZONTAL);
        Button init = makeButton("INIT");
        Button step = makeButton("STEP");
        Button run = makeButton("RUN");
        Button refresh = makeButton("ОБНОВИТЬ");
        opRow1.addView(init, new LinearLayout.LayoutParams(0, -2, 1f));
        opRow1.addView(step, new LinearLayout.LayoutParams(0, -2, 1f));
        opRow1.addView(run, new LinearLayout.LayoutParams(0, -2, 1f));
        opRow1.addView(refresh, new LinearLayout.LayoutParams(0, -2, 1f));
        operationControls.addView(opRow1, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout opRow2 = new LinearLayout(this);
        opRow2.setOrientation(LinearLayout.HORIZONTAL);
        Button queue = makeButton("ОЧЕРЕДЬ");
        Button events = makeButton("СОБЫТИЯ");
        Button ledger = makeButton("РЕСУРС");
        opRow2.addView(queue, new LinearLayout.LayoutParams(0, -2, 1f));
        opRow2.addView(events, new LinearLayout.LayoutParams(0, -2, 1f));
        opRow2.addView(ledger, new LinearLayout.LayoutParams(0, -2, 1f));
        operationControls.addView(opRow2, new LinearLayout.LayoutParams(-1, -2));
        paletteContent.addView(operationControls, new LinearLayout.LayoutParams(-1, -2));

        pane.addView(paletteContent, new LinearLayout.LayoutParams(-1, -2));

        paletteToggle.setOnClickListener(v -> {
            boolean show = paletteContent.getVisibility() != View.VISIBLE;
            paletteContent.setVisibility(show ? View.VISIBLE : View.GONE);
            paletteToggle.setText(show ? "ПАЛИТРА ▲" : "ПАЛИТРА ▼");
        });
        buildModeButton.setOnClickListener(v -> showBuildControls());
        operationModeButton.setOnClickListener(v -> showOperationControls());

        init.setOnClickListener(v -> runGraphCommand("runtime init demo", false));
        step.setOnClickListener(v -> runGraphCommand("runtime step", false));
        run.setOnClickListener(v -> runGraphCommand("runtime run", false));
        refresh.setOnClickListener(v -> refreshGraph());
        fit.setOnClickListener(v -> graphView.fitToScreen());
        queue.setOnClickListener(v -> runGraphCommand("runtime queue", true));
        events.setOnClickListener(v -> runGraphCommand("runtime events", true));
        ledger.setOnClickListener(v -> runGraphCommand("runtime ledger", true));
        validate.setOnClickListener(v -> runGraphCommand("runtime validate", false));
        editorButton.setOnClickListener(v -> {
            boolean enabled = !graphView.isEditMode();
            graphView.setEditMode(enabled);
            editorButton.setText(enabled ? "EDIT: ВКЛ" : "РЕДАКТОР");
            graphAction.setText(enabled
                    ? "EDIT: перетащи узел; затем тап по OUT и по совместимому IN. Связи рисуются прямыми."
                    : "VIEW: панорама и масштаб; topology заблокирована от случайных касаний.");
            graphTelemetry.setText(graphView.compactSummary());
        });
        addNode.setOnClickListener(v -> showNodePalette());
        deleteNode.setOnClickListener(v -> {
            String id = graphView.getSelectedNodeId();
            if (id == null || id.isEmpty()) {
                graphAction.setText("Сначала выбери добавленный узел в режиме EDIT.");
                return;
            }
            runGraphCommand("graph node remove " + id, false);
            graphView.clearSelection();
        });
        autoLayout.setOnClickListener(v -> {
            runGraphCommand("graph layout clear", false);
            graphView.fitToScreen();
        });

        showBuildControls();
        paletteContent.setVisibility(View.GONE);
        paletteToggle.setText("ПАЛИТРА ▼");
        graphAction.setText("ГРАФ: связи прямые. Открой ПАЛИТРА для построения или запуска.");
        return pane;
    }

    private void showBuildControls() {
        if (buildControls == null || operationControls == null) return;
        buildControls.setVisibility(View.VISIBLE);
        operationControls.setVisibility(View.GONE);
        buildModeButton.setEnabled(false);
        operationModeButton.setEnabled(true);
        graphAction.setText("ПОСТРОЕНИЕ: РЕДАКТОР → + УЗЕЛ → выбери функцию; OUT → совместимый IN.");
    }

    private void showOperationControls() {
        if (buildControls == null || operationControls == null) return;
        buildControls.setVisibility(View.GONE);
        operationControls.setVisibility(View.VISIBLE);
        buildModeButton.setEnabled(true);
        operationModeButton.setEnabled(false);
        graphAction.setText("ОПЕРАЦИИ: INIT / STEP / RUN; диагностика — ОЧЕРЕДЬ, СОБЫТИЯ, РЕСУРС.");
    }

    private void showNodePalette() {
        final String[] labels = {
                "Семантическая проверка",
                "Контрпроверка",
                "Сравнение / Join",
                "Ревизия",
                "Фиксация / Commit"
        };
        final String[] types = {"SemanticCheck", "CounterCheck", "Compare", "Revision", "Commit"};
        new AlertDialog.Builder(this)
                .setTitle("Добавить функцию")
                .setItems(labels, (dialog, which) -> runGraphCommand("graph node add " + types[which], false))
                .setNegativeButton("ОТМЕНА", null)
                .show();
    }

    private LinearLayout buildConsolePane() {
        LinearLayout pane = new LinearLayout(this);
        pane.setOrientation(LinearLayout.VERTICAL);
        pane.setPadding(dp(8), dp(4), dp(8), dp(8));

        scroll = new ScrollView(this);
        output = new TextView(this);
        output.setTextColor(Color.LTGRAY);
        output.setTextSize(16f);
        output.setGravity(Gravity.START);
        output.setTextIsSelectable(true);
        scroll.addView(output, new ScrollView.LayoutParams(-1,-2));
        pane.addView(scroll, new LinearLayout.LayoutParams(-1,0,1f));

        input = new EditText(this);
        input.setHint("команды — по одной на строку");
        input.setSingleLine(false);
        input.setMinLines(3);
        input.setMaxLines(8);
        input.setGravity(Gravity.TOP | Gravity.START);
        input.setHorizontallyScrolling(false);
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(Color.LTGRAY);
        input.setImeOptions(EditorInfo.IME_FLAG_NO_ENTER_ACTION);
        pane.addView(input, new LinearLayout.LayoutParams(-1,-2));

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);

        Button execute = makeButton("ВЫПОЛНИТЬ");
        buttons.addView(execute, new LinearLayout.LayoutParams(0,-2,1f));

        Button clear = makeButton("ОЧИСТИТЬ");
        buttons.addView(clear, new LinearLayout.LayoutParams(0,-2,1f));

        pane.addView(buttons, new LinearLayout.LayoutParams(-1,-2));

        execute.setOnClickListener(v -> dispatchBatch());
        clear.setOnClickListener(v -> {
            input.setText("");
            commandQueue.clear();
        });

        return pane;
    }

    private Button makeButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(11f);
        b.setMinHeight(0);
        b.setMinWidth(0);
        b.setPadding(dp(2), dp(4), dp(2), dp(4));
        return b;
    }

    private void showGraph() {
        graphPane.setVisibility(View.VISIBLE);
        consolePane.setVisibility(View.GONE);
        if (nativeReady) refreshGraph();
    }

    private void showConsole() {
        graphPane.setVisibility(View.GONE);
        consolePane.setVisibility(View.VISIBLE);
    }

    private void refreshGraph() {
        if (!nativeReady) return;
        try {
            String json = NativeBridge.uiSnapshot();
            graphView.setSnapshot(json);
            graphTelemetry.setText(graphView.compactSummary());
        } catch (Throwable t) {
            graphAction.setText("Ошибка GraphView: " + t.getClass().getSimpleName() + ": " + t.getMessage());
        }
    }

    private void runGraphCommand(String cmd, boolean openConsole) {
        if (!nativeReady) return;
        try {
            String response = NativeBridge.command(cmd);
            println("> " + cmd);
            if (response != null && !response.isEmpty()) println(response);
            saveState();
            graphAction.setText(compactResponse(cmd, response));
            refreshGraph();
            if (openConsole) showConsole();
        } catch (Throwable t) {
            graphAction.setText("ОШИБКА: " + t.getClass().getSimpleName() + ": " + t.getMessage());
        }
    }

    private String compactResponse(String cmd, String response) {
        if (response == null || response.isEmpty()) return cmd;
        String line = response.split("\\n", 2)[0];
        return cmd + " → " + line;
    }

    private void printGreeting() {
        println(" /\\_/\\ ");
        println("( o.o )   TMC " + VERSION);
        println(" > ^ <    Graph Editor / Java host / Rust SQLite event-runtime / Android 14 arm64");
        println("");
        println(" /\\_/\\   /\\_/\\ ");
        println("( =^.^= ) ( =^.^= )");
        println("(\")_(\") (\")_(\")");
        println("");
        println("ГРАФ — основной интерфейс runtime; нижняя ПАЛИТРА сворачивается.");
        println("ПОСТРОЕНИЕ — узлы, связи и layout; ОПЕРАЦИИ — INIT/STEP/RUN и диагностика.");
        println("Палитра функций подписана по-русски; внутренние типы Rust не меняются.");
        println("Связи на графе — только прямые отрезки, без кривых Безье.");
        println("");
    }

    private void dispatchBatch() {
        String raw = input.getText().toString();
        if (raw == null || raw.trim().isEmpty()) return;

        List<String> commands = parseCommands(raw);
        if (commands.isEmpty()) {
            input.setText("");
            return;
        }

        input.setText("");
        commandQueue.clear();
        commandQueue.addAll(commands);

        if (!nativeReady) {
            println("native core недоступно");
            return;
        }

        if (commands.size() > 1) println("=== ПАКЕТ: " + commands.size() + " команд ===");

        int total = commands.size();
        int index = 0;
        while (!commandQueue.isEmpty()) {
            String cmd = commandQueue.removeFirst();
            index++;
            if (total > 1) println("[" + index + "/" + total + "] > " + cmd);
            else println("> " + cmd);

            try {
                String response = NativeBridge.command(cmd);
                if (response != null && !response.isEmpty()) println(response);
                saveState();

                if (isHardFailure(response)) {
                    preserveRemainingQueue();
                    println("=== ПАКЕТ ОСТАНОВЛЕН: ошибка на " + index + "/" + total +
                            "; оставшиеся команды возвращены в поле ввода ===");
                    printExpectation();
                    refreshGraph();
                    return;
                }
            } catch (Throwable t) {
                println("ОШИБКА: " + t.getClass().getSimpleName() + ": " + t.getMessage());
                preserveRemainingQueue();
                println("=== ПАКЕТ ОСТАНОВЛЕН: исключение; оставшиеся команды возвращены в поле ввода ===");
                printExpectation();
                refreshGraph();
                return;
            }
        }

        if (total > 1) println("=== ПАКЕТ ЗАВЕРШЁН: " + total + "/" + total + " ===");
        printExpectation();
        refreshGraph();
    }

    private List<String> parseCommands(String raw) {
        String normalized = raw.replace("\r\n", "\n").replace('\r', '\n');
        String[] lines = normalized.split("\n");
        ArrayList<String> result = new ArrayList<>();
        for (String line : lines) {
            String cmd = line.trim();
            if (cmd.isEmpty()) continue;
            if (cmd.startsWith("#")) continue;
            result.add(cmd);
        }
        return result;
    }

    private boolean isHardFailure(String response) {
        if (response == null) return false;
        String r = response.trim();
        return r.startsWith("ОШИБКА:") ||
               r.startsWith("ERROR:") ||
               r.startsWith("НЕИЗВЕСТНАЯ КОМАНДА") ||
               r.startsWith("TYPE MISMATCH:") ||
               r.startsWith("CARDINALITY:") ||
               r.startsWith("UNKNOWN;");
    }

    private void preserveRemainingQueue() {
        if (commandQueue.isEmpty()) return;
        StringBuilder sb = new StringBuilder();
        while (!commandQueue.isEmpty()) {
            if (sb.length() > 0) sb.append('\n');
            sb.append(commandQueue.removeFirst());
        }
        input.setText(sb.toString());
        input.setSelection(input.getText().length());
    }

    private void saveState() {
        if (sqliteReady) return;
        String data = NativeBridge.exportState();
        if (data != null) prefs.edit().putString("rust_state_json_v2", data).apply();
    }

    private void printExpectation() {
        if (!nativeReady) return;
        String e = NativeBridge.expectation();
        println("Ожидаю: " + e);
    }

    private void println(String s) {
        if (output == null) return;
        output.append(s); output.append("\n");
        if (scroll != null) scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }
}
